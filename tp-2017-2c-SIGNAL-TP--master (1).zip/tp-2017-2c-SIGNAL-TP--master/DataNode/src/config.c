/*
 * config.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */
#include "config.h"

int datanode_config_create(datanode_config *config,char* config_path){
	t_config *cfg_config;
	cfg_config = config_create(config_path);
	if(cfg_config == NULL){
		pthread_mutex_lock(&mutex_datanode_log);
		log_error(datanode_log, "datanode_config_create->No se pudo acceder al archivo de config");
		pthread_mutex_unlock(&mutex_datanode_log);
		return 0;
	}

	if (config_keys_amount(cfg_config) == CANTIDAD_PARAMETROS_CONFIG) {
		if (config_has_property(cfg_config, "IP_FILESYSTEM")) {
			config->ip_fs = string_new();
			string_append(&config->ip_fs,config_get_string_value(cfg_config, "IP_FILESYSTEM"));
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: IP_FILESYSTEM");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "PUERTO_FILESYSTEM")) {
			config->puerto_fs = config_get_int_value(cfg_config, "PUERTO_FILESYSTEM");
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: PUERTO_FILESYSTEM");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "NOMBRE_NODO")) {
			config->nombre_nodo = string_new();
			string_append(&config->nombre_nodo,config_get_string_value(cfg_config, "NOMBRE_NODO"));
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: NOMBRE_NODO");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "IP_WORKER")) {
			config->ip_worker = string_new();
			string_append(&config->ip_worker,config_get_string_value(cfg_config, "IP_WORKER"));
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: IP_WORKER");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "PUERTO_WORKER")) {
			config->puerto_worker = config_get_int_value(cfg_config, "PUERTO_WORKER");
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: PUERTO_WORKER");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "PUERTO_DATANODE")) {
			config->puerto_datanode = config_get_int_value(cfg_config, "PUERTO_DATANODE");
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: PUERTO_DATANODE");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "RUTA_DATABIN")) {
			config->ruta_databin = string_new();
			string_append(&config->ruta_databin,config_get_string_value(cfg_config, "RUTA_DATABIN"));
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: RUTA_DATABIN");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
		if (config_has_property(cfg_config, "TAMANO_DISCO")) {
			config->tamano_disco = config_get_int_value(cfg_config, "TAMANO_DISCO");
		} else {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "datanode_config_create->Falta el parametro: TAMANO_DISCO");
			pthread_mutex_unlock(&mutex_datanode_log);
			return 0;
		}
	}else{
		pthread_mutex_lock(&mutex_datanode_log);
		log_error(datanode_log, "datanode_config_create->El archivo de configuracion no tiene todos los parametros necesarios");
		pthread_mutex_unlock(&mutex_datanode_log);
		return 0;
	}
	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "datanode_config_create->Se ha cargado el archivo de configuracion del datanode exitosamente");
	pthread_mutex_unlock(&mutex_datanode_log);
	config_destroy(cfg_config);
	return 1;
}

void datanode_config_destroy(datanode_config *config){
	free(config->ip_fs);
	free(config->ip_worker);
	free(config->nombre_nodo);
	free(config->ruta_databin);
	free(config);
	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "datanode_config_destroy->Estructura datanode_cfg liberada exitosamente");
	pthread_mutex_unlock(&mutex_datanode_log);
}

void log_config(datanode_config *config){
	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log,"-----Archivo de configuracion del proceso datanode -----\n");
	log_trace(datanode_log,"IP_FILESYSTEM: %s\n",config->ip_fs);
	log_trace(datanode_log,"PUERTO_FILESYSTEM: %d\n",config->puerto_fs);
	log_trace(datanode_log,"NOMBRE_NODO: %s\n",config->nombre_nodo);
	log_trace(datanode_log,"IP_WORKER: %s\n",config->ip_worker);
	log_trace(datanode_log,"PUERTO_WORKER: %d\n",config->puerto_worker);
	log_trace(datanode_log,"PUERTO_DATANODE: %d\n",config->puerto_datanode);
	log_trace(datanode_log,"RUTA_DATABIN: %s\n",config->ruta_databin);
	log_trace(datanode_log,"TAMANO_DISCO: %d\n",config->tamano_disco);
	log_trace(datanode_log,"-----Fin archivo de configuracion del proceso datanode-----\n");
	pthread_mutex_unlock(&mutex_datanode_log);
}

