/*
 * serializeDnode.h
 *
 *  Created on: 14/10/2017
 *      Author: utnso
 */

#ifndef SRC_SERIALIZEDNODE_H_
#define SRC_SERIALIZEDNODE_H_
#include <stdio.h>
#include <ctype.h>
#include <stdint.h>
#include "src/socket-adm.h"
#include "src/serialize-adm.h"
#include <stdlib.h>
#include <string.h>

/*
 * serialize_nuevo_nodo:
 * Serializa una estructura del tipo t_mensaje_nuevo_nodo;
 * */
char* serialize_nuevo_nodo(t_mensaje_nuevo_nodo* mensaje_nodo, int* largo);

/*
 * enviar_mensaje_nuevo_nodo:
 * envia una estructura del tipo t_mensaje_nuevo_nodo al sock_fd pasado por parametro
 * */
int enviar_mensaje_nuevo_nodo(t_mensaje_nuevo_nodo *mensaje_nodo, int sock_fd);


#endif /* SRC_SERIALIZEDNODE_H_ */
