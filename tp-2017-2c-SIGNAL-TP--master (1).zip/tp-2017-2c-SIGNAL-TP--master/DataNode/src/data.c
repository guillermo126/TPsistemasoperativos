/*
 * data.c
 *
 *  Created on: 7/9/2017
 *      Author: utnso
 */
#include "data.h"

int create_databin(char* path, int size_mb){
	int rta=0;
	FILE *fp=fopen(path, "w");
	if(ftruncate(fileno(fp), (1024*1024)*size_mb)== -1){
		rta=0;
		log_error(datanode_log, "create_databin->error al truncar el archivo %s",path);
	}else{
		if(fclose(fp)!=0){
			rta=0;
			log_error(datanode_log, "create_databin->error al cerrar el archivo %s",path);
		}else{
			rta=1;
			log_trace(datanode_log, "create_databin->archivo %s creado correctamente con el tamano de %dMB",path,size_mb);
		}
	}
	return rta;
}
//chequea si existe el archivo data bin, si no existe lo crea
int check_and_create_databin(char* path){
	int rta = 1;
	if( access( path, F_OK ) != -1 ) {
		log_trace(datanode_log, "check_and_create_databin->el archivo %s existe",path);
	} else {
		log_trace(datanode_log, "check_and_create_databin->el archivo %s no existe, se procede a crearlo",path);
		if (!create_databin(path, datanode_cfg->tamano_disco)){
			log_error(datanode_log, "check_and_create_databin->error al crear el archivo %s",path);
			rta = 0;
		}
	}
	return rta;
}

char* mapearDisco(){
	pmap_fs = map_file(datanode_cfg->ruta_databin,datanode_log);
	if (pmap_fs == NULL) {
		pthread_mutex_lock(&mutex_datanode_log);
		log_error(datanode_log, "mapearDisco->Error al mapear el archivo bin %s",datanode_cfg->ruta_databin);
		pthread_mutex_unlock(&mutex_datanode_log);
	}
	return pmap_fs;
}

int initData(){
	if(!check_and_create_databin(datanode_cfg->ruta_databin)){
		log_error(datanode_log, "initData->Error al chequear el archivo bin %s",datanode_cfg->ruta_databin);
	}else{
		if (mapearDisco() == NULL) {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "initData->No se pudo mapear el data.bin");
			pthread_mutex_unlock(&mutex_datanode_log);
			return EXIT_FAILURE;
		}
		log_trace(datanode_log, "initData->Se mapeo correctamente el archivo data.bin");
	}
	return EXIT_SUCCESS;
}

int conectarse_a_proceso_filesystem() {
	char* puerto = string_itoa(datanode_cfg->puerto_fs);
	int sock_aux = socket_create(datanode_cfg->ip_fs, puerto, TIPO_CLIENTE, 1, datanode_log);
	if (sock_aux) {
		pthread_mutex_lock(&mutex_datanode_log);
		log_trace(datanode_log, "conectarse_a_proceso_filesystem()->Conexion al proceso filesystem exitosa");
		pthread_mutex_unlock(&mutex_datanode_log);
		socket_filesystem = sock_aux;
	}
	free(puerto);
	return socket_filesystem;
}

//crea un archivo data bin de un tamaño especifico


unsigned int round_closest(unsigned int dividend, unsigned int divisor)
{
	return (dividend + (divisor / 2)) / divisor;
}

int obtener_id_nodo(char* nombreNodo){
	char* subs = string_substring(nombreNodo, 4, string_length(nombreNodo));
	int id_nodo = atoi(subs);
	free(subs);
	return id_nodo;
}

unsigned int obtener_bloques_totales_nodo(){
	struct stat st;
	stat(datanode_cfg->ruta_databin, &st);
	unsigned int calc= round_closest(st.st_size, (1024*1024));
	log_trace(datanode_log, "obtener_bloques_totales_nodo-> el tamano del archivo data.bin es de  %dMB",calc);
	return calc;
}

t_mensaje_nuevo_nodo* create_mensaje_nuevo_nodo(void){
	t_mensaje_nuevo_nodo* msjeNodo = malloc(sizeof(t_mensaje_nuevo_nodo));
	msjeNodo->bloques_totales = obtener_bloques_totales_nodo();
	msjeNodo->datanode_id = obtener_id_nodo(datanode_cfg->nombre_nodo);
	msjeNodo->ip_nodo = string_new();
	string_append(&msjeNodo->ip_nodo,datanode_cfg->ip_worker);
	msjeNodo->puerto_worker = datanode_cfg->puerto_worker;
	msjeNodo->ip_nodo_size = string_length(datanode_cfg->ip_worker);
	return msjeNodo;
}


int enviar_datos_del_nodo(int sock_fd){
	int rta;
	log_trace(datanode_log, "enviar_datos_del_nodo->init");
	t_mensaje_HEADER* msjeHeader = malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_nuevo_nodo* msjeNuevoNodo= create_mensaje_nuevo_nodo();
	log_trace(datanode_log, "enviar_datos_del_nodo->se envia header nuevo nodo");
	msjeHeader->codigoMensaje = DATANODE_NUEVO_NODO;
	msjeHeader->tamanio = sizeof(typeof(msjeNuevoNodo->bloques_totales))+sizeof(typeof(msjeNuevoNodo->puerto_worker))+sizeof(typeof(msjeNuevoNodo->ip_nodo_size))+sizeof(typeof(msjeNuevoNodo->datanode_id))+(sizeof(char)*msjeNuevoNodo->ip_nodo_size);
	if (!enviar_mensaje_header(msjeHeader,sock_fd)){
		free(msjeNuevoNodo->ip_nodo);
		free(msjeNuevoNodo);
		free(msjeHeader);
		log_error(datanode_log, "enviar_datos_del_nodo->Error al enviar header nuevo nodo");
		return 0;
	}
	log_trace(datanode_log, "enviar_datos_del_nodo->se envia msjeNuevoNodo creado");
	if (!enviar_mensaje_nuevo_nodo(msjeNuevoNodo,sock_fd)){
		free(msjeNuevoNodo->ip_nodo);
		free(msjeNuevoNodo);
		log_error(datanode_log, "enviar_datos_del_nodo->Error al enviar los datos de msjeNuevoNodo");
		return 0;
	}
	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "enviar_datos_del_nodo->datos de msjeNuevoNodo enviados");
	pthread_mutex_unlock(&mutex_datanode_log);

	if (!recibir_mensaje_header(msjeHeader,sock_fd)){
		free(msjeNuevoNodo->ip_nodo);
		free(msjeNuevoNodo);
		free(msjeHeader);
		log_error(datanode_log, "enviar_datos_del_nodo->Error al recibir respuesta de msjeNuevoNodo");
		return 0;
	}

	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "enviar_datos_del_nodo->respuesta de nuevo nodo recibida");
	pthread_mutex_unlock(&mutex_datanode_log);

	if (msjeHeader->codigoMensaje == DATANODE_NUEVO_NODO_ACEPTADO) {
		rta = 1;
		pthread_mutex_lock(&mutex_datanode_log);
		log_trace(datanode_log, "enviar_datos_del_nodo->nuevo nodo aceptado en el sistema");
		pthread_mutex_unlock(&mutex_datanode_log);
	} else {
		rta = 0;
		pthread_mutex_lock(&mutex_datanode_log);
		log_trace(datanode_log, "enviar_datos_del_nodo->nodo no aceptado en el sistema");
		pthread_mutex_unlock(&mutex_datanode_log);
	}
	free(msjeHeader);
	free(msjeNuevoNodo->ip_nodo);
	free(msjeNuevoNodo);
	log_trace(datanode_log, "enviar_datos_del_nodo->end");
	return rta;
}

int enviar_handsake_filesystem(int sock_fd) {
	int rta;
	t_mensaje_HANDSHAKE* msjeHandshake = malloc(sizeof(t_mensaje_HANDSHAKE));
	msjeHandshake->codigoHandshake = HANDSHAKE_DATANODE;
	log_trace(datanode_log, "enviar_handsake_filesystem()->init");
	if (!enviar_handshake(msjeHandshake, sock_fd)){
		free(msjeHandshake);
		return 0;
	}

	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "enviar_handsake_filesystem()->handshake enviado");
	pthread_mutex_unlock(&mutex_datanode_log);

	if (!recibir_handshake(msjeHandshake, sock_fd)){
		free(msjeHandshake);
		return 0;
	}

	pthread_mutex_lock(&mutex_datanode_log);
	log_trace(datanode_log, "enviar_handsake_filesystem()->respuesta de handshake recibida");
	pthread_mutex_unlock(&mutex_datanode_log);

	if (msjeHandshake->codigoHandshake == HANDSHAKE_DATANODE) {
		rta = 1;
		pthread_mutex_lock(&mutex_datanode_log);
		log_trace(datanode_log, "enviar_handsake_filesystem()->handshake correcto, conexion aceptada");
		pthread_mutex_unlock(&mutex_datanode_log);
	} else {
		rta = 0;
		pthread_mutex_lock(&mutex_datanode_log);
		log_trace(datanode_log, "enviar_handsake_filesystem()->handshake incorrecto, se interrumpe la conexion");
		pthread_mutex_unlock(&mutex_datanode_log);
	}

	free(msjeHandshake);
	log_trace(datanode_log, "enviar_handsake_filesystem()->end");
	return rta;
}

char* leer_bloque_databin(int numero_bloque,int data_size){
	return get_file_block(pmap_fs,numero_bloque,BLOCK_SIZE,data_size,datanode_log);
}

void escribir_bloque_databin(int numero_bloque,char* data,int data_size){
	write_file_block(pmap_fs,numero_bloque,BLOCK_SIZE,data,data_size,datanode_log);
	return;
}
/*
void test_escribir_varias_veces_bloque(){
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-init");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-1");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-2");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-3");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-4");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-5");
	escribir_bloque_databin(0,"HOLAHOLAHOLAHOLA");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-6");
	log_trace(datanode_log,"test_escribir_varias_veces_bloque-end");
}*/

void manejarPeticionesFilesystem(int socketfilesystem) {
	pthread_mutex_lock(&mutex_datanode_log);
	pthread_mutex_unlock(&mutex_datanode_log);
	t_mensaje_HEADER* mensaje_header;
	t_mensaje_leer_escribir_nodo* mensaje_leer_escribir;
	char* resultado_lectura;
	char* buffer;
	int msjLargo=0;
	while (1) {
		log_trace(datanode_log, "Manejar Peticiones Filesystem - Esperando mensajes....");
		mensaje_header = malloc(sizeof(t_mensaje_HEADER));
		if (!recibir_mensaje_header(mensaje_header, socketfilesystem)) {
			pthread_mutex_lock(&mutex_datanode_log);
			log_error(datanode_log, "manejarPeticionesFilesystem-> Error en Recibir el Mensaje Header");
			pthread_mutex_unlock(&mutex_datanode_log);
			if (!socket_close(socketfilesystem)) {
				pthread_mutex_lock(&mutex_datanode_log);
				log_error(datanode_log, "manejarPeticionesFilesystem -> Error al cerrar el socket");
				pthread_mutex_unlock(&mutex_datanode_log);
			}
			free(mensaje_header);
			break;
		}else{

			switch (mensaje_header->codigoMensaje) {
			case DATANODE_ESCRIBIR_BLOQUE:
				buffer = malloc(mensaje_header->tamanio);
				log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_ESCRIBIR_BLOQUE --> init.");
				if(recvall(socket_filesystem, buffer, mensaje_header->tamanio)){
					mensaje_leer_escribir = deserializarLeerEscribirNodo_COPIA(buffer);
					escribir_bloque_databin(mensaje_leer_escribir->bloque_id,mensaje_leer_escribir->buff_bloque,mensaje_leer_escribir->buff_bloque_size);
					free(mensaje_leer_escribir->buff_bloque);
				}
				free(mensaje_header);
				free(mensaje_leer_escribir);
				free(buffer);
				log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_ESCRIBIR_BLOQUE --> end.");
				break;
			case DATANODE_LEER_BLOQUE:
				log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE --> init.");
				buffer = malloc(mensaje_header->tamanio);
				if(recvall(socket_filesystem, buffer, mensaje_header->tamanio)){
					mensaje_leer_escribir = deserializarLeer(buffer);
					log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE --> se pide leer el bloque %d.",mensaje_leer_escribir->bloque_id);
					resultado_lectura=leer_bloque_databin(mensaje_leer_escribir->bloque_id,mensaje_leer_escribir->buff_bloque_size);
					mensaje_leer_escribir->buff_bloque = malloc(mensaje_leer_escribir->buff_bloque_size);
					memcpy(mensaje_leer_escribir->buff_bloque,resultado_lectura,mensaje_leer_escribir->buff_bloque_size);
					//mensaje_leer_escribir->buff_bloque = string_new();
					//string_append(&mensaje_leer_escribir->buff_bloque,resultado_lectura);
					//tengo la data del bloque pedido, lo envio al filesystem
					char* msjeLeer = serializarLeerEscribirNodo_COPIA(mensaje_leer_escribir, &msjLargo);
					mensaje_header->tamanio = msjLargo;
					if(!enviar_mensaje_header(mensaje_header,socket_filesystem)){
						log_error(datanode_log,"manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE ->error al enviar mensaje header para el filesystem");
					}else{
						log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE --> se envio mensaje header.");
						if(!sendall(socket_filesystem,msjeLeer, msjLargo)){
							log_error(datanode_log,"manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE ->error al enviar mensaje leerescribir para el filesystem");
						}
						log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE --> se envio mensaje leer escribir.");
					}
					free(mensaje_leer_escribir->buff_bloque);
					free(msjeLeer);
				}
				free(resultado_lectura);
				free(mensaje_header);
				free(mensaje_leer_escribir);
				free(buffer);
				log_trace(datanode_log, "manejarPeticionesFilesystem->DATANODE_LEER_BLOQUE --> end.");
				break;
			default:
				free(mensaje_header);
				log_error(datanode_log, "manejarPeticionesFilesystem-> Operacion desconocida");
				break;
			}
		}
	}
}

