/*
 * config.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/log.h>
#include <pthread.h>

#define PROGRAM_NAME "DATANODE_SIGNAL_TP"
#define PATH_CONFIG_DATANODE "config/datanode.cfg"
#define PATH_LOG_DATANODE "log/datanode.log"
#define CANTIDAD_PARAMETROS_CONFIG 8

//estructura config del datanode
typedef struct {
	char* ip_fs;
	int32_t puerto_fs;
	char* nombre_nodo;
	char* ip_worker;
	int32_t puerto_worker;
	int32_t puerto_datanode;
	char *ruta_databin;
	int32_t tamano_disco;
} datanode_config;

//Estructura global que contiene el archivo de configuración actual del datanode
datanode_config* datanode_cfg;
//mutex para modificar la variable global del archivo de configuracion
pthread_mutex_t mutex_datanode_cfg;
//Estructura que representa el log del proceso datanode
t_log* datanode_log;
//mutex para usar el log
pthread_mutex_t mutex_datanode_log;

/*
 * datanode_config_create:
 * genera una estructura del tipo datanode_config leyendo los parametros
 * desde el archivo de configuracion
 */
int datanode_config_create(datanode_config *config,char* config_path);

/*
 * datanode_config_destroy:
 * destruye una estructura del tipo datanode_config
 */
void datanode_config_destroy(datanode_config *config);

/*
 * log_config:
 * loguea los valores de una estructura del tipo config
 * */
void log_config(datanode_config *config);

#endif /* SRC_CONFIG_H_ */
