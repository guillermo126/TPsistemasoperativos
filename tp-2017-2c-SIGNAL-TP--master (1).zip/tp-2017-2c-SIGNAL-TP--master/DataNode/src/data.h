/*
 * data.h
 *
 *  Created on: 7/9/2017
 *      Author: utnso
 */

#ifndef SRC_DATA_H_
#define SRC_DATA_H_
#include <commons/log.h>
#include <commons/collections/list.h>
#include <pthread.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/bitarray.h>
#include <stdlib.h>
#include "src/serialize-adm.h"
#include "src/socket-adm.h"
#include "src/filesUtilities.h"
#include <stdio.h>
#include <semaphore.h>
#include <ctype.h>
#include <string.h>
#include "config.h"
#include <ftw.h>
#include <unistd.h>
#include "serializeDnode.h"
#include <sys/stat.h>

//#define BLOCK_SIZE 1024
#define BLOCK_SIZE 1048576

//Variables utilizadas para mapear el disco
struct stat fs_stat;
int fd_filesystem;
char* pmap_fs;

//Variable global que almacena el fd del proceso filesystem
int socket_filesystem;


/*
 * conectarse_a_proceso_filesystem:
 * genera un socket cliente para conectarse al proceso filesystem segun los parametros
 * que se leen de la estructura config pasada por parametro
 * Persiste el valor del socket en la variable global socket_filesystem
 * Si no puede conectarse retorna 0.
 * */
int conectarse_a_proceso_filesystem();

/*
 * enviar_handsake_filesystem:
 * envia el msje de handshake a filesystem y espera la confirmación de este.
 * Si hay un error al enviar el handshake, recibirlo o en la validacion, retorna 0.
 * */
int enviar_handsake_filesystem(int sock_fd);

/*
 * enviar_datos_del_nodo:
 * envia los datos del nodo al filesystem para que lo acepte al sistema.
 * Si hay un error al enviar el mensaje, recibirlo o en la validacion, retorna 0.
 * */
int enviar_datos_del_nodo(int sock_fd);

//Funcion para inicializar el Data Bin
int initData();
//Funcion para mapear el disco
char* mapearDisco();

/*manejarPeticionesFilesystem:
 * recibe los mensajes del filesystem y ejecuta las operaciones que les solicita
 * */
void manejarPeticionesFilesystem(int socketfilesystem);

void test_escribir_varias_veces_bloque();
#endif /* SRC_DATA_H_ */
