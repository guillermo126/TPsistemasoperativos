/*
 * datanode.c
 *
 *  Created on: 3/9/2017
 *      Author: Alejandro Arancibia
 */
#include "datanode.h"

int main(int argc, char* argv[]) {
	//inicializacion estruvturas y variables globales
	datanode_cfg = malloc(sizeof(datanode_config));
	datanode_log =  log_create(PATH_LOG_DATANODE, PROGRAM_NAME, true, LOG_LEVEL_TRACE);
	//se carga la estructura de config del datanode
	if(!datanode_config_create(datanode_cfg,PATH_CONFIG_DATANODE)){
		log_error(datanode_log, "main-> Error al cargar el archivo de configuracion");
		return EXIT_FAILURE;
	}
	//logueo de config
	log_config(datanode_cfg);
	//se mapea data.bin a memoria
	if(initData()==EXIT_FAILURE){
		pthread_mutex_lock(&mutex_datanode_log);
		log_error(datanode_log, "main->No se pudo levantar el data.bin");
		pthread_mutex_unlock(&mutex_datanode_log);
		return EXIT_FAILURE;
	}

	//Se realiza conexion con filesystem
	if(!conectarse_a_proceso_filesystem()){
		log_error(datanode_log, "main->Error al conectarse con el proceso filesystem");
		return EXIT_FAILURE;
	}

	//Se realiza handshake con filesystem
	if(!enviar_handsake_filesystem(socket_filesystem)){
		log_error(datanode_log,"main->Error al realizar handshake con el proceso filesystem");
		return EXIT_FAILURE;
	}

	//Se envian los datos del nodo al FS
	if(!enviar_datos_del_nodo(socket_filesystem)){
		log_error(datanode_log,"main->Error al enviar los datos del nodo al proceso filesystem");
		return EXIT_FAILURE;
	}

	//Se crea procedimiento para atender las peticiones del FileSystem
	manejarPeticionesFilesystem(socket_filesystem);

	//liberacion de estructuras variables globales
	datanode_config_destroy(datanode_cfg);
	log_destroy(datanode_log);
	return EXIT_SUCCESS;

}

