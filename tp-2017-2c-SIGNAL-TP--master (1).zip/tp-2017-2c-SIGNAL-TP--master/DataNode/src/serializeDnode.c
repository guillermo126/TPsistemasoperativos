/*
 * serializeDnode.c
 *
 *  Created on: 14/10/2017
 *      Author: utnso
 */
#include "serializeDnode.h"

char* serialize_nuevo_nodo(t_mensaje_nuevo_nodo* mensaje_nodo, int* largo){
	char *empaquetado = malloc(sizeof(typeof(mensaje_nodo->bloques_totales))+sizeof(typeof(mensaje_nodo->puerto_worker))+sizeof(typeof(mensaje_nodo->ip_nodo_size))+sizeof(typeof(mensaje_nodo->datanode_id))+(sizeof(char)*mensaje_nodo->ip_nodo_size));
		int offset = 0;
		int size_to_send;

		size_to_send =  sizeof(mensaje_nodo->datanode_id);
		memcpy(empaquetado + offset, &(mensaje_nodo->datanode_id), size_to_send);
		offset += size_to_send;

		size_to_send =  sizeof(mensaje_nodo->puerto_worker);
		memcpy(empaquetado + offset, &(mensaje_nodo->puerto_worker), size_to_send);
		offset += size_to_send;

		size_to_send =  sizeof(mensaje_nodo->bloques_totales);
		memcpy(empaquetado + offset, &(mensaje_nodo->bloques_totales), size_to_send);
		offset += size_to_send;

		size_to_send =  sizeof(mensaje_nodo->ip_nodo_size);
		memcpy(empaquetado + offset, &(mensaje_nodo->ip_nodo_size), size_to_send);
		offset += size_to_send;

		size_to_send =  mensaje_nodo->ip_nodo_size;
		memcpy(empaquetado + offset, mensaje_nodo->ip_nodo, size_to_send);
		offset += size_to_send;

		*largo = offset;
		return empaquetado;

}

int enviar_mensaje_nuevo_nodo(t_mensaje_nuevo_nodo *mensaje_nodo, int sock_fd){
	int largo=0;
	int rta;
		char *buf=serialize_nuevo_nodo(mensaje_nodo,&largo);
		rta = sendall(sock_fd, buf, largo);
		free(buf);
		return rta;
}
