/*
 * funcionesWorkerNode.h
 *
 *  Created on: 4/9/2017
 *      Author: utnso
 */

#ifndef SRC_FUNCIONESWORKERNODE_H_
#define SRC_FUNCIONESWORKERNODE_H_

#include <sys/wait.h>

#include "config.h"

#include "commons/log.h"

#include "src/serialize-adm.h"
#include "src/socket-adm.h"
#include "src/filesUtilities.h"
#include "mapeoDatosMaster.h"

/*
 	 * Variables valor para indicar que reduccion se deserializa
*/
#define LOCAL 4
#define GLOBAL 5

/*
 	 * Variable valor para indicar tamaño de un bloque fijo
*/
//#define BLOCK_SIZE 1024
#define BLOCK_SIZE 1048576// todo cambiar para test final -> 1MB

/*
 	 * Variable valor para indicar archivo abierto o no -> 0 cerrado - 1 abierto
*/
int archivo_abierto;

/*
 	 * Variable que almacena el file en curso
*/
FILE* fpNoHost;

/*
 	 * t_workers_conectados: Estructura que contiene el socket fd de cada worker conectado al worker host (apareo global)
*/
typedef struct {
	int socket_worker_fd;
	int32_t pathnombre_largo;
	char* pathnombre;
}t_workers_conectados;

/*
 	 * t_elemento_linea: Estructura que contiene el buffer linea recibido por Worker en el apareo global
*/
typedef struct {
	char* buffer;
	uint32_t largo_buffer;
}t_elemento_linea;

/*
 	 * pmap_fs: variable global que guarda el archivo mapeado en memoria
*/
char* pmap_fs;

/*
 	 * seguirEscuchandoConexiones: variable global que indica si seguir escuchando como servidor
*/
int seguirEscuchandoConexiones;

/*
 	 * databin_file_map: variable global que almacena el mapeo del archivo data.bin
*/
char* databin_file_map;

/*
 	 * @NAME: inicializarVariablesWorker
 	 * @DESC: Funcion que inicializa todas las variables globales a utilizar en el proceso
*/
void inicializarVariablesWorker();

/*
 	 * @NAME: crearServidorMultiplexor
 	 * @DESC: Funcion que crea un servidor multiplexor para escuchar conexiones y mensajes
*/
int crearServidorMultiplexor();

/*
 	 * @NAME: nuevaConexionMaster
 	 * @DESC: Funcion que informa la conexion de un proceso Master
*/
void nuevaConexionMaster();

/*
 	 * @NAME: recibirMensajesMaster
 	 * @DESC: Funcion que recibe mensajes de Master y se fija si es conexion nueva o pedido para ejecutar una operacion
*/
int recibirMensajesMaster(int);

/*
 	 * @NAME: intercambiarHandshake
 	 * @DESC: Funcion que intercambia handshake según quien reciba como proceso
*/
int intercambiarHandshake(int);

/*
 	 * @NAME: forkearProcesoWorker
 	 * @DESC: Funcion forkea y ejecuta etapa correspondiente segun Master le indique
*/
void forkearProcesoWorker(workernode_fork_exec*);


/*
 	 * @NAME: recibirOperacionesMaster
 	 * @DESC: Funcion que recibe operaciones del Master y forkea si es necesario para ejecutar las acciones recibidas
*/
int recibirOperacionesMaster(int);

/*
 	 * @NAME: escribir_archivo_bloque
 	 * @DESC: Funcion que guarda en archivo el contenido del bloque
*/
char* escribir_archivo_bloque(char*, int32_t, int);

/*
 	 * @NAME: enviarArchivoAlFilesystem
 	 * @DESC: Funcion que se conecta con el filesystem y le envia contenido de archivo, nombre y ruta que debera tener
*/
int enviarArchivoAlFilesystem(t_msj_almacenamiento_final_fs*);

/*
 	 * @NAME: obtenerContenidoArchivoAlmacenamiento
 	 * @DESC: Funcion que segun el path que haya recibido de Master abre el archivo para obtener el contenido a enviar al filesystem
*/
t_msj_almacenamiento_final_fs* obtenerContenidoArchivoAlmacenamiento(t_msj_almacenamiento_final_worker*);

/*
 	 * @NAME: notificarAlMaster
 	 * @DESC: Funcion que notifica al proceso Master distintos mensajes segun haya salido determinada operacion-tarea
*/
int notificarAlMaster(t_mensaje_HEADER*, int);

/*
 	 * @NAME: mapearArchivo
 	 * @DESC: Funcion que mapea el archivo data.bin en memoria
*/
char* mapearArchivo();

/*
 	 * @NAME: ejecutarEtapa
 	 * @DESC: Funcion que arma parametro de system y ejecuta una etapa dinamicamente segun reciba
*/
int ejecutarEtapa(char*, char*, char*,int);

/*
 	 * @NAME: aparearContenidoArchivos
 	 * @DESC: Funcion que aparea locamente registros/bloques de archivo a procesar y devuelve el char con temporal
*/
char* aparearContenidoArchivos(t_msj_reduccion_local_worker*);

/*
 	 * @NAME: conectarseConWorkers
 	 * @DESC: Funcion que se conecta con los distintos worker para empezar el apareo global
*/
char* conectarseConWorkers(t_msj_reduccion_global_worker*);

/*
 	 * @NAME: leerLineaArchivoGlobal
 	 * @DESC: Funcion que retorna una linea del archivo de reduccion global segun donde esté parado el cursor del file*
*/
char* leerLineaArchivoGlobal(FILE*);

/*
 	 * @NAME: aparearArchivosEntreWorkers
 	 * @DESC: Funcion que se aparea globalmente sus resultados de reduccion locales con los workers conectados anteriormente
*/
char* aparearArchivosEntreWorkers(t_list*);

/*
 	 * @NAME: desconectarWorkers
 	 * @DESC: Funcion que se desconecta con los workers conectados anteriormente
*/
int desconectarWorkers(t_list*);

/*
 	 * @NAME: liberarVariablesWorker
 	 * @DESC: Funcion que libera las variables globales que se utilizaron en el proceso
*/
void liberarVariablesWorker();

/*
 	 * @NAME: dummy_func_escribir
 	 * @DESC: Funcion dummy de escritura, para multiplexar
*/
void dummy_func_escribir(int);

/*
 	 * @NAME: logDebugTransformacion
 	 * @DESC: Funcion que loguea en trace debug los datos de transformacion recibidos por Master
*/
void logDebugTransformacion(t_msj_transformacion_worker*);

/*
 	 * @NAME: logDebugReduccionLocal
 	 * @DESC: Funcion que loguea en trace debug los datos de reduccion local recibidos por Master
*/
void logDebugReduccionLocal(t_msj_reduccion_local_worker*);

/*
 	 * @NAME: logDebugReduccionGlobal
 	 * @DESC: Funcion que loguea en trace debug los datos de reduccion global recibidos por Master
*/
void logDebugReduccionGlobal(t_msj_reduccion_global_worker*);

/*
 	 * @NAME: logDebugAlmacenamientoFinal
 	 * @DESC: Funcion que loguea en trace debug los datos del almacenamiento final recibidos por Master
*/
void logDebugAlmacenamientoFinal(t_msj_almacenamiento_final_worker*);

#endif /* SRC_FUNCIONESWORKERNODE_H_ */
