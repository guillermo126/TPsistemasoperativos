/*
 * workernode.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#include "workernode.h"

int main(int argc, char* argv[]) {

	//Se inicializan las variables a utilizar en el proceso Worker
	inicializarVariablesWorker();

	//Se carga la estructura de config del workernode
	if(!workernode_config_create(workernode_cfg, PATH_CONFIG_WORKERNODE)){
		log_error(workernode_log, "workernode-> main: Error al cargar el archivo de configuracion.");
		liberarVariablesWorker();
		return EXIT_FAILURE;
	}

	//Se mapea el archivo data.bin en memoria
	if(mapearArchivo() == NULL){
		log_error(workernode_log, "workernode-> main: No se pudo mapear data.bin");
		liberarVariablesWorker();
		return EXIT_FAILURE;
	}

	//Se crea un socket multiplexing de tipo servidor para escuchar al proceso Master
	if(crearServidorMultiplexor()==0){
		log_error(workernode_log, "workernode-> main: Error al crear el servidor multiplexor del Worker.");
		liberarVariablesWorker();
	    return EXIT_FAILURE;
	}else{
		log_info(workernode_log, "workernode-> main: Servidor multiplexor del Worker creado correctamente.");
	}

	//Se liberan estructuras y variables globales
	liberarVariablesWorker();

	return EXIT_SUCCESS;
}
