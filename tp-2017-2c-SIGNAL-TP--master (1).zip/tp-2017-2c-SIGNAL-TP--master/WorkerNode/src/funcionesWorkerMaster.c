/*
 * funcionesWorkerMaster.c
 *
 *  Created on: 13/9/2017
 *      Author: utnso
 */

#include "funcionesWorkerMaster.h"
#include "config.h"

bool esProcesoAceptado(master_aceptado* master){
	if(master->sock_fd == socket_lectura_master){
		return true;
	}else{
		return false;
	}
}

int buscarEnProcesosConectados(int sock_fd){
	socket_lectura_master = sock_fd;
	t_list* master_encontrado = list_filter(worker_master_aceptados, (void*)esProcesoAceptado);

	if(list_is_empty(master_encontrado)){
		log_trace(workernode_log, "funcionesWorkerMaster-> buscarEnProcesosConectados: No se encontro el proceso en la lista de conectados.");
		list_clean(master_encontrado);
		list_destroy(master_encontrado);
		return 0;
	}else{
		log_trace(workernode_log, "funcionesWorkerMaster-> buscarEnProcesosConectados: Se encontro el proceso en la lista de conectados.");
		list_clean(master_encontrado);
		list_destroy(master_encontrado);
		return 1;
	}

}

master_aceptado* processCreate(int sock){
	master_aceptado* nuevo_master = malloc(sizeof(master_aceptado));
	nuevo_master->sock_fd = sock;
	return nuevo_master;
}

void aceptarProceso(int sock_fd){
	list_add(worker_master_aceptados, processCreate(sock_fd));

	log_trace(workernode_log, "funcionesWorkerMaster-> aceptarProceso: Se ingresa proceso al sistema.");
	log_trace(workernode_log, "funcionesWorkerMaster-> aceptarProceso: Cantidad de procesos activos en el sistema: %d", list_size(worker_master_aceptados));
}

void processDestroy(master_aceptado* master) {
	free(master);
}

void eliminarProceso(int sock_fd){
	list_remove_and_destroy_by_condition(worker_master_aceptados, (void*)esProcesoAceptado, (void*)processDestroy);
	log_trace(workernode_log,"funcionesWorkerMaster-> eliminarProceso: Se elimino al proceso %d del sistema",sock_fd);
	log_trace(workernode_log, "funcionesWorkerMaster-> eliminarProceso: Cantidad de procesos activos en el sistema: %d",list_size(worker_master_aceptados));
}
