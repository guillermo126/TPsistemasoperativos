/*
 * serializacionMensajes.c
 *
 *  Created on: 11/9/2017
 *      Author: utnso
 */

#include "serializacionMensajes.h"

t_msj_transformacion_worker* deserializarMensajeTransformacionWorker(char* buffer){
	t_msj_transformacion_worker* desempaquetado = malloc(sizeof(t_msj_transformacion_worker));
	int offset = 0, tmp_len = 0;

	memcpy(&desempaquetado->bloqueATransformar, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->bloqueATransformar)));
	offset += tmp_len;

	memcpy(&desempaquetado->bloqueATransformar_tamanio, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->bloqueATransformar_tamanio)));
	offset += tmp_len;

	memcpy(&desempaquetado->scripTransformador_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->scripTransformador_largo)));
	offset += tmp_len;

	desempaquetado->scriptTransformador = malloc(desempaquetado->scripTransformador_largo + 1);
	memcpy(desempaquetado->scriptTransformador, buffer + offset, tmp_len = desempaquetado->scripTransformador_largo);
	desempaquetado->scriptTransformador[desempaquetado->scripTransformador_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->archivo_destino_transformacion_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->archivo_destino_transformacion_largo)));
	offset += tmp_len;

	desempaquetado->archivo_destino_transformacion = malloc(desempaquetado->archivo_destino_transformacion_largo + 1);
	memcpy(desempaquetado->archivo_destino_transformacion, buffer + offset, tmp_len = desempaquetado->archivo_destino_transformacion_largo);
	desempaquetado->archivo_destino_transformacion[desempaquetado->archivo_destino_transformacion_largo] = '\0';

	return desempaquetado;
}

t_msj_reduccion_local_worker* deserializarMensajeReduccionLocalWorker(char* buffer){
	t_msj_reduccion_local_worker* desempaquetado = malloc(sizeof(t_msj_reduccion_local_worker));
	desempaquetado->archivos_reduccion = list_create();
	int offset = 0, tmp_len = 0;

	memcpy(&desempaquetado->scriptReduccion_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->scriptReduccion_largo)));
	offset += tmp_len;

	desempaquetado->scriptReduccion = malloc(desempaquetado->scriptReduccion_largo + 1);
	memcpy(desempaquetado->scriptReduccion, buffer + offset, tmp_len = desempaquetado->scriptReduccion_largo);
	desempaquetado->scriptReduccion[desempaquetado->scriptReduccion_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->destino_reduccion_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->destino_reduccion_largo)));
	offset += tmp_len;

	desempaquetado->destino_reduccion = malloc(desempaquetado->destino_reduccion_largo + 1);
	memcpy(desempaquetado->destino_reduccion, buffer + offset, tmp_len = desempaquetado->destino_reduccion_largo);
	desempaquetado->destino_reduccion[desempaquetado->destino_reduccion_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->archivos_reduccion_cantidad, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->archivos_reduccion_cantidad)));
	offset += tmp_len;

	int i;

	for(i=0;i<desempaquetado->archivos_reduccion_cantidad;i++){
		t_archivo_reducir_local* archivoLocal = malloc(sizeof(t_archivo_reducir_local));

		memcpy(&archivoLocal->nombreArchivoLargo, buffer + offset, tmp_len = sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		offset += tmp_len;

		archivoLocal->nombreArchivo = malloc(archivoLocal->nombreArchivoLargo+ 1);
		memcpy(archivoLocal->nombreArchivo, buffer + offset, tmp_len = archivoLocal->nombreArchivoLargo);
		archivoLocal->nombreArchivo[archivoLocal->nombreArchivoLargo] = '\0';
		offset += tmp_len;

		list_add(desempaquetado->archivos_reduccion, archivoLocal);
	}

	return desempaquetado;
}

t_msj_reduccion_global_worker* deserializarMensajeReduccionGlobalWorker(char* buffer){
	t_msj_reduccion_global_worker* desempaquetado = malloc(sizeof(t_msj_reduccion_global_worker));
	desempaquetado->archivos_reduccion = list_create();
	int offset = 0, tmp_len = 0;

	memcpy(&desempaquetado->scriptReduccion_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->scriptReduccion_largo)));
	offset += tmp_len;

	desempaquetado->scriptReduccion = malloc(desempaquetado->scriptReduccion_largo + 1);
	memcpy(desempaquetado->scriptReduccion, buffer + offset, tmp_len = desempaquetado->scriptReduccion_largo);
	desempaquetado->scriptReduccion[desempaquetado->scriptReduccion_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->destino_reduccion_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->destino_reduccion_largo)));
	offset += tmp_len;

	desempaquetado->destino_reduccion = malloc(desempaquetado->destino_reduccion_largo + 1);
	memcpy(desempaquetado->destino_reduccion, buffer + offset, tmp_len = desempaquetado->destino_reduccion_largo);
	desempaquetado->destino_reduccion[desempaquetado->destino_reduccion_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->archivos_reduccion_cantidad, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->archivos_reduccion_cantidad)));
	offset += tmp_len;

	int i;

	for(i=0;i<desempaquetado->archivos_reduccion_cantidad;i++){
		t_archivo_reducir_global* archivoLocal = malloc(sizeof(t_archivo_reducir_global));

		memcpy(&archivoLocal->nombreArchivoLargo, buffer + offset, tmp_len = sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		offset += tmp_len;

		archivoLocal->nombreArchivo = malloc(archivoLocal->nombreArchivoLargo + 1);
		memcpy(archivoLocal->nombreArchivo, buffer + offset, tmp_len = archivoLocal->nombreArchivoLargo);
		archivoLocal->nombreArchivo[archivoLocal->nombreArchivoLargo] = '\0';
		offset += tmp_len;

		memcpy(&archivoLocal->nodo_ip_largo, buffer + offset, tmp_len = sizeof(typeof(archivoLocal->nodo_ip_largo)));
		offset += tmp_len;

		archivoLocal->nodo_ip = malloc(archivoLocal->nodo_ip_largo + 1);
		memcpy(archivoLocal->nodo_ip, buffer + offset, tmp_len = archivoLocal->nodo_ip_largo);
		archivoLocal->nodo_ip[archivoLocal->nodo_ip_largo] = '\0';
		offset += tmp_len;

		memcpy(&archivoLocal->nodo_puerto_largo, buffer + offset, tmp_len = sizeof(typeof(archivoLocal->nodo_puerto_largo)));
		offset += tmp_len;

		archivoLocal->nodo_puerto = malloc(archivoLocal->nodo_puerto_largo + 1);
		memcpy(archivoLocal->nodo_puerto, buffer + offset, tmp_len = archivoLocal->nodo_puerto_largo);
		archivoLocal->nodo_puerto[archivoLocal->nodo_puerto_largo] = '\0';
		offset += tmp_len;

		list_add(desempaquetado->archivos_reduccion, archivoLocal);
	}

	return desempaquetado;
}

t_msj_almacenamiento_final_worker* deserializarAlmacenamientoFinalWorker(char* buffer){
	t_msj_almacenamiento_final_worker* desempaquetado = malloc(sizeof(t_msj_almacenamiento_final_worker));
	int offset = 0, tmp_len = 0;

	memcpy(&desempaquetado->archivo_almacenamiento_final_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->archivo_almacenamiento_final_largo)));
	offset += tmp_len;

	desempaquetado->archivo_almacenamiento_final = malloc(desempaquetado->archivo_almacenamiento_final_largo + 1);
	memcpy(desempaquetado->archivo_almacenamiento_final, buffer + offset, tmp_len = desempaquetado->archivo_almacenamiento_final_largo);
	desempaquetado->archivo_almacenamiento_final[desempaquetado->archivo_almacenamiento_final_largo] = '\0';
	offset += tmp_len;

	memcpy(&desempaquetado->archivo_reduccion_global_largo, buffer + offset, tmp_len = sizeof(typeof(desempaquetado->archivo_reduccion_global_largo)));
	offset += tmp_len;

	desempaquetado->archivo_reduccion_global = malloc(desempaquetado->archivo_reduccion_global_largo + 1);
	memcpy(desempaquetado->archivo_reduccion_global, buffer + offset, tmp_len = desempaquetado->archivo_reduccion_global_largo);
	desempaquetado->archivo_reduccion_global[desempaquetado->archivo_reduccion_global_largo] = '\0';

	return desempaquetado;
}


char* serializarAlmacenamientoFinal(t_msj_almacenamiento_final_fs* mensajeFS, int* largo){
	char *empaquetado = malloc(sizeof(typeof(mensajeFS->path_archivo_largo)) +
					    (sizeof(char)*mensajeFS->path_archivo_largo) +
						(sizeof(char)*mensajeFS->contenido_archivo_largo) +
						sizeof(typeof(mensajeFS->contenido_archivo_largo)));

	int offset = 0, tmp_size = 0;

	tmp_size =  sizeof(mensajeFS->path_archivo_largo);
	memcpy(empaquetado + offset, &(mensajeFS->path_archivo_largo), tmp_size);
	offset += tmp_size;

	tmp_size =  mensajeFS->path_archivo_largo;
	memcpy(empaquetado + offset, mensajeFS->path_archivo, tmp_size);
	offset += tmp_size;

	tmp_size =  sizeof(mensajeFS->contenido_archivo_largo);
	memcpy(empaquetado + offset, &(mensajeFS->contenido_archivo_largo), tmp_size);
	offset += tmp_size;

	tmp_size =  mensajeFS->contenido_archivo_largo;
	memcpy(empaquetado + offset, mensajeFS->contenido_archivo, tmp_size);
	offset += tmp_size;

	*largo = offset;

	return empaquetado;
}
