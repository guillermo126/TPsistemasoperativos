/*
 * MapeoDatosMaster.c
 *
 *  Created on: 9/11/2017
 *      Author: utnso
 */

#include "mapeoDatosMaster.h"
#include "config.h"

workernode_fork_exec* mapearDatosForkeoTransformacion(t_msj_transformacion_worker* tw, char* path,int socket, t_mensaje_HEADER* msjHeader){
	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoTransformacion: init mapearDatosForkeoTransformacion");

	workernode_fork_exec* wfe = malloc(sizeof(workernode_fork_exec));
	wfe->dato_origen = string_new();
	string_append(&wfe->dato_origen, path);
	wfe->bloque_nro = tw->bloqueATransformar;
	wfe->dato_destino = string_new();
	string_append(&wfe->dato_destino, tw->archivo_destino_transformacion);
	wfe->mensajeHeader = malloc(sizeof(t_mensaje_HEADER));
	wfe->mensajeHeader->codigoMensaje = msjHeader->codigoMensaje;
	wfe->mensajeHeader->tamanio = msjHeader->tamanio;
	wfe->script = string_new();
	char* script_temporal = almacenarScript(tw->scriptTransformador, tw->scripTransformador_largo, EJECUTAR_TRANSFORMACION);
	string_append(&wfe->script, script_temporal);
	wfe->socket_fd = socket;
	wfe->tipoEtapa = EJECUTAR_TRANSFORMACION;

	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoTransformacion: end mapearDatosForkeoTransformacion");

	free(script_temporal);

	return wfe;
}

workernode_fork_exec* mapearDatosForkeoReduccionLocal(t_msj_reduccion_local_worker* rlw, char* origen, int socket, t_mensaje_HEADER* msjHeader){
	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoReduccionLocal: init mapearDatosForkeoReduccionLocal");

	workernode_fork_exec* wfe = malloc(sizeof(workernode_fork_exec));
	wfe->dato_origen = string_new();
	string_append(&wfe->dato_origen, origen);
	wfe->bloque_nro = 0;
	wfe->dato_destino = string_new();
	string_append(&wfe->dato_destino, rlw->destino_reduccion);
	wfe->mensajeHeader = malloc(sizeof(t_mensaje_HEADER));
	wfe->mensajeHeader->codigoMensaje = msjHeader->codigoMensaje;
	wfe->mensajeHeader->tamanio = msjHeader->tamanio;
	wfe->script = string_new();
	char* script_temporal = almacenarScript(rlw->scriptReduccion, rlw->scriptReduccion_largo, EJECUTAR_REDUCCION_LOCAL);
	string_append(&wfe->script, script_temporal);
	wfe->socket_fd = socket;
	wfe->tipoEtapa = EJECUTAR_REDUCCION_LOCAL;

	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoReduccionLocal: end mapearDatosForkeoReduccionLocal");

	free(script_temporal);

	return wfe;

}

workernode_fork_exec* mapearDatosForkeoReduccionGlobal(t_msj_reduccion_global_worker* rgw, char* origen, int socket, t_mensaje_HEADER* msjHeader){

	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoReduccionGlobal: init mapearDatosForkeoReduccionGlobal");

	workernode_fork_exec* wfe = malloc(sizeof(workernode_fork_exec));
	wfe->dato_origen = string_new();
	string_append(&wfe->dato_origen, origen);
	wfe->bloque_nro = 0;
	wfe->dato_destino = string_new();
	string_append(&wfe->dato_destino, rgw->destino_reduccion);
	wfe->mensajeHeader = malloc(sizeof(t_mensaje_HEADER));
	wfe->mensajeHeader->codigoMensaje = msjHeader->codigoMensaje;
	wfe->mensajeHeader->tamanio = msjHeader->tamanio;
	wfe->script = string_new();
	char* script_temporal = almacenarScript(rgw->scriptReduccion, rgw->scriptReduccion_largo, EJECUTAR_REDUCCION_GLOBAL);
	string_append(&wfe->script, script_temporal);
	wfe->socket_fd = socket;
	wfe->tipoEtapa = EJECUTAR_REDUCCION_GLOBAL;

	log_info(workernode_log, "funcionesWorkerNode-> mapearDatosForkeoReduccionGlobal: end mapearDatosForkeoReduccionGlobal");

	free(script_temporal);

	return wfe;
}


char* almacenarScript(char* script, int script_largo, int etapa){

	log_info(workernode_log, "funcionesWorkerNode-> almacenarScript: init almacenarScript");

	char* archivo_path = string_new();

	string_append(&archivo_path, "temp/scripts/");
	string_append(&archivo_path, "script_");

	if(etapa == 1){
		string_append(&archivo_path, "transformacion");
	}else if(etapa == 2){
		string_append(&archivo_path, "reduccion_local");
	}else if(etapa == 3){
		string_append(&archivo_path, "reduccion_global");
	}

	char* contador_char = string_itoa(contador_file_scripts);

	string_append(&archivo_path, contador_char);
	string_append(&archivo_path, EXTENSION);

	log_debug(workernode_log, "funcionesWorkerNode-> almacenarScript: archivo_path -> etapa: %s", archivo_path);

	FILE* f_exec = fopen(archivo_path, "w");

	fwrite(script, script_largo, 1, f_exec);

	contador_file_scripts++;

	fclose(f_exec);

	free(contador_char);

	log_info(workernode_log, "funcionesWorkerNode-> almacenarScript: end almacenarScript");

	return archivo_path;
}
