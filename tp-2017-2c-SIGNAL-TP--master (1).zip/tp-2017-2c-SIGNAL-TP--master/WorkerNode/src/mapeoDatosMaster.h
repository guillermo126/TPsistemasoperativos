/*
 * mapeoDatosMaster.h
 *
 *  Created on: 9/11/2017
 *      Author: utnso
 */

#ifndef SRC_MAPEODATOSMASTER_H_
#define SRC_MAPEODATOSMASTER_H_

#include "src/serialize-adm.h"
#include <stdio.h>
#include <sys/stat.h>

/*
 	 * Variables valor para indicar que etapa se va a ejecutar en el proceso
*/
#define EJECUTAR_TRANSFORMACION 1
#define EJECUTAR_REDUCCION_LOCAL 2
#define EJECUTAR_REDUCCION_GLOBAL 3

/*
 	 * contador_file_scripts: Variable para indicar que nro de archivo ponerle al temporal donde se guarda el script
*/
int contador_file_scripts;

/*
 	 * EXTENSION: Variable para indicar que extension ponerle al temporal donde se guarda el script
*/
char* EXTENSION;

/*
 	 * workernode_fork_exec: Estructura que contiene los parametros para ejecutar etapa dentro del fork
*/
typedef struct {
	t_mensaje_HEADER* mensajeHeader;
	int socket_fd;
	char* dato_origen;
	int32_t bloque_nro;
	char* script;
	char* dato_destino;
	int tipoEtapa;
} workernode_fork_exec;

/*
 	 * @NAME: mapearDatosForkeoTransformacion
 	 * @DESC: Funcion que mapea info transformacion enviada por Master a variable que usa Worker para ejecutar en fork
*/
workernode_fork_exec* mapearDatosForkeoTransformacion(t_msj_transformacion_worker*, char*, int, t_mensaje_HEADER*);

/*
 	 * @NAME: mapearDatosForkeoReduccionLocal
 	 * @DESC: Funcion que mapea info reduccion local enviada por Master a variable que usa Worker para ejecutar en fork
*/
workernode_fork_exec* mapearDatosForkeoReduccionLocal(t_msj_reduccion_local_worker*, char*, int, t_mensaje_HEADER*);

/*
 	 * @NAME: mapearDatosForkeoReduccionGlobal
 	 * @DESC: Funcion que mapea info reduccion global enviada por Master a variable que usa Worker para ejecutar en fork
*/
workernode_fork_exec* mapearDatosForkeoReduccionGlobal(t_msj_reduccion_global_worker*, char*, int, t_mensaje_HEADER*);

/*
 	 * @NAME: almacenarScript
 	 * @DESC: Funcion que mapea el contenido script recibido de Master a un archivo para poder ejecutar mediante System
*/
char* almacenarScript(char*, int, int);

#endif /* SRC_MAPEODATOSMASTER_H_ */
