/*
 * config.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#include "config.h"

t_config* tConfig;

int workernode_config_create(workernode_config *config, char* config_path){
	t_config *cfg_config;
	cfg_config = config_create(config_path);

	if(cfg_config == NULL){
		log_error(workernode_log, "config-> workernode_config_create: No se pudo acceder al archivo de config.");
		return 0;
	}

	if(config_keys_amount(cfg_config) == CANTIDAD_PARAMETROS_CONFIG){
		if(config_has_property(cfg_config, "IP_FILESYSTEM")){
			config->ip_fs = string_new();
			string_append(&config->ip_fs,config_get_string_value(cfg_config, "IP_FILESYSTEM"));
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro IP_FILESYSTEM.");
			return 0;
		}

		if(config_has_property(cfg_config, "PUERTO_FILESYSTEM")){
			config->puerto_fs = config_get_int_value(cfg_config, "PUERTO_FILESYSTEM");
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro PUERTO_FILESYSTEM.");
			return 0;
		}

		if(config_has_property(cfg_config, "NOMBRE_NODO")){
			config->nombre_nodo = string_new();
			string_append(&config->nombre_nodo,config_get_string_value(cfg_config, "NOMBRE_NODO"));
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro NOMBRE_NODO.");
			return 0;
		}

		if(config_has_property(cfg_config, "PUERTO_WORKER")){
			config->puerto_worker = config_get_int_value(cfg_config, "PUERTO_WORKER");
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro PUERTO_WORKER.");
			return 0;
		}

		if(config_has_property(cfg_config, "PUERTO_DATANODE")){
			config->puerto_datanode = config_get_int_value(cfg_config, "PUERTO_DATANODE");
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro PUERTO_DATANODE.");
			return 0;
		}

		if(config_has_property(cfg_config, "RUTA_DATABIN")){
			config->ruta_databin = string_new();
			string_append(&config->ruta_databin,config_get_string_value(cfg_config, "RUTA_DATABIN"));
		}else{
			log_error(workernode_log, "config-> workernode_config_create: Falta el parametro RUTA_DATABIN.");
			return 0;
		}
	}else{
		log_error(workernode_log, "config-> workernode_config_create: El archivo de configuracion no tiene todos los parametros necesarios.");
		return 0;
	}

	log_trace(workernode_log, "config-> workernode_config_create: Se ha cargado el archivo de configuracion del workernode exitosamente.");

	log_config(config);

	config_destroy(cfg_config);

	return 1;
}

void workernode_config_destroy(workernode_config *config){
	free(config);
	log_trace(workernode_log, "config-> workernode_config_destroy: Estructura workernode_cfg liberada exitosamente.");
}

void log_config(workernode_config *config){
	log_trace(workernode_log,"----- Archivo de configuracion del proceso workernode -----\n");
	log_trace(workernode_log,"IP_FILESYSTEM: %s\n",config->ip_fs);
	log_trace(workernode_log,"PUERTO_FILESYSTEM: %d\n",config->puerto_fs);
	log_trace(workernode_log,"NOMBRE_NODO: %s\n",config->nombre_nodo);
	log_trace(workernode_log,"PUERTO_WORKER: %d\n",config->puerto_worker);
	log_trace(workernode_log,"PUERTO_DATANODE: %d\n",config->puerto_datanode);
	log_trace(workernode_log,"RUTA_DATABIN: %s\n",config->ruta_databin);
	log_trace(workernode_log,"----- Fin archivo de configuracion del proceso workernode -----\n");
}
