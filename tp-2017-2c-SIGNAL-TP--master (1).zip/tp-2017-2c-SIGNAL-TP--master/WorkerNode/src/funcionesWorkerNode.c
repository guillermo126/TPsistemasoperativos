/*
 * funcionesWorkerNode.c
 *
 *  Created on: 4/9/2017
 *      Author: utnso
 */

#include "funcionesWorkerNode.h"
#include "serializacionMensajes.h"
#include "funcionesWorkerMaster.h"

void inicializarVariablesWorker(){
	workernode_cfg = malloc(sizeof(workernode_config));
	workernode_log = log_create(PATH_LOG_WORKERNODE, PROGRAM_NAME, true, LOG_LEVEL_TRACE);

	if(pthread_mutex_init(&mutex_workernode_log, NULL) != 0){
		log_error(workernode_log, "funcionesWorkerNode-> inicializarVariablesWorker: Error al inicializar mutex log.");
	}

	EXTENSION = string_new();
	string_append(&EXTENSION, ".py");

	contador_file_scripts = 0;
	seguirEscuchandoConexiones = 1;

	worker_master_aceptados = list_create();

	log_trace(workernode_log, "funcionesWorkerNode-> inicializarVariablesWorker: Variables globales del proceso inicializadas.");
}

int crearServidorMultiplexor(){
	int socket_server = socket_multiplexing("127.0.0.1",string_itoa(workernode_cfg->puerto_worker),50,&nuevaConexionMaster,&recibirMensajesMaster,&dummy_func_escribir,workernode_log);
	return socket_server;
}


void nuevaConexionMaster(){
	log_trace(workernode_log, "funcionesWorkerNode-> nuevaConexionMaster: Se recibio una conexion nueva.");
}

int recibirMensajesMaster(int socket_fd){
	if(buscarEnProcesosConectados(socket_fd)){
		if(recibirOperacionesMaster(socket_fd)==0){
			return 0;
		}
	}else{
		log_trace(workernode_log, "funcionesWorkerNode-> recibirMensajesMaster: Se procede a realizar el handshake.");
		if(intercambiarHandshake(socket_fd)){
			aceptarProceso(socket_fd);
		}else{
			log_error(workernode_log, "funcionesWorkerNode-> recibirMensajesMaster: Error al intercambiar handshake.");
		}
	}
	return 1;
}

int intercambiarHandshake(int sock_fd){
	t_mensaje_HANDSHAKE* mensajeHandshake = malloc(sizeof(t_mensaje_HANDSHAKE));

	if(recibir_handshake(mensajeHandshake, sock_fd)){
		switch(mensajeHandshake->codigoHandshake){
			case HANDSHAKE_MASTER:
				log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se recibio mensaje HANDSHAKE_MASTER.");
				mensajeHandshake->codigoHandshake = HANDSHAKE_WORKER;
				if(enviar_handshake(mensajeHandshake, sock_fd)){
					log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se envio mensaje HANDSHAKE_WORKER correctamente.");
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Error al enviar mensaje handshake.");
					free(mensajeHandshake);
					return 0;
				}
			break;
			case HANDSHAKE_WORKER:
				log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se recibio mensaje HANDSHAKE_WORKER.");
				mensajeHandshake->codigoHandshake = HANDSHAKE_WORKER;
				if(enviar_handshake(mensajeHandshake, sock_fd)){
					log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se envio mensaje HANDSHAKE_WORKER correctamente.");
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Error al enviar mensaje handshake.");
					free(mensajeHandshake);
					return 0;
				}
				break;
			case ERROR_HANDSHAKE:
				log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se recibio mensaje ERROR_HANDSHAKE.");
				free(mensajeHandshake);
				return 0;
			break;
			default:
				log_trace(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Se recibio mensaje handshake desconocido.");
				free(mensajeHandshake);
				return 0;
			break;
		}
	}else{
		log_error(workernode_log, "funcionesWorkerNode-> intercambiarHandshake: Error al recibir mensaje handshake.");
		free(mensajeHandshake);
		return 0;
	}

	free(mensajeHandshake);

	return 1;
}


void forkearProcesoWorker(workernode_fork_exec* info){
//	signal(SIGCHLD, SIG_IGN);

	int status_child1;
	pid_t pid_final;
	pid_t pid;

	switch(pid = fork()){
		case -1:
			log_error(workernode_log, "funcionesWorkerNode-> forkearProcesoWorker: Error al forkear proceso Worker.");
			break;
		case 0:
			switch(pid_final = fork()){
				case -1:
					//Error
				break;
				case 0:
					log_trace(workernode_log, "funcionesWorkerNode-> forkearProcesoWorker: Proceso hijo %d - Padre %d -> para ejecutar etapa creado correctamente.", getpid(), getppid());
					if(ejecutarEtapa(info->dato_origen, info->script, info->dato_destino, info->tipoEtapa)){
						info->mensajeHeader->codigoMensaje = WORKER_MASTER_ETAPA_OK;
					}else{
						info->mensajeHeader->codigoMensaje = WORKER_MASTER_ETAPA_FAILED;
					}
					info->mensajeHeader->tamanio = info->bloque_nro;
					notificarAlMaster(info->mensajeHeader,info->socket_fd);
					free(info->mensajeHeader);
					free(info->dato_destino);
					remove(info->dato_origen);
					free(info->dato_origen);
					remove(info->script);
					free(info->script);
					free(info);
					log_trace(workernode_log, "funcionesWorkerNode-> forkearProcesoWorker: Fin proceso hijo %d - De Padre %d", getpid(), getppid());
					exit(0);
				break;
				default:
					exit(0);
				break;
			}
			break;
		default:
			waitpid(pid, &status_child1, NULL);
			log_trace(workernode_log, "funcionesWorkerNode-> forkearProcesoWorker: Proceso padre %d vuelve a escuchar conexiones.", getpid());
			break;
	}

}


int recibirOperacionesMaster(int socket){
	char* buffer;
	t_mensaje_HEADER* mensajeHeader = malloc(sizeof(t_mensaje_HEADER));
	t_msj_transformacion_worker* info_transformacion;
	t_msj_reduccion_local_worker* info_reduccion_local;
	t_msj_reduccion_global_worker* info_reduccion_global;
	t_msj_almacenamiento_final_worker* info_almacenamiento_final;

		if(recibir_mensaje_header(mensajeHeader, socket)){
			buffer = malloc(mensajeHeader->tamanio);
			switch(mensajeHeader->codigoMensaje){
			case WORKER_MASTER_TRANSFORMACION:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio mensaje header WORKER_MASTER_TRANSFORMACION.");
				if(recvall(socket,buffer,mensajeHeader->tamanio)){
					log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio info_transformacion.");
					info_transformacion = deserializarMensajeTransformacionWorker(buffer);
				//	logDebugTransformacion(info_transformacion);
					char* bloqueOrigen = get_file_block(pmap_fs, info_transformacion->bloqueATransformar, BLOCK_SIZE, info_transformacion->bloqueATransformar_tamanio , workernode_log);
					char* path_origen_cat = escribir_archivo_bloque(bloqueOrigen, info_transformacion->bloqueATransformar_tamanio, info_transformacion->bloqueATransformar);
					workernode_fork_exec* workernode_fork_temporal_T = mapearDatosForkeoTransformacion(info_transformacion, path_origen_cat, socket, mensajeHeader);
					forkearProcesoWorker(workernode_fork_temporal_T);
					free(workernode_fork_temporal_T->dato_destino);
					free(workernode_fork_temporal_T->dato_origen);
					free(workernode_fork_temporal_T->script);
					free(workernode_fork_temporal_T->mensajeHeader);
					free(workernode_fork_temporal_T);
					free(path_origen_cat);
					free(bloqueOrigen);
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al recibir el datos de transformacion del Master.");
				}
				free(info_transformacion->archivo_destino_transformacion);
				free(info_transformacion->scriptTransformador);
				free(info_transformacion);
			break;
			case WORKER_MASTER_REDUCCION_LOCAL:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio mensaje header WORKER_MASTER_REDUCCION_LOCAL.");
				if(recvall(socket, buffer, mensajeHeader->tamanio)){
					log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio info_reduccion_local.");
					info_reduccion_local = deserializarMensajeReduccionLocalWorker(buffer);
				//	logDebugReduccionLocal(info_reduccion_local);
					char* origenEtapa = aparearContenidoArchivos(info_reduccion_local);
					workernode_fork_exec* workernode_fork_temporal_RL = mapearDatosForkeoReduccionLocal(info_reduccion_local, origenEtapa, socket, mensajeHeader);
					forkearProcesoWorker(workernode_fork_temporal_RL);
					free(workernode_fork_temporal_RL->dato_destino);
					free(workernode_fork_temporal_RL->dato_origen);
					free(workernode_fork_temporal_RL->script);
					free(workernode_fork_temporal_RL->mensajeHeader);
					free(workernode_fork_temporal_RL);
					free(origenEtapa);
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al recibir el datos de reduccion local del Master.");
				}
				free(info_reduccion_local->destino_reduccion);
				free(info_reduccion_local->scriptReduccion);
				void destruir_archivo_reduccion_local (void*data){
					t_archivo_reducir_local* arl = (t_archivo_reducir_local*) data;
					free(arl->nombreArchivo);
					free(arl);
				}
				list_destroy_and_destroy_elements(info_reduccion_local->archivos_reduccion, destruir_archivo_reduccion_local);
				free(info_reduccion_local);
			break;
			case WORKER_MASTER_REDUCCION_GLOBAL:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio mensaje header WORKER_MASTER_REDUCCION_GLOBAL.");
				if(recvall(socket, buffer, mensajeHeader->tamanio)){
					log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio info_reduccion_global.");
					info_reduccion_global = deserializarMensajeReduccionGlobalWorker(buffer);
				//	logDebugReduccionGlobal(info_reduccion_global);
					char* origenRG = NULL;
					origenRG = conectarseConWorkers(info_reduccion_global);
					if(origenRG != NULL){
						workernode_fork_exec* workernode_fork_temporal_RG = mapearDatosForkeoReduccionGlobal(info_reduccion_global,origenRG, socket, mensajeHeader);
						forkearProcesoWorker(workernode_fork_temporal_RG);
						free(workernode_fork_temporal_RG->dato_destino);
						free(workernode_fork_temporal_RG->dato_origen);
						free(workernode_fork_temporal_RG->script);
						free(workernode_fork_temporal_RG->mensajeHeader);
						free(workernode_fork_temporal_RG);
						free(origenRG);
					}else{
						mensajeHeader->codigoMensaje = WORKER_MASTER_ETAPA_FAILED;
						mensajeHeader->tamanio = 0;
						notificarAlMaster(mensajeHeader, socket);
					}
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al recibir el datos de reduccion global del Master.");
				}
				free(info_reduccion_global->destino_reduccion);
				free(info_reduccion_global->scriptReduccion);
				void destruir_archivo_reduccion_global (void*data){
					t_archivo_reducir_global* arg = (t_archivo_reducir_global*) data;
					free(arg->nombreArchivo);
					free(arg->nodo_puerto);
					free(arg->nodo_ip);
					free(arg);
				}
				list_destroy_and_destroy_elements(info_reduccion_global->archivos_reduccion, destruir_archivo_reduccion_global);
				free(info_reduccion_global);
			break;
			case WORKER_MASTER_ALMACENAMIENTO_FINAL:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio mensaje header WORKER_MASTER_ALMACENAMIENTO_FINAL.");
				if(recvall(socket, buffer, mensajeHeader->tamanio)){
					log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio info_almacenamiento_final.");
					info_almacenamiento_final = deserializarAlmacenamientoFinalWorker(buffer);
				//	logDebugAlmacenamientoFinal(info_almacenamiento_final);
					t_msj_almacenamiento_final_fs* file = obtenerContenidoArchivoAlmacenamiento(info_almacenamiento_final);
					if(enviarArchivoAlFilesystem(file)){
						log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Archivo %s enviado al FileSystem correctamente.", file->path_archivo);
						mensajeHeader->codigoMensaje = WORKER_MASTER_ETAPA_OK;
					}else{
						log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al enviar el archivo final al filesystem.");
						mensajeHeader->codigoMensaje = WORKER_MASTER_ETAPA_FAILED;
					}
					mensajeHeader->tamanio = 0;
					notificarAlMaster(mensajeHeader,socket);
					free(file->contenido_archivo);
					free(file->path_archivo);
					free(file);
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al recibir el datos de almacenamiento final del Master.");
				}
				free(info_almacenamiento_final->archivo_almacenamiento_final);
				free(info_almacenamiento_final->archivo_reduccion_global);
				free(info_almacenamiento_final);
			break;
			case WORKER_APAREO_GLOBAL:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio mensaje header WORKER_APAREO_GLOBAL.");
				recvall(socket, buffer, mensajeHeader->tamanio);
				buffer[mensajeHeader->tamanio] = '\0';
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio info para abrir el archivo de reduccion local: %s.", buffer);
				if(archivo_abierto == 0){
					fpNoHost = fopen(buffer, "r");
					if(fpNoHost == NULL){
						log_error(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Error al abrir archivo Worker: %s.", buffer);
					}else{
						archivo_abierto = 1;
					}
				}
				char* linea = leerLineaArchivoGlobal(fpNoHost);
				if(linea != NULL){
					mensajeHeader->codigoMensaje = WORKER_APAREO_LEER_LINEA;
					mensajeHeader->tamanio = string_length(linea);
					enviar_mensaje_header(mensajeHeader, socket);
					sendall(socket, linea, mensajeHeader->tamanio);
				}else{
					mensajeHeader->codigoMensaje = WORKER_APAREO_EOF;
					mensajeHeader->tamanio = 0;
					enviar_mensaje_header(mensajeHeader, socket);
					archivo_abierto = 0;
					fclose(fpNoHost);
				}
				free(linea);
				break;
			default:
				log_trace(workernode_log, "funcionesWorkerNode-> recibirOperacionesMaster: Se recibio un mensaje header desconocido.");
				break;
			}
			free(buffer);
		}else{
			free(mensajeHeader);
			return 0;
		}

	free(mensajeHeader);

	return 1;
}


char* escribir_archivo_bloque(char* bloque, int32_t datasize, int nrobloque){


	char* path_archivo_cat = string_new();

	string_append(&path_archivo_cat, "temp/Bloque");
	char* contador_numeros = string_itoa(nrobloque);
	string_append(&path_archivo_cat, contador_numeros);

	FILE* fp = fopen(path_archivo_cat,"w");

	fwrite(bloque, datasize, 1, fp);

	fclose(fp);

	free(contador_numeros);

	return path_archivo_cat;
}


int enviarArchivoAlFilesystem(t_msj_almacenamiento_final_fs* mensajeFS){
	log_info(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: init enviarArchivoAlFilesystem.");

	t_mensaje_HANDSHAKE* mensajeHandshake = malloc(sizeof(t_mensaje_HANDSHAKE));
	t_mensaje_HEADER* mensajeHeader = malloc(sizeof(t_mensaje_HEADER));

	int* msjLargo = malloc(sizeof(int32_t));
	int resultadoOperacion = 0;

	char* buffer;
	char* puerto_filesystem = string_itoa(workernode_cfg->puerto_fs);

	int socket_cliente_fs = socket_create(workernode_cfg->ip_fs, puerto_filesystem, TIPO_CLIENTE, 0, workernode_log);

	if(socket_cliente_fs != 0){
		log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Socket cliente %d creado con exito.", socket_cliente_fs);
		mensajeHandshake->codigoHandshake = HANDSHAKE_WORKER;
		if(enviar_handshake(mensajeHandshake,socket_cliente_fs)){
			log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se envio correctamente el mensaje HANDSHAKE_WORKER.");
			if(recibir_handshake(mensajeHandshake,socket_cliente_fs)){
				log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se recibio correctamente un  mensaje handshake..");
				if(mensajeHandshake->codigoHandshake == HANDSHAKE_FS){
					log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se valido correctamente el mensaje HANDSHAKE_FS.");
					buffer = serializarAlmacenamientoFinal(mensajeFS, msjLargo);
					mensajeHeader->codigoMensaje = WORKER_FS_ENVIAR_ARCHIVO;
					mensajeHeader->tamanio = *msjLargo;
					if(enviar_mensaje_header(mensajeHeader,socket_cliente_fs)){
						log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se envio correctamente el mensaje header WORKER_FS_ENVIAR_ARCHIVO.");
						if(sendall(socket_cliente_fs, buffer, mensajeHeader->tamanio)){
							log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se enviaron correctamente los datos de almacenamiento final al filesystem.");
							if(recibir_mensaje_header(mensajeHeader, socket_cliente_fs)){
								if(mensajeHeader->codigoMensaje==FS_ALMACENAMIENTO_OK){
									resultadoOperacion = 1;
									log_trace(workernode_log, "funcionesWorkerNode-> enviarArchivoFilesystem: Se recibio mensaje header FS_ALMACENAMIENTO_OK");
								}else{
									resultadoOperacion = 0;
								}
							}else{
								log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Error al recibir mensaje header WORKER_FS_ENVIAR_ARCHIVO.");
							}
						}else{
							log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Error al enviar datos de almacenamiento final al FileSystem.");
						}
					}else{
						log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Error al enviar mensaje header WORKER_FS_ENVIAR_ARCHIVO.");
					}
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Se recibio un handshake incorrecto.");
				}
			}else{
				log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Error al recibir handshake del proceso FileSystem.");
			}
		}else{
			log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: Error al enviar handshake al proceso FileSystem.");
		}
	}else{
		log_error(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: No se pudo crear el socket cliente del worker.");
	}

	free(mensajeHandshake);
	free(mensajeHeader);
	free(msjLargo);
	free(puerto_filesystem);

	log_info(workernode_log, "funcionesWorkerNode-> enviarArchivoAlFilesystem: end enviarArchivoAlFilesystem.");

	return resultadoOperacion;
}

t_msj_almacenamiento_final_fs* obtenerContenidoArchivoAlmacenamiento(t_msj_almacenamiento_final_worker* info_almacenamiento_final){
	  log_info(workernode_log, "funcionesWorkerNode-> obtenerContenidoArchivoAlmacenamiento: init obtenerContenidoArchivoAlmacenamiento");

	  t_msj_almacenamiento_final_fs* datos_file;

	  if(strcmp(info_almacenamiento_final->archivo_almacenamiento_final,"")==0){
		  log_trace(workernode_log, "funcionesWorkerNode-> obtenerContenidoArchivoAlmacenamiento: El archivo %s (nulo) no existe.",info_almacenamiento_final->archivo_almacenamiento_final);
	  }else{
		  datos_file = malloc(sizeof(t_msj_almacenamiento_final_fs));

		  char* path = string_new();
		  char* letra = malloc(sizeof(char));

		  int cantidadDeLetras = 0;

		  string_append(&path, "temp/");

		  //Se mapea el path para abrir el archivo
		  string_append(&path, info_almacenamiento_final->archivo_reduccion_global);

		  //Se abre el archivo
		  FILE* archivo = fopen(path, "r");

		  //Si hubo algun error, loguea y retorna instantaneamente
		  if(archivo==NULL){
			  log_error(workernode_log, "funcionesWorkerNode-> obtenerContenidoArchivoAlmacenamiento: No se pudo abrir el archivo %s",info_almacenamiento_final->archivo_reduccion_global);
			  if(errno == ENOENT){
				  log_trace(workernode_log, "funcionesWorkerNode-> obtenerContenidoArchivoAlmacenamiento: El archivo %s no existe.",info_almacenamiento_final->archivo_reduccion_global);
			  }
			  free(letra);
		  }else{
			  //Recorro el archivo para obtener la cantidad de letras/caracteres que contiene
			  while (!feof(archivo)) {
			   *letra = getc(archivo);
			   cantidadDeLetras++;
			  }

			  rewind(archivo);
			  cantidadDeLetras--;

			  char* mensajeAEnviar = malloc(cantidadDeLetras + 1);
			  char* datos = malloc(cantidadDeLetras);

			  //Copio el contenido del archivo en variables locales
			  fread(datos, cantidadDeLetras, 1, archivo);
			  memcpy(mensajeAEnviar, datos, cantidadDeLetras);
			  mensajeAEnviar[cantidadDeLetras] = '\0';

			  //Se asigna a la estructura los datos del script obtenidos
			  datos_file->contenido_archivo = string_new();
			  string_append(&datos_file->contenido_archivo, mensajeAEnviar);
			  datos_file->contenido_archivo_largo = cantidadDeLetras;
			  datos_file->path_archivo = string_new();
			  string_append(&datos_file->path_archivo, info_almacenamiento_final->archivo_almacenamiento_final);
			  datos_file->path_archivo_largo = info_almacenamiento_final->archivo_almacenamiento_final_largo;

			  //Se cierra el archivo
			  fclose(archivo);

			  //Libera memoria reservada
			  free(mensajeAEnviar);
			  free(datos);
			  free(letra);
			  free(path);
		  }
	  }

	  log_info(workernode_log, "funcionesWorkerNode-> obtenerContenidoArchivoAlmacenamiento: end obtenerContenidoArchivoAlmacenamiento");

	  return datos_file;
}

int notificarAlMaster(t_mensaje_HEADER* mensajeHeader, int socket){
	log_info(workernode_log, "funcionesWorkerNode-> notificarAlMaster: init notificarAlMaster");

	int resultado = 0;

	if(!enviar_mensaje_header(mensajeHeader,socket)){
		log_error(workernode_log, "funcionesWorkerNode-> notificarAlMaster: Error al notificar master resultado de la etapa.");
		resultado = 0;
	}else{
		log_trace(workernode_log, "funcionesWorkerNode-> notificarAlMaster: Resultado de etapa notificado a Master correctamente.");
		resultado = 1;
	}

	log_info(workernode_log, "funcionesWorkerNode-> notificarAlMaster: end notificarAlMaster");

	return resultado;
}

char* mapearArchivo(){

	pmap_fs = map_file(workernode_cfg->ruta_databin,workernode_log);

	if (pmap_fs == NULL) {
		log_error(workernode_log, "funcionesWorkerNode-> mapearArchivo: Error al mapear el archivo bin %s", workernode_cfg->ruta_databin);
	}

	return pmap_fs;
}

int ejecutarEtapa(char* origen, char* script, char* destino_temporal_operacion, int etapaEjecutar){
	log_info(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: init ejecutarEtapa");

	char* parametroSystem = string_new();
	char* string_permisos = string_new();

	int valorRetorno = 1;

	//Preparo string para ejecutar transformacion
	if(etapaEjecutar == 1){
		string_append(&parametroSystem, "cat ");
	}else{
		char* string_permisos_temporales = string_new();
		string_append(&string_permisos_temporales, "chmod a+rx ");
		string_append(&string_permisos_temporales, origen);
		if(system(string_permisos_temporales) == -1){
			log_error(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: Fallo la ejecucion del comando de ortorgamiento de permisos para %s", string_permisos_temporales);
			free(parametroSystem);
			free(string_permisos);
			log_info(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: end ejecutarEtapa");
			return 0;
		}else{
			log_trace(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: La ejecucion del comando de ortorgamiento de permisos fue satisfactoria para %s", string_permisos_temporales);
		}
		string_append(&parametroSystem, "cat ");
		free(string_permisos_temporales);
	}

	string_append(&parametroSystem, origen);
	string_append(&parametroSystem, " | ");

	string_append(&parametroSystem, script);
//	string_append(&parametroSystem, "/home/utnso/Escritorio/ chmod +x  script_transformacion.py");

	if(etapaEjecutar==1){
		 string_append(&parametroSystem, " | sort");
	}

	string_append(&parametroSystem, " > ");
	string_append(&parametroSystem, "temp/");
	string_append(&parametroSystem, destino_temporal_operacion);

	log_debug(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: System command: %s", parametroSystem);

	//Le doy permisos de lectura y ejecucion al script file
	string_append(&string_permisos, "chmod a+rx ");
	string_append(&string_permisos, script);

	log_debug(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: System command chmod: %s", string_permisos);

	if(system(string_permisos) == -1){
		log_error(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: Fallo la ejecucion del comando de ortorgamiento de permisos para %s", string_permisos);
		free(parametroSystem);
		free(string_permisos);
		log_info(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: end ejecutarEtapa");
		return 0;
	}else{
		log_trace(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: La ejecucion del comando de ortorgamiento de permisos fue satisfactoria para %s", string_permisos);
	}

//	system("echo hola pepe | ./script_transformacion.py > /tmp/resultado"); -> ejemplo de system
	//Se ejecuta la transformacion
	int resultado = system(parametroSystem);

	//Setea valor de retorno
	if(resultado == -1){
		log_error(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: Fallo la ejecucion del comando-etapa.");
		free(parametroSystem);
		free(string_permisos);
		log_info(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: end ejecutarEtapa");
		return 0;
	}else{
		log_trace(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: La ejecucion del comando-etapa fue satisfactoria.");
	}

	free(parametroSystem);
	free(string_permisos);

	//Se elimina el archivo con el script post-ejecucion porque quedo en desuso
	//remove(script);

	log_info(workernode_log, "funcionesWorkerNode-> ejecutarEtapa: end ejecutarEtapa");

	return valorRetorno;
}

char* aparearContenidoArchivos(t_msj_reduccion_local_worker* mensaje_reduccion_local){
	log_info(workernode_log, "funcionesWorkerNode-> aparearContenidoArchivos: init aparearContenidoArchivos");

	char* stringApareo = string_new();
	char* archivoTemporalApareado = string_new();

	//Preparo el path donde va a ser guardado el apareo que despues me sirve como entrada de la ejecucion de la etapa
	string_append(&archivoTemporalApareado, "temp/");
	string_append(&archivoTemporalApareado, "apareo_temporal_");
	string_append(&archivoTemporalApareado, mensaje_reduccion_local->destino_reduccion);

	//Concatena comando sort y archivos que va a aparear/ordenar
	string_append(&stringApareo, "sort -m ");

	int i;
	for(i=0;i<mensaje_reduccion_local->archivos_reduccion_cantidad;i++){
		t_archivo_reducir_local* archivo_local = list_get(mensaje_reduccion_local->archivos_reduccion,i);
		string_append(&stringApareo, "temp/");
		string_append(&stringApareo, archivo_local->nombreArchivo);
		string_append(&stringApareo, " ");
	}

	//Termina de orquestar el comando a ejecutar la reduccion local con system
	string_append(&stringApareo, " > ");
	string_append(&stringApareo, archivoTemporalApareado);

	log_debug(workernode_log, "funcionesWorkerNode-> aparearContenidoArchivos: System command: %s", stringApareo);

//	system("sort -m temporal.txt temporal2.txt > t.txt"): ejemplo de apareo con 2 archivos (funciona con más)
	//Ejecuta reduccion local
	if(system(stringApareo) == -1){
		log_error(workernode_log, "funcionesWorkerNode-> aparearContenidoArchivos: Fallo la ejecucion del comando de apareo local.");
	}

	free(stringApareo);

	log_info(workernode_log, "funcionesWorkerNode-> aparearContenidoArchivos: end aparearContenidoArchivos");

	return archivoTemporalApareado;
}

char* conectarseConWorkers(t_msj_reduccion_global_worker* workernode_reduccion_global){
	log_info(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: init conectarseConWorkers");

	int socket_cliente_worker;
	int i=0;
	int workerFailedConnection = 0;


	char* apareoGlobal = NULL;

	t_list* lista_workernode_conectados = list_create();
	t_mensaje_HANDSHAKE* msjHandshake = malloc(sizeof(t_mensaje_HANDSHAKE));

	//Itero y me voy conectado a los workers que me indico Master 1 a 1. Si falla la comunicacion con alguno, aborto operacion
	while(i<workernode_reduccion_global->archivos_reduccion_cantidad && workerFailedConnection!=1){
		t_archivo_reducir_global* archivo = list_get(workernode_reduccion_global->archivos_reduccion,i);
		if(archivo->nodo_ip_largo == 0 && archivo->nodo_puerto_largo == 0){
			log_info(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Se identifico worker host, no se conecta pero guarda info de archivo fs local.");
			t_workers_conectados* connected_workers_host = malloc(sizeof(t_workers_conectados));
			connected_workers_host->socket_worker_fd = -1;
			connected_workers_host->pathnombre = string_new();
			string_append(&connected_workers_host->pathnombre, archivo->nombreArchivo);
			connected_workers_host->pathnombre_largo = archivo->nombreArchivoLargo;
			list_add(lista_workernode_conectados, connected_workers_host);
		}else{
			socket_cliente_worker = socket_create(archivo->nodo_ip, archivo->nodo_puerto,TIPO_CLIENTE,0,workernode_log);
			if(socket_cliente_worker != 0){
				log_trace(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Socket cliente creado correctamente para Worker IP-> %s / Puerto-> %s", archivo->nodo_ip, archivo->nodo_puerto);
				msjHandshake->codigoHandshake = HANDSHAKE_WORKER;
				int resultado_envio = enviar_handshake(msjHandshake,socket_cliente_worker);
				int resultado_recepcion = recibir_handshake(msjHandshake, socket_cliente_worker);
				if(msjHandshake->codigoHandshake == HANDSHAKE_WORKER && resultado_envio == 1 && resultado_recepcion == 1){
					t_workers_conectados* connected_workers = malloc(sizeof(t_workers_conectados));
					connected_workers->socket_worker_fd = socket_cliente_worker;
					connected_workers->pathnombre = string_new();
					string_append(&connected_workers->pathnombre, archivo->nombreArchivo);
					connected_workers->pathnombre_largo = archivo->nombreArchivoLargo;
					list_add(lista_workernode_conectados, connected_workers);
				}else{
					log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Error de autenticacion de proceso Worker %d nuevo.", socket_cliente_worker);
					log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Se aborta la conexion con los procesos Workers.");
					workerFailedConnection++;
				}
			}else{
				log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Error al crear socket cliente para Worker IP-> %s / Puerto-> %s", archivo->nodo_ip, archivo->nodo_puerto);
				log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Se aborta la conexion con los procesos Workers.");
				list_destroy(lista_workernode_conectados);
				workerFailedConnection++;
			}
		}
		i++;
	}

	//Si falla la conexion con alguno, desconecto los workers anteriormente conectados
	if(workerFailedConnection != 0){
		if(!desconectarWorkers(lista_workernode_conectados)){
			log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Error al desconectar workers.");
		}else{
			log_trace(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Workers desconectados correctamente.");

		}
	}else{
		apareoGlobal = aparearArchivosEntreWorkers(lista_workernode_conectados);
		if(apareoGlobal != NULL){
			log_trace(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Los workers aparearon sus archivos correctamente.");
		}else{
			log_error(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: Error al apareo archivos entre Workers.");
		}
	}

	free(msjHandshake);

//	list_destroy_and_destroy_elements(lista_workernode_conectados, destruir_lista_workers_conectados);

	log_info(workernode_log, "funcionesWorkerNode-> conectarseConWorkers: end conectarseConWorkers");

	return apareoGlobal;
}

char* leerLineaArchivoGlobal(FILE* fileReduccionGlobal){

	size_t len = 0;
	char* temporal_linea = NULL;

	if(getline(&temporal_linea,&len,fileReduccionGlobal)==-1){
		log_trace(workernode_log, "funcionesWorkerNode-> leerLineaArchivoGlobal: Fin de archivo. Se notifica al Worker host de la reduccion global");
		log_trace(workernode_log, "funcionesWorkerNode-> leerLineaArchivoGlobal: Se envio mensaje header WORKER_APAREO_EOF al Worker host.");
	//	fclose(fileReduccionGlobal);
		free(temporal_linea);
		temporal_linea = NULL;
	}else{
		log_trace(workernode_log, "funcionesWorkerNode-> leerLineaArchivoGlobal: Se envio mensaje header WORKER_APAREO_LEER_LINEA al Worker host.");
		log_trace(workernode_log, "funcionesWorkerNode-> leerLineaArchivoGlobal: Se envio linea a aparear al Worker host.");
		log_debug(workernode_log, "funcionesWorkerNode-> leerLineaArchivoGlobal: Worker host leyo linea: %s", temporal_linea);
	}

	return temporal_linea;
}


char* aparearArchivosEntreWorkers(t_list* lista_workernode_conectados){

	log_info(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: init aparearArchivosEntreWorkers");

	t_mensaje_HEADER* msjHeader = malloc(sizeof(t_mensaje_HEADER));

	int i=0;
	int eliminarUno=-1;
	int hayWorkersConectados = list_size(lista_workernode_conectados);


	t_list* lista_apareo = list_create();

	FILE* fpHOST = NULL;

	while(hayWorkersConectados > 0){
		for(i=0;i<list_size(lista_workernode_conectados);i++){
			t_workers_conectados* awc = list_get(lista_workernode_conectados, i);
			char* path_completo = string_new();
			string_append(&path_completo, "temp/");
			string_append(&path_completo, awc->pathnombre);
			log_debug(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: Archivo: %s", path_completo);
			if(awc->socket_worker_fd == -1){
				if(archivo_abierto == 0){
					fpHOST = fopen(path_completo,"r");
					if(fpHOST == NULL){
						log_error(workernode_log, "funcionesWorkerNode -> aparearArchivosEntreWorkers: No se pudo abrir el archivo del Worker host %s", path_completo);
					}else{
						archivo_abierto = 1;
					}
				}
				char* lineaLeida = leerLineaArchivoGlobal(fpHOST);
				if(lineaLeida!=NULL){
					t_elemento_linea* elemento_linea = malloc(sizeof(t_elemento_linea));
					elemento_linea->buffer = string_new();
					string_append(&elemento_linea->buffer, lineaLeida);
					elemento_linea->largo_buffer = strlen(lineaLeida);
					list_add(lista_apareo, elemento_linea);
					free(lineaLeida);
				}else{
					eliminarUno=i;
				}
			}else{
				msjHeader->codigoMensaje = WORKER_APAREO_GLOBAL;
				msjHeader->tamanio = strlen(path_completo);
				if(!enviar_mensaje_header(msjHeader, awc->socket_worker_fd)){
					log_error(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: Error al enviar mensaje header WORKER_APAREO_GLOBAL");
				}else{
					log_info(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: Mensaje header WORKER_APAREO_GLOBAL enviado correctamente.");
				}
				sendall(awc->socket_worker_fd, path_completo, msjHeader->tamanio);
				recibir_mensaje_header(msjHeader, awc->socket_worker_fd);
				if(msjHeader->codigoMensaje==WORKER_APAREO_LEER_LINEA){
					char* buffer = malloc(msjHeader->tamanio);
					recvall(awc->socket_worker_fd, buffer, msjHeader->tamanio);
					log_debug(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: Worker host recibio linea: %s", buffer);
					t_elemento_linea* elemento_linea = malloc(sizeof(t_elemento_linea));
					elemento_linea->buffer = string_new();
					string_append(&elemento_linea->buffer, buffer);
					elemento_linea->largo_buffer = msjHeader->tamanio;
					list_add(lista_apareo, elemento_linea);
					free(buffer);
				}else{
					eliminarUno=i;
					if(awc->socket_worker_fd != -1){
						socket_close(awc->socket_worker_fd);
					}
				}
			}
			free(path_completo);
		}

			bool menor_a_mayor(t_elemento_linea* el1, t_elemento_linea* el2) {
				return (strcmp(el1->buffer, el2->buffer) < 0);

			}

			list_sort(lista_apareo, (void*)menor_a_mayor);

			if(eliminarUno != -1){
				void eliminar_elemento_conectados (void*data){
					t_workers_conectados* arg = (t_workers_conectados*) data;
					free(arg->pathnombre);
					free(arg);
				}
				list_remove_and_destroy_element(lista_workernode_conectados,eliminarUno,eliminar_elemento_conectados);
			//	list_remove(lista_workernode_conectados, eliminarUno);
				hayWorkersConectados --;
			}

			i=0;
			eliminarUno=-1;
	}

	list_destroy(lista_workernode_conectados);

	for(i=0;i<list_size(lista_apareo);i++){
		t_elemento_linea* elem = list_get(lista_apareo,i);
		log_debug(workernode_log, "LINEA %d: %s", i+1, elem->buffer);
	}

	char* resultado_apareo_global = string_new();
	char* aleatorio = string_itoa(random());

	string_append(&resultado_apareo_global, "temp/archivo_apareo_global_temporal_");
	string_append(&resultado_apareo_global, aleatorio);

	FILE* pf = fopen(resultado_apareo_global, "w");

	for(i=0;i<list_size(lista_apareo);i++){
		t_elemento_linea* linea = list_get(lista_apareo,i);
		fwrite(linea->buffer, linea->largo_buffer, 1, pf);
	}

	archivo_abierto = 0;

	void eliminar_lista_apareo (void*data){
		t_elemento_linea* arg = (t_elemento_linea*) data;
		free(arg->buffer);
		free(arg);
	}

	list_destroy_and_destroy_elements(lista_apareo,eliminar_lista_apareo);


	fclose(pf);
	fclose(fpHOST);

	free(aleatorio);
	free(msjHeader);

	log_info(workernode_log, "funcionesWorkerNode-> aparearArchivosEntreWorkers: end aparearArchivosEntreWorkers");

	return resultado_apareo_global;
}

int desconectarWorkers(t_list* lista_workernode_conectados){

	int i;
	int resultado = 1;

	//Voy recorriendo la lista de worker conectados y cerrando la comunicacion
	for(i=0;i< lista_workernode_conectados->elements_count;i++){
		t_workers_conectados* worker = list_get(lista_workernode_conectados,i);
		if(worker->socket_worker_fd == -1){
			resultado = 1;
		}else{
			if(!socket_close(worker->socket_worker_fd)){
				resultado = 0;
			}else{
				resultado = 1;
			}
		}
	}

	return resultado;
}

void liberarVariablesWorker(){
	workernode_config_destroy(workernode_cfg);

	free(EXTENSION);
	free(pmap_fs);

	pthread_mutex_destroy(&mutex_workernode_log);
	list_destroy_and_destroy_elements(worker_master_aceptados,(void*)free);

	log_trace(workernode_log, "funcionesWorkerNode-> liberarSemaforosWorker: Variables globales del proceso liberadas.");

	log_destroy(workernode_log);

	printf("\nFin del proceso Worker. ");
}

void dummy_func_escribir(int sock_fd){

}

void logDebugTransformacion(t_msj_transformacion_worker* info_transformacion){
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: --- Datos transformacion recibidos ---");
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: BLOQUE: %d", info_transformacion->bloqueATransformar);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: BLOQUE TAMAÑO: %d", info_transformacion->bloqueATransformar_tamanio);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: SCRIPT: %s", info_transformacion->scriptTransformador);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: SCRIPT LARGO: %d", info_transformacion->scripTransformador_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: ARCHIVO TEMPORAL: %s", info_transformacion->archivo_destino_transformacion);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: LARGO NOMBRE ARCHIVO TEMPORAL: %d", info_transformacion->archivo_destino_transformacion_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugTransformacion: --------------------------------------");
}

void logDebugReduccionLocal(t_msj_reduccion_local_worker* info_reduccion_local){
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: --- Datos reduccion local recibidos ---");
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: CANTIDAD ARCHIVOS REDUCCION LOCAL: %d", info_reduccion_local->archivos_reduccion_cantidad);
	int i;
	for(i=0;i<info_reduccion_local->archivos_reduccion_cantidad;i++){
		t_archivo_reducir_local* archivo = list_get(info_reduccion_local->archivos_reduccion,i);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: ARCHIVO %d -> LARGO %d", i+1 , archivo->nombreArchivoLargo);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: ARCHIVO %d -> NOMBRE %s", i+1 , archivo->nombreArchivo);
	}
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: LARGO DESTINO: %d", info_reduccion_local->destino_reduccion_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: DESTINO: %s", info_reduccion_local->destino_reduccion);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: LARGO SCRIPT: %d", info_reduccion_local->scriptReduccion_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: SCRIPT REDUCTOR LOCAL: %s", info_reduccion_local->scriptReduccion);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionLocal: --------------------------------------");
}

void logDebugReduccionGlobal(t_msj_reduccion_global_worker* info_reduccion_global){
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: --- Datos reduccion global recibidos ---");
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: CANTIDAD ARCHIVOS REDUCCION GLOBAL: %d", info_reduccion_global->archivos_reduccion_cantidad);
	int i;
	for(i=0;i<info_reduccion_global->archivos_reduccion_cantidad;i++){
		t_archivo_reducir_global* archivo = list_get(info_reduccion_global->archivos_reduccion,i);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> LARGO %d", i+1 , archivo->nombreArchivoLargo);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> NOMBRE %s", i+1 , archivo->nombreArchivo);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> NODO PUERTO LARGO %d", i+1 , archivo->nodo_puerto_largo);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> NODO PUERTO %s", i+1 , archivo->nodo_puerto);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> NODO IP LARGO %d", i+1 , archivo->nodo_ip_largo);
		log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: ARCHIVO %d -> NODO IP %s", i+1 , archivo->nodo_ip);
	}
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: LARGO DESTINO: %d", info_reduccion_global->destino_reduccion_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: DESTINO: %s", info_reduccion_global->destino_reduccion);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: LARGO SCRIPT: %d", info_reduccion_global->scriptReduccion_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: SCRIPT REDUCTOR GLOBAL: %s", info_reduccion_global->scriptReduccion);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugReduccionGlobal: --------------------------------------");
}

void logDebugAlmacenamientoFinal(t_msj_almacenamiento_final_worker* info_almacenamiento_final){
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: --- Datos almacenamiento final ---");
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: LARGO PATH ARCHIVO: %d", info_almacenamiento_final->archivo_almacenamiento_final_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: ARCHIVO: %s", info_almacenamiento_final->archivo_almacenamiento_final);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: LARGO PATH ARCHIVO GLOBAL: %d", info_almacenamiento_final->archivo_reduccion_global_largo);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: ARCHIVO GLOBAL: %s", info_almacenamiento_final->archivo_reduccion_global);
	log_debug(workernode_log, "funcionesWorkerNode-> logDebugAlmacenamientoFinal: --------------------------------------");
}
