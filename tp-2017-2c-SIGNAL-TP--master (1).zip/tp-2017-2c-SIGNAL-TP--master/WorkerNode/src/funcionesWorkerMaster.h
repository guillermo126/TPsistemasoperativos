/*
 * funcionesWorkerMaster.h
 *
 *  Created on: 13/9/2017
 *      Author: utnso
 */

#ifndef SRC_FUNCIONESWORKERMASTER_H_
#define SRC_FUNCIONESWORKERMASTER_H_

#include <commons/collections/list.h>
#include "src/serialize-adm.h"

/*
 	 * master_aceptado: estructura que guarda sock_fd de un master aceptado
*/
typedef struct {
	int32_t sock_fd;
} master_aceptado;

/*
 	 * socket_lectura_master: socket fd del master actual de lectura
*/
int socket_lectura_master;

/*
	* worker_master_aceptados: lista global que contiene los masters que están conectadas a worker
*/
t_list* worker_master_aceptados;

/*
 	 * @NAME: buscarEnProcesosConectados
 	 * @DESC: Funcion que busca en una lista si el Master o Worker ya está conectado o es uno nuevo
*/
int buscarEnProcesosConectados(int);

/*
 	 * @NAME: aceptarMaster
 	 * @DESC: Funcion que agrega un proceso Master o Worker a la lista de activos - conectados al sistema
*/
void aceptarProceso(int);

/*
 	 * @NAME: eliminarMaster
 	 * @DESC: Funcion que elimina un proceso Master o Worker a la lista de activos - conectados al sistema
*/
void eliminarProceso(int);

#endif /* SRC_FUNCIONESWORKERMASTER_H_ */
