/*
 * workernode.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#ifndef SRC_WORKERNODE_H_
#define SRC_WORKERNODE_H_

#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>

#include <commons/log.h>
#include <commons/collections/list.h>
#include <commons/config.h>
#include <commons/string.h>

#include "src/serialize-adm.h"
#include "src/socket-adm.h"

#include "config.h"
#include "funcionesWorkerNode.h"

#endif /* SRC_WORKERNODE_H_ */
