/*
 * config.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include <commons/config.h>
#include <commons/string.h>
#include <commons/log.h>

#define PROGRAM_NAME "WORKERNODE_SIGNAL_TP"
#define PATH_CONFIG_WORKERNODE "config/workernode.cfg"
#define PATH_LOG_WORKERNODE "log/workernode.log"
#define CANTIDAD_PARAMETROS_CONFIG 6

/*
 	 * workernode_config: Estructura que contiene los parametros del archivo de configuracion del workernode
*/
typedef struct {
	char* ip_fs;
	int32_t puerto_fs;
	char* nombre_nodo;
	int32_t puerto_worker;
	int32_t puerto_datanode;
	char* ruta_databin;
} workernode_config;

/*
 	 * workernode_cfg: Variable global de tipo workernode_config. Contiene datos del archivo config
*/
workernode_config* workernode_cfg;

/*
 	 * workernode_log: Variable que contiene info de log del proceso workernode
*/
t_log* workernode_log;

/*
 	 * mutex_workernode_log: Mutex para sincronizar uso del log
*/
pthread_mutex_t mutex_workernode_log;

/*
 	 * @NAME: workernode_config_create
 	 * @DESC: Genera estructura del tipo workernode_config leyendo parametros desde el archivo de configuracion
*/
int workernode_config_create(workernode_config *config,char* config_path);

/*
 	 * @NAME: workernode_config_destroy
 	 * @DESC: Destruye una estructura del tipo workernode_config
*/
void workernode_config_destroy(workernode_config *config);

/*
 	 * @NAME: log_config
 	 * @DESC: Loguea los valores de una estructura del tipo config
*/
void log_config(workernode_config *config);

#endif /* SRC_CONFIG_H_ */
