/*
 * serializacionMensajes.h
 *
 *  Created on: 11/9/2017
 *      Author: utnso
 */

#ifndef SRC_SERIALIZACIONMENSAJES_H_
#define SRC_SERIALIZACIONMENSAJES_H_

#include <src/serialize-adm.h>

/*
 	 * @NAME: deserializarMensajeTransformacionWorker
 	 * @DESC: Funcion que deserializa el mensaje transformacion enviado por el proceso Master
*/
t_msj_transformacion_worker* deserializarMensajeTransformacionWorker(char*);

/*
 	 * @NAME: deserializarMensajeReduccionLocalWorker
 	 * @DESC: Funcion que deserializa el mensaje reduccion local enviado por el proceso Master
*/
t_msj_reduccion_local_worker* deserializarMensajeReduccionLocalWorker(char*);

/*
 	 * @NAME: deserializarMensajeReduccionGlobalWorker
 	 * @DESC: Funcion que deserializa el mensaje reduccion global enviado por el proceso Master
*/
t_msj_reduccion_global_worker* deserializarMensajeReduccionGlobalWorker(char*);

/*
 	 * @NAME: deserializarAlmacenamientoFinalWorker
 	 * @DESC: Funcion que deserializa el mensaje almacenamiento a fs enviado por el proceso Master
*/
t_msj_almacenamiento_final_worker* deserializarAlmacenamientoFinalWorker(char*);

/*
 	 * @NAME: serializarAlmacenamientoFinal
 	 * @DESC: Funcion que serializa el mensaje almacenamiento a enviar desde Worker a FS
*/
char* serializarAlmacenamientoFinal(t_msj_almacenamiento_final_fs*, int*);

#endif /* SRC_SERIALIZACIONMENSAJES_H_ */
