# tp-2017-2c-SIGNAL-TP-

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/utnso/git/tp-2017-2c-SIGNAL-TP-/SharedLibrarySignalTP/Debug

scripts/transformador.sh scripts/reductor.rb yamafs:/datos.csv yamafs:/analisis/resultado.json
