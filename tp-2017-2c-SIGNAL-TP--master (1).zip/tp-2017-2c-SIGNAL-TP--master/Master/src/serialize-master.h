/*
 * serialize-master.h
 *
 *  Created on: 5/9/2017
 *      Author: marcelocejas
 */

#ifndef SRC_SERIALIZE_MASTER_H_
#define SRC_SERIALIZE_MASTER_H_

#include <commons/collections/list.h>
#include "src/serialize-adm.h"

int socket_yama;

t_pNodo_transformacion* deserializeMsjTransformacion(char* mensaje_transformacion);

t_pNodo_reduccion_global* deserializeMsjReduccionGlobal(char* mensaje_Reduccion_Global);

t_pNodo_reduccion_local* deserializeMsjReduccionLocal(char* mensaje_Reduccion_Local);

t_pNodo_almacenamiento_final* deserializeMsjAlmacenamientoFinal(char* mensaje_AlmacenamientoFinal);

char* serializeSolicitarJob(t_pSolicitar_Job* param_Solicitar_Job, int* largo);

char* serializeTransformarWorker(t_msj_transformacion_worker* msj_transformar_worker, int* largo);

char* serializeReducirLocalWorker(t_msj_reduccion_local_worker* msj_reducir_worker, int* largo);

char* serializeReducirGlobalWorker(t_msj_reduccion_global_worker* msj_reducir_worker, int* largo);

char* serializeAlmacenamientoFinalWorker(t_msj_almacenamiento_final_worker* msj_almacenamiento_final_worker, int* largo);

char* serializeRespuestaEtapa(t_mensaje_resultado_etapa* pRespuestaEtapa, int* largo);

#endif /* SRC_SERIALIZE_MASTER_H_ */
