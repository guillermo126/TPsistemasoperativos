/*
 * funcionesYama.c
 *
 *  Created on: 8/9/2017
 *      Author: marcelocejas
 */


#include "funcionesYama.h"

int threadClienteYama(){

	if (pthread_create(&threadYama, &attr, manejadorJob, NULL) < 0) {
		log_error(master_log,"threadCliente-> Error al crear hilo de comunicacion con Yama.");
		return EXIT_FAILURE;
	}else{
		log_trace(master_log,"threadCliente-> Se creo el hilo de comunicacion con Yama.");
	}

	return EXIT_SUCCESS;
}

int conectarYama() {
	t_mensaje_HANDSHAKE *handShake;
	handShake = malloc(sizeof(handshake_t));
	handShake->codigoHandshake = HANDSHAKE_MASTER;
	if (enviar_handshake(handShake, socket_yama)) {
		if (recibir_handshake(handShake, socket_yama)) {
			if (handShake->codigoHandshake == HANDSHAKE_YAMA) {
				log_trace(master_log,"conectarYama-> Conctado a YAMA.");
				free(handShake);
				return EXIT_SUCCESS;
			}
		}
	}
	free(handShake);
	return EXIT_FAILURE;
}

int solicitarJob() {
	t_mensaje_HEADER* headerSolicitarJob = malloc(sizeof(t_mensaje_HEADER));

	headerSolicitarJob->codigoMensaje = YAMA_CREAR_JOB;
	headerSolicitarJob->tamanio = pJob->archivo_datos_largo;
	if(!enviar_mensaje_header(headerSolicitarJob, socket_yama)){
		pthread_mutex_lock(&mutex_master_log);
		log_error(master_log, "solicitarJob-> Error enviando header de solicitud de job a YAMA.");
		pthread_mutex_unlock(&mutex_master_log);
		free(headerSolicitarJob);
		return EXIT_FAILURE;
	}
	if(!sendall(socket_yama, pJob->archivo_dato, pJob->archivo_datos_largo)){
		pthread_mutex_lock(&mutex_master_log);
		log_error(master_log, "solicitarJob-> Error enviando msj de solicitud de job a YAMA.");
		pthread_mutex_unlock(&mutex_master_log);
		free(headerSolicitarJob);
		return EXIT_FAILURE;
	}
	pthread_mutex_lock(&mutex_master_log);
	log_trace(master_log, "solicitarJob-> Mensaje de solititud de job enviado a YAMA correctamente.");
	pthread_mutex_unlock(&mutex_master_log);
	free(headerSolicitarJob);
	return EXIT_SUCCESS;
}

int validarWorkerConectado(t_worker_conectado* workerConectado){

	bool worker_conectado(t_worker_conectado *worker) {
		return (strcmp(worker->ipWorker, workerConectado->ipWorker) == 0
				&& strcmp(worker->puertoWorker, workerConectado->puertoWorker) == 0);
	}

	if (list_any_satisfy(ls_workerConectado, (void*) worker_conectado)) {
		t_worker_conectado* aux = malloc(sizeof(t_worker_conectado));
		aux = list_find(ls_workerConectado, (void*) worker_conectado);
		log_trace(master_log, "validarWorkerConectado-> Worker validado como ya conectado IP: %s PUERTO: %s.", aux->ipWorker, aux->puertoWorker);
		workerConectado->socket = aux->socket;
		workerConectado->ipWorker = string_duplicate(aux->ipWorker);
		workerConectado->puertoWorker = string_duplicate(aux->puertoWorker);
		//free(aux->ipWorker);
		//free(aux->puertoWorker);
		//free(aux);
	} else {
		workerConectado->socket = inciarConexionWorker(workerConectado->ipWorker, workerConectado->puertoWorker);
		if (0 < workerConectado->socket) {
			t_worker_conectado* aux = malloc(sizeof(t_worker_conectado));
			aux->ipWorker = string_duplicate(workerConectado->ipWorker);
			aux->puertoWorker = string_duplicate(workerConectado->puertoWorker);
			aux->socket = workerConectado->socket;
			list_add(ls_workerConectado, aux);
			log_trace(master_log, "validarWorkerConectado-> Nuevo worker conectado IP: %s PUERTO: %s.", workerConectado->ipWorker, workerConectado->puertoWorker);
		} else {
			pthread_mutex_lock(&mutex_master_log);
			log_error(master_log, "validarWorkerConectado-> Error al conectar a worker IP: %s PUERTO: %s.", workerConectado->ipWorker, workerConectado->puertoWorker);
			pthread_mutex_unlock(&mutex_master_log);
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}

void* manejadorJob() {
	t_mensaje_HEADER* headerMsjRecibido = malloc(sizeof(t_mensaje_HEADER));
	char*buffer;

	maximoTareasParalelas = 0;
	tareasParalelas = 0;
	cantidadFallos = 0;

	struct timeval *tInicialJob = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tFinalJob = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tTotalJob = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tPromedioTransformacion = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tPromedioReduccionLocal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tPromedioReduccionGlobal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));

	gettimeofday(tInicialJob, NULL);

	tiemposTransformacion = list_create();
	tiemposReduccionLocal = list_create();
	tiemposReduccionGlobal = list_create();

	if(solicitarJob()){
		pthread_exit(NULL);
	}
	log_trace(master_log, "manejadorJob-> Se solicito Job a Yama.");
	t_hilo_transformacion_worker* pTransformacion_worker;
	t_worker_conectado* workerConectado = malloc(sizeof(t_worker_conectado));
	int errorCount = 0;
	pthread_t threadWorker;
	int loop =  1;
	while (loop) {
		int i;
		if(!recibir_mensaje_header(headerMsjRecibido, socket_yama)){
			log_error(master_log, "Error recibiendo header de YAMA.");
			sleep(1);
			if(errorCount < 1){
				headerMsjRecibido->codigoMensaje = -1;
				errorCount++;
				continue;
			}
			else
				break;
		}

		switch ((int) headerMsjRecibido->codigoMensaje) {
		case  YAMA_ID_MASTER:
			idMaster = headerMsjRecibido->tamanio;
			log_trace(master_log, "manejadorJob-> ID Master recibido: %d",  idMaster);
			break;
		case PARAMETROS_TRANSFORMACION:
			tareasParalelas ++;
			buffer = malloc(headerMsjRecibido->tamanio);
			recvall(socket_yama, buffer, headerMsjRecibido->tamanio);

			log_debug(master_log, "TRANSFORMACION LOCK");
			pthread_mutex_lock(&mutex_transformacion);
			t_pNodo_transformacion* mensajeTransformacion = deserializeMsjTransformacion(buffer);

			workerConectado->ipWorker = string_duplicate(mensajeTransformacion->nodo_ip);
			workerConectado->puertoWorker = string_duplicate(mensajeTransformacion->nodo_puerto);

			if(validarWorkerConectado(workerConectado)){
				pthread_mutex_lock(&mutex_master_log);
				log_error(master_log, "manejadorJob-> Error al conectar al worker en la etapa de transformacion. IP:%s - PUERTO:%s.",
						workerConectado->ipWorker, workerConectado->puertoWorker);

				free(workerConectado->ipWorker);
				free(workerConectado->puertoWorker);
				pthread_mutex_unlock(&mutex_master_log);
				t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
				pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
				pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
				pRespuestaEtapa->bloque = mensajeTransformacion->bloque;
				pRespuestaEtapa->id_master = idMaster;
				pRespuestaEtapa->id_nodo = mensajeTransformacion->nodo_id;

				respuestaYama(YAMA_TRANSFORMACION_ERROR, pRespuestaEtapa);
				free(pRespuestaEtapa->nombreArchivo);
				free(pRespuestaEtapa);
				free(mensajeTransformacion->archivo_resultado);
				free(mensajeTransformacion->nodo_ip);
				free(mensajeTransformacion->nodo_puerto);
				free(mensajeTransformacion);
				cantidadFallos++;
				log_debug(master_log, "TRANSFORMACION UNLOCK ERROR");
				pthread_mutex_unlock(&mutex_transformacion);
				break;
			}
/*
			log_debug(master_log,
					"YAMA --> Archivo destino transformasion. Nombre %s, Nombre largo: %d",
					mensajeTransformacion->archivo_resultado,
					mensajeTransformacion->archivo_resultado_largo);
*/
			pTransformacion_worker = malloc(sizeof(t_hilo_transformacion_worker));
			pTransformacion_worker->parche = 1;
			pTransformacion_worker->bloqueATransformar_tamanio = mensajeTransformacion->bytesOcupados;
			pTransformacion_worker->bloqueATransformar = mensajeTransformacion->bloque;
			pTransformacion_worker->scriptTransformador_largo = *scriptTransformadorLargo;
			pTransformacion_worker->archivo_destino_transformacion_largo = mensajeTransformacion->archivo_resultado_largo;
			pTransformacion_worker->socket_worker = workerConectado->socket;
			pTransformacion_worker->worker_id = mensajeTransformacion->nodo_id;
			pTransformacion_worker->scriptTransformador = malloc(*scriptTransformadorLargo);
			memcpy(pTransformacion_worker->scriptTransformador, scriptTransformador, *scriptTransformadorLargo);
			pTransformacion_worker->archivo_destino_transformacion = string_duplicate(mensajeTransformacion->archivo_resultado);

			free(mensajeTransformacion->archivo_resultado);
			free(mensajeTransformacion->nodo_ip);
			free(mensajeTransformacion->nodo_puerto);
			free(mensajeTransformacion);

			int rs = pthread_create(&threadWorker, &attr_hilo_worker, (void*)solicitarTransformacionWorker, (void*)pTransformacion_worker);

			if (rs) {
				log_error(master_log, "manejadorJob-> Error al crear hilo de transformacion worker IP: %s PUERTO: %s.", workerConectado->ipWorker, workerConectado->puertoWorker);
				log_debug(master_log, "TRANSFORMACION UNLOCK ERROR THREAD");
				pthread_mutex_unlock(&mutex_transformacion);
			}

			log_debug(master_log, "TRANSFORMACION LOCK FREE YAMA");
			pthread_mutex_lock(&mutex_transformacion);
			free(pTransformacion_worker->archivo_destino_transformacion);
			free(pTransformacion_worker->scriptTransformador);
			free(pTransformacion_worker);
			pthread_mutex_unlock(&mutex_transformacion);
			log_debug(master_log, "TRANSFORMACION UNLOCK FREE YAMA");

			free(workerConectado->ipWorker);
			free(workerConectado->puertoWorker);
			break;
		case SOLICITUD_REDUCCION_LOCAL:
			tareasParalelas ++;
			buffer = malloc(headerMsjRecibido->tamanio);
			recvall(socket_yama, buffer, headerMsjRecibido->tamanio);

			log_debug(master_log, "REDUCCION LOCAL LOCK");
			pthread_mutex_lock(&mutex_redu_local);
			t_pNodo_reduccion_local* mensajeReduccionLocal = deserializeMsjReduccionLocal(buffer);

			workerConectado->ipWorker = string_duplicate(mensajeReduccionLocal->nodo_ip);
			workerConectado->puertoWorker = string_duplicate(mensajeReduccionLocal->nodo_puerto);

			if(validarWorkerConectado(workerConectado)){
				pthread_mutex_lock(&mutex_master_log);
				log_error(master_log, "manejadorJob-> Error al conectar con worker en la etapa de reduccion local. IP:%s - PUERTO:%s.",
						workerConectado->ipWorker, workerConectado->puertoWorker);
				free(workerConectado->ipWorker);
				free(workerConectado->puertoWorker);
				pthread_mutex_unlock(&mutex_master_log);
				t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
				pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
				pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
				pRespuestaEtapa->bloque = 0;
				pRespuestaEtapa->id_master = idMaster;
				pRespuestaEtapa->id_nodo = mensajeReduccionLocal->nodo_id;

				respuestaYama(YAMA_REDUCCION_LOCAL_ERROR, pRespuestaEtapa);
				free(pRespuestaEtapa->nombreArchivo);
				free(pRespuestaEtapa);
				if(list_size(mensajeReduccionLocal->archivos_reduccion)>0)
					list_destroy_and_destroy_elements(mensajeReduccionLocal->archivos_reduccion, (void*) liberarArchivosReduccionLocal);
				else
					list_destroy(mensajeReduccionLocal->archivos_reduccion);
				free(mensajeReduccionLocal->nodo_puerto);
				free(mensajeReduccionLocal->nodo_ip);
				free(mensajeReduccionLocal->destino_reduccion);
				free(mensajeReduccionLocal);
				cantidadFallos++;

				log_debug(master_log, "REDUCCION LOCAL UNLOCK ERROR");
				pthread_mutex_unlock(&mutex_redu_local);
				break;
			}

			t_hilo_reduccion_local_worker* pReduccionLocal = malloc(sizeof(t_hilo_reduccion_local_worker));
			pReduccionLocal->reduccion_local_worker = malloc(sizeof(t_msj_reduccion_local_worker));
			pReduccionLocal->reduccion_local_worker->scriptReduccion_largo = *scriptReductorLargo;
			pReduccionLocal->reduccion_local_worker->scriptReduccion = malloc(*scriptReductorLargo);
			memcpy(pReduccionLocal->reduccion_local_worker->scriptReduccion, scriptReductor, *scriptReductorLargo);
			pReduccionLocal->reduccion_local_worker->destino_reduccion_largo = mensajeReduccionLocal->destino_reduccion_largo;
			pReduccionLocal->reduccion_local_worker->destino_reduccion = string_duplicate(mensajeReduccionLocal->destino_reduccion);
			pReduccionLocal->reduccion_local_worker->archivos_reduccion = list_create();
			for(i=0; i < mensajeReduccionLocal->archivos_reduccion_cantidad; i++){
				list_add(pReduccionLocal->reduccion_local_worker->archivos_reduccion, list_get(mensajeReduccionLocal->archivos_reduccion, i));
			}
			pReduccionLocal->reduccion_local_worker->archivos_reduccion_cantidad = mensajeReduccionLocal->archivos_reduccion_cantidad;
			pReduccionLocal->socket_worker = workerConectado->socket;
			pReduccionLocal->worker_id = mensajeReduccionLocal->nodo_id;

			if (pthread_create(&threadWorker, &attr_hilo_worker, (void*)solicitarReduccionLocalWorker, (void*)pReduccionLocal) < 0) {
				pthread_mutex_lock(&mutex_master_log);
				log_error(master_log, "manejadorJob-> Error al crear hilo de reduccion local worker.");
				pthread_mutex_unlock(&mutex_master_log);
				if(list_size(pReduccionLocal->reduccion_local_worker->archivos_reduccion)>0)
					list_destroy_and_destroy_elements(pReduccionLocal->reduccion_local_worker->archivos_reduccion, (void*) liberarArchivosReduccionLocal);
				else
					list_destroy(pReduccionLocal->reduccion_local_worker->archivos_reduccion);
				free(pReduccionLocal->reduccion_local_worker->destino_reduccion);
				free(pReduccionLocal->reduccion_local_worker->scriptReduccion);
				free(pReduccionLocal->reduccion_local_worker);
				free(pReduccionLocal);
				log_debug(master_log, "REDUCCION LOCAL UNLOCK ERROR THREAD");
				pthread_mutex_unlock(&mutex_redu_local);
			} else {
				pthread_mutex_lock(&mutex_master_log);
				log_trace(master_log, "manejadorJob-> Se creo el hilo de reduccion local worker.");
				pthread_mutex_unlock(&mutex_master_log);
			}

			free(workerConectado->ipWorker);
			free(workerConectado->puertoWorker);
			free(mensajeReduccionLocal->nodo_puerto);
			free(mensajeReduccionLocal->nodo_ip);
			free(mensajeReduccionLocal->destino_reduccion);
			free(mensajeReduccionLocal);
			break;
		case SOLICITUD_REDUCCION_GLOBAL:
			tareasParalelas ++;
			buffer = malloc(headerMsjRecibido->tamanio);
			recvall(socket_yama, buffer, headerMsjRecibido->tamanio);
			log_debug(master_log, "REDUCCION GLOBAL LOCK");
			pthread_mutex_lock(&mutex_redu_global);
			t_pNodo_reduccion_global* mensajeReduccionGlobal = deserializeMsjReduccionGlobal(buffer);

			workerConectado->ipWorker = string_duplicate(mensajeReduccionGlobal->nodo_ip);
			workerConectado->puertoWorker = string_duplicate(mensajeReduccionGlobal->nodo_puerto);

			if(validarWorkerConectado(workerConectado)){
				log_error(master_log, "manejadorJob-> Error al conectar con worker en la etapa de reduccion global. IP:%s - PUERTO:%s.",
						workerConectado->ipWorker, workerConectado->puertoWorker);
				free(workerConectado->ipWorker);
				free(workerConectado->puertoWorker);
				t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
				pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
				pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
				pRespuestaEtapa->bloque = 0;
				pRespuestaEtapa->id_master = idMaster;
				pRespuestaEtapa->id_nodo = mensajeReduccionGlobal->nodo_id;

				respuestaYama(YAMA_REDUCCION_LOCAL_ERROR, pRespuestaEtapa);
				free(pRespuestaEtapa->nombreArchivo);
				free(pRespuestaEtapa);
				if(list_size(mensajeReduccionGlobal->archivos_reduccion)>0)
					list_destroy_and_destroy_elements(mensajeReduccionGlobal->archivos_reduccion, (void*) liberarArchivosReduccionGlobal);
				else
					list_destroy(mensajeReduccionGlobal->archivos_reduccion);
				free(mensajeReduccionGlobal->nodo_puerto);
				free(mensajeReduccionGlobal->nodo_ip);
				free(mensajeReduccionGlobal->destino_reduccion);
				free(mensajeReduccionGlobal);
				cantidadFallos++;
				log_debug(master_log, "REDUCCION GLOBAL UNLOCK ERROR");
				pthread_mutex_unlock(&mutex_redu_global);
				break;
			}

			t_hilo_reduccion_global_worker* pReduccionGlobal = malloc(sizeof(t_hilo_reduccion_local_worker));

			pReduccionGlobal->reduccion_global_worker = malloc(sizeof(t_msj_reduccion_global_worker));
			pReduccionGlobal->reduccion_global_worker->scriptReduccion_largo = *scriptReductorLargo;
			pReduccionGlobal->reduccion_global_worker->scriptReduccion = malloc(*scriptReductorLargo);
			memcpy(pReduccionGlobal->reduccion_global_worker->scriptReduccion, scriptReductor, *scriptReductorLargo);
			pReduccionGlobal->reduccion_global_worker->destino_reduccion_largo = mensajeReduccionGlobal->destino_reduccion_largo;
			pReduccionGlobal->reduccion_global_worker->destino_reduccion = string_duplicate(mensajeReduccionGlobal->destino_reduccion);
			pReduccionGlobal->reduccion_global_worker->archivos_reduccion_cantidad = mensajeReduccionGlobal->archivos_reduccion_cantidad;
			pReduccionGlobal->reduccion_global_worker->archivos_reduccion = list_create();
			for(i=0; i < mensajeReduccionGlobal->archivos_reduccion_cantidad; i++){
				list_add(pReduccionGlobal->reduccion_global_worker->archivos_reduccion, list_get(mensajeReduccionGlobal->archivos_reduccion, i));
			}

			pReduccionGlobal->socket_worker = workerConectado->socket;
			pReduccionGlobal->worker_id = mensajeReduccionGlobal->nodo_id;

			if (pthread_create(&threadWorker, &attr_hilo_worker, (void*)solicitarReduccionGlobalWorker, (void*)pReduccionGlobal) < 0) {
				pthread_mutex_lock(&mutex_master_log);
				log_error(master_log, "manejadorJob-> Error al crear hilo de reduccion global worker.");
				pthread_mutex_unlock(&mutex_master_log);
				if(list_size(pReduccionGlobal->reduccion_global_worker->archivos_reduccion)>0)
					list_destroy_and_destroy_elements(pReduccionGlobal->reduccion_global_worker->archivos_reduccion, (void*) liberarArchivosReduccionGlobal);
				else
					list_destroy(pReduccionGlobal->reduccion_global_worker->archivos_reduccion);
				free(pReduccionGlobal->reduccion_global_worker->destino_reduccion);
				free(pReduccionGlobal->reduccion_global_worker->scriptReduccion);
				free(pReduccionGlobal->reduccion_global_worker);
				free(pReduccionGlobal);
				log_debug(master_log, "REDUCCION GLOBAL UNLOCK ERROR THREAD");
				pthread_mutex_unlock(&mutex_redu_global);
			} else {
				pthread_mutex_lock(&mutex_master_log);
				log_trace(master_log, "manejadorJob-> Se creo el hilo de global worker.");
				pthread_mutex_unlock(&mutex_master_log);
			}

			free(workerConectado->ipWorker);
			free(workerConectado->puertoWorker);
			free(mensajeReduccionGlobal->nodo_puerto);
			free(mensajeReduccionGlobal->nodo_ip);
			free(mensajeReduccionGlobal->destino_reduccion);
			free(mensajeReduccionGlobal);
			break;
		case YAMA_ALMACENAMIENTO_FINAL:
				buffer = malloc(headerMsjRecibido->tamanio);
				recvall(socket_yama, buffer, headerMsjRecibido->tamanio);
				t_pNodo_almacenamiento_final* mensajeAlmacenamientoFinal = malloc(sizeof(t_pNodo_almacenamiento_final));
				mensajeAlmacenamientoFinal = deserializeMsjAlmacenamientoFinal(buffer);

				workerConectado->ipWorker = string_duplicate(mensajeAlmacenamientoFinal->nodo_ip);
				workerConectado->puertoWorker = string_duplicate(mensajeAlmacenamientoFinal->nodo_puerto);

				if(validarWorkerConectado(workerConectado)){
					pthread_mutex_lock(&mutex_master_log);
					log_error(master_log, "manejadorJob-> Error al conectar al worker en la etapa de almacenamiento final. IP:%s - PUERTO:%s.",
							workerConectado->ipWorker, workerConectado->puertoWorker);
					free(workerConectado->ipWorker);
					free(workerConectado->puertoWorker);
					pthread_mutex_unlock(&mutex_master_log);
					t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
					pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
					pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
					pRespuestaEtapa->bloque = 0;
					pRespuestaEtapa->id_master = idMaster;
					pRespuestaEtapa->id_nodo = mensajeAlmacenamientoFinal->nodo_id;

					respuestaYama(YAMA_REDUCCION_LOCAL_ERROR, pRespuestaEtapa);

					cantidadFallos++;
					free(mensajeAlmacenamientoFinal->archivo_final);
					free(mensajeAlmacenamientoFinal->nodo_ip);
					free(mensajeAlmacenamientoFinal->nodo_puerto);
					free(mensajeAlmacenamientoFinal);
					free(pRespuestaEtapa->nombreArchivo);
					free(pRespuestaEtapa);
					break;
				}

				t_hilo_almacenamiento_final_worker* pAlmacenamientoFinal_worker = malloc(sizeof(t_hilo_almacenamiento_final_worker));

				pAlmacenamientoFinal_worker->almacenamiento_final_worker = malloc(sizeof(t_msj_almacenamiento_final_worker));
				pAlmacenamientoFinal_worker->almacenamiento_final_worker->archivo_almacenamiento_final_largo = pJob->archivo_resultado_largo;
				pAlmacenamientoFinal_worker->almacenamiento_final_worker->archivo_almacenamiento_final = string_duplicate(pJob->archivo_resultado);
				pAlmacenamientoFinal_worker->almacenamiento_final_worker->archivo_reduccion_global_largo = mensajeAlmacenamientoFinal->archivo_final_largo;
				pAlmacenamientoFinal_worker->almacenamiento_final_worker->archivo_reduccion_global = string_duplicate(mensajeAlmacenamientoFinal->archivo_final);
				pAlmacenamientoFinal_worker->socket_worker = workerConectado->socket;
				pAlmacenamientoFinal_worker->worker_id = mensajeAlmacenamientoFinal->nodo_id;

				if (pthread_create(&threadWorker, &attr_hilo_worker, (void*)solicitarAlmacenamientoFinalWorker, (void*)pAlmacenamientoFinal_worker) < 0) {
					pthread_mutex_lock(&mutex_master_log);
					log_error(master_log, "manejadorJob-> Error al crear hilo de almacenamiento final worker.");
					pthread_mutex_unlock(&mutex_master_log);
					free(pAlmacenamientoFinal_worker->almacenamiento_final_worker->archivo_almacenamiento_final);
					free(pAlmacenamientoFinal_worker->almacenamiento_final_worker);
					free(pAlmacenamientoFinal_worker);
				} else {
					pthread_mutex_lock(&mutex_master_log);
					log_trace(master_log, "manejadorJob-> Se creo el hilo de almacenamiento final worker.");
					pthread_mutex_unlock(&mutex_master_log);
				}
				free(mensajeAlmacenamientoFinal->archivo_final);
				free(mensajeAlmacenamientoFinal->nodo_ip);
				free(mensajeAlmacenamientoFinal->nodo_puerto);
				free(mensajeAlmacenamientoFinal);
			break;
		case YAMA_FINALIZAR_JOB:
			log_trace(master_log, "manejadorJob-> Job Finalizado.");
			loop = 0;
			break;
		default:
			log_error(master_log, "manejadorJob-> Mensaje recibido no identificado.");
			errorCount++;
			break;
		}
	}
	gettimeofday(tFinalJob, NULL);

	calcularIntervaloTiempo(tInicialJob, tFinalJob, tTotalJob);
	calcularTiempoPromedio(tiemposTransformacion, tPromedioTransformacion);
	calcularTiempoPromedio(tiemposReduccionLocal, tPromedioReduccionLocal);
	calcularTiempoPromedio(tiemposReduccionGlobal, tPromedioReduccionGlobal);

	imprimirMetricas(tTotalJob, tPromedioTransformacion, tPromedioReduccionLocal, tPromedioReduccionGlobal);

	if(list_size(tiemposTransformacion)>0)
		list_destroy_and_destroy_elements(tiemposTransformacion,(void*) liberarTiempos);
	else
		list_destroy(tiemposTransformacion);


	if(list_size(tiemposReduccionLocal)>0)
		list_destroy_and_destroy_elements(tiemposReduccionLocal,(void*) liberarTiempos);
	else
		list_destroy(tiemposReduccionLocal);


	if(list_size(tiemposReduccionGlobal)>0)
		list_destroy_and_destroy_elements(tiemposReduccionGlobal,(void*) liberarTiempos);
	else
		list_destroy(tiemposReduccionGlobal);


	if(list_size(ls_workerConectado)>0)
		list_destroy_and_destroy_elements(ls_workerConectado,(void*) liberarWorkerConectado);
	else
		list_destroy(ls_workerConectado);

	free(headerMsjRecibido);
	free(workerConectado);
	free(tInicialJob);
	free(tFinalJob);
	free(tTotalJob);
	pthread_exit(NULL);
}

int calcularTiempoPromedio(t_list* tiemposMedidos, struct timeval * tiempoPromedio){
	int i, cantidadMediciones;
	long int uTiempoPromedio, uTiempoMedidoTotal = 0;
	struct timeval * tiempoMedido;

	cantidadMediciones = list_size(tiemposMedidos);
	for(i=0; i < cantidadMediciones; i++){
		tiempoMedido = list_get(tiemposMedidos, i);
		uTiempoMedidoTotal = uTiempoMedidoTotal + (tiempoMedido->tv_usec + 1000000 * tiempoMedido->tv_sec);
	}
	if(cantidadMediciones > 0)
		uTiempoPromedio = uTiempoMedidoTotal / cantidadMediciones;
	else
		uTiempoPromedio = 0;

	tiempoPromedio->tv_sec = uTiempoPromedio / 1000000;
	tiempoPromedio->tv_usec = uTiempoPromedio % 1000000;

	return uTiempoPromedio;
}

void imprimirMetricas(struct timeval * tTotal, struct timeval * tPromedioTransformacion, struct timeval * tPromedioReduccionLocal, struct timeval * tPromedioReduccionGlobal){

	printf("\n--------------------- JOB finalizado: %s ---------------------\n", pJob->archivo_dato);
	printf("Tiempo total de Ejecución del Job: %d.%d\n", (int)tTotal->tv_sec, (int)tTotal->tv_usec);
	printf("Tiempo promedio de ejecución de Transformación: %d.%d\n", (int)tPromedioTransformacion->tv_sec, (int)tPromedioTransformacion->tv_usec);
	printf("Tiempo promedio de ejecución de Reducción Local: %d.%d\n", (int)tPromedioReduccionLocal->tv_sec, (int)tPromedioReduccionLocal->tv_usec);
	printf("Tiempo promedio de ejecución de Reducción Global: %d.%d\n", (int)tPromedioReduccionGlobal->tv_sec, (int)tPromedioReduccionGlobal->tv_usec);
	printf("Cantidad total de tareas paralelas realizadas: %d\n", maximoTareasParalelas);
	printf("Cantidad de fallos obtenidos en la realización del JOB: %d\n", cantidadFallos);
	printf("\n---------------------------------------------------------------------------\n");
	printf("\n");

}
