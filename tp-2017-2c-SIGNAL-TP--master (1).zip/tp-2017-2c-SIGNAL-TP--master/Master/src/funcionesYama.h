/*
 * funcionesYama.h
 *
 *  Created on: 8/9/2017
 *      Author: utnso
 */

#ifndef SRC_FUNCIONESYAMA_H_
#define SRC_FUNCIONESYAMA_H_

#include "funcionesWorker.h"

pthread_t threadYama;
pthread_attr_t attr;
pthread_attr_t attr_hilo_worker;

char* scriptTransformador;
int32_t* scriptTransformadorLargo;
char* scriptReductor;
int32_t* scriptReductorLargo;

int conectarYama();
int conectarYama();
int solicitarJob();
void* manejadorJob();
int threadClienteYama();
int validarWorkerConectado(t_worker_conectado* workerConectado);
void imprimirMetricas(struct timeval * tTotal, struct timeval * tPromedioTransformacion, struct timeval * tPromedioReduccionLocal, struct timeval * tPromedioReduccionGlobal);
int calcularTiempoPromedio(t_list* tiemposMedidos, struct timeval * tiempoPromedio);

#endif /* SRC_FUNCIONESYAMA_H_ */
