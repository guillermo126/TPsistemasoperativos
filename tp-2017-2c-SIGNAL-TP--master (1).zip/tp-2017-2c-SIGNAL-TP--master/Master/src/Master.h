/*
 * Master.h
 *
 *  Created on: 3/9/2017
 *      Author: marcelocejas
 */

#ifndef MASTER_H_
#define MASTER_H_

#include "funcionesYama.h"

void leerParametros(char** argv);
void liberarParametros();
char* leerScript(char* nombreScript, int32_t* scriptLargo);

#endif /* MASTER_H_ */
