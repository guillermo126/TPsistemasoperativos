/*
 * config.h
 *
 *  Created on: 3/9/2017
 *      Author: marcelocejas
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_

#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <commons/collections/list.h>
#include <commons/config.h>
#include <commons/log.h>
#include <commons/string.h>
#include <commons/temporal.h>
#include "serialize-master.h"
#include "src/serialize-adm.h"
#include "src/socket-adm.h"

#define PROGRAM_NAME "MASTER_SIGNAL_TP"
#define PATH_CONFIG_MASTER "config/master.cfg"
#define PATH_LOG_MASTER "log/master.log"
#define CANTIDAD_PARAMETROS_CONFIG 2

//estructura config del master
typedef struct {
	char* ip_yama;
	char* puerto_yama;
} master_config;

//Estructura global que contiene el archivo de configuración actual del master
master_config* master_cfg;
//mutex para modificar la variable global del archivo de configuracion
pthread_mutex_t mutex_master_cfg;
//Estructura que representa el log del proceso master
t_log* master_log;
//mutex para usar el log
pthread_mutex_t mutex_master_log;
pthread_mutex_t mutex_transformacion;
pthread_mutex_t mutex_redu_local;
pthread_mutex_t mutex_redu_global;

/*
 * master_config_create:
 * genera una estructura del tipo master_config leyendo los parametros
 * desde el archivo de configuracion
 */
int master_config_create(master_config *config,char* config_path);

/*
 * master_config_destroy:
 * destruye una estructura del tipo master_config
 */
void master_config_destroy(master_config *config);

/*
 * log_config:
 * loguea los valores de una estructura del tipo config
 * */
void log_config(master_config *config);
#endif /* SRC_CONFIG_H_ */
