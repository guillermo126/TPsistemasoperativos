/*
 * funcionesWorker.c
 *
 *  Created on: 8/9/2017
 *      Author: marcelocejas
 */


#include "funcionesWorker.h"


int conectarWorker(int socket_worker){
	t_mensaje_HANDSHAKE *handShake;
	handShake = malloc(sizeof(t_mensaje_HANDSHAKE));
	handShake->codigoHandshake = HANDSHAKE_MASTER;
	if (enviar_handshake(handShake, socket_worker)) {
		if (recibir_handshake(handShake, socket_worker)) {
			if (handShake->codigoHandshake == HANDSHAKE_WORKER) {
				log_trace(master_log,"conectarYama-> Conctado a WORKER.");
				free(handShake);
				return EXIT_SUCCESS;
			}
		}
	}
	free(handShake);
	return EXIT_FAILURE;
}

/*Retorna socket conectado, 0 en caso de error.
 * */
int inciarConexionWorker(char* nodo_ip, char* nodo_puerto){
	int socket_worker;
	socket_worker = socket_create(nodo_ip, nodo_puerto, (char) TIPO_CLIENTE,	0, master_log);

	if (conectarWorker(socket_worker)) {
		return 0;
	}
	return socket_worker;
}

void liberarWorkerConectado(t_worker_conectado* workerConectado){
	if(workerConectado->socket > 0)
		socket_close(workerConectado->socket);
	free(workerConectado->puertoWorker);
	free(workerConectado->ipWorker);
	free(workerConectado);
}

void liberarArchivosReduccionLocal(t_archivo_reducir_local* archivoReduccionLocal){
	free(archivoReduccionLocal->nombreArchivo);
	free(archivoReduccionLocal);
}

void liberarArchivosReduccionGlobal(t_archivo_reducir_global* archivoReduccionGlobal){
	if(archivoReduccionGlobal->nodo_ip_largo > 0)
		free(archivoReduccionGlobal->nodo_ip);
	if(archivoReduccionGlobal->nodo_puerto_largo > 0)
		free(archivoReduccionGlobal->nodo_puerto);
	if(archivoReduccionGlobal->nombreArchivoLargo > 0)
		free(archivoReduccionGlobal->nombreArchivo);
	free(archivoReduccionGlobal);
}

void liberarTiempos(struct timeval *tiempo){
	free(tiempo);
}

int calcularIntervaloTiempo(struct timeval *tInicial, struct timeval *tFinal, struct timeval * tIntervalo){
    long int intervalo = (tFinal->tv_usec + 1000000 * tFinal->tv_sec) - (tInicial->tv_usec + 1000000 * tInicial->tv_sec);
    tIntervalo->tv_sec = intervalo / 1000000;
    tIntervalo->tv_usec = intervalo % 1000000;

    return (intervalo<0);
}

int respuestaYama(mensaje_t resultado, t_mensaje_resultado_etapa* pRespuestaEtapa){
	t_mensaje_HEADER* headerRpta = malloc(sizeof(t_mensaje_HEADER));
	int32_t* msjLargo = malloc(sizeof(int32_t));

	char* msjRespuestaEtapa = serializeRespuestaEtapa(pRespuestaEtapa, msjLargo);

	headerRpta->codigoMensaje = resultado;
	headerRpta->tamanio = *msjLargo;
	log_trace(master_log, "respuestaYama--> Enviando respuesta a YAMA.");
	if(!enviar_mensaje_header(headerRpta, socket_yama)){
		log_error(master_log, "respuestaYama-->Falla enviando header respuesta a YAMA.");
		free(msjLargo);
		free(msjRespuestaEtapa);
		free(headerRpta);
		return EXIT_FAILURE;
	}

	if(!sendall(socket_yama, msjRespuestaEtapa, *msjLargo)){
		log_error(master_log, "respuestaYama-->Falla enviando respuesta a YAMA.");
		free(msjLargo);
		free(msjRespuestaEtapa);
		free(headerRpta);
		return EXIT_FAILURE;
	}

	free(msjLargo);
	free(msjRespuestaEtapa);
	free(headerRpta);
	return EXIT_SUCCESS;
}

void* solicitarTransformacionWorker(t_hilo_transformacion_worker* pWorker){
	pthread_t self;
	self = pthread_self();

	t_msj_transformacion_worker* msjTransformarWorker = malloc(sizeof(t_msj_transformacion_worker));

	int32_t workerID = pWorker->worker_id;
	int32_t workerSoket = pWorker->socket_worker;

	log_trace(master_log, "manejadorJob-> Se creo el hilo de transformacion worker");

	struct timeval *tInicialTransformacion = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tFinalTransformacion = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tTotalTransformacion = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	gettimeofday(tInicialTransformacion, NULL);

	msjTransformarWorker->bloqueATransformar_tamanio = pWorker->bloqueATransformar_tamanio;
	msjTransformarWorker->scripTransformador_largo = pWorker->scriptTransformador_largo;
	msjTransformarWorker->archivo_destino_transformacion_largo = pWorker->archivo_destino_transformacion_largo;
	msjTransformarWorker->scriptTransformador = malloc(pWorker->scriptTransformador_largo);
	memcpy(msjTransformarWorker->scriptTransformador, pWorker->scriptTransformador, pWorker->scriptTransformador_largo);
	msjTransformarWorker->archivo_destino_transformacion = string_duplicate(pWorker->archivo_destino_transformacion);
	msjTransformarWorker->bloqueATransformar = pWorker->bloqueATransformar;

	int32_t* msjLargo = malloc(sizeof(int32_t));

	t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
	pRespuestaEtapa->bloque = pWorker->bloqueATransformar;
	pRespuestaEtapa->id_master = idMaster;
	pRespuestaEtapa->id_nodo = pWorker->worker_id;
	pRespuestaEtapa->nombreArchivoLargo = 0;

	log_debug(master_log, "TRANSFORMACION UNLOCK THREAD %lu", self);
	pthread_mutex_unlock(&mutex_transformacion);

	char* packTransformar = serializeTransformarWorker(msjTransformarWorker, msjLargo);
/*
	log_debug(master_log,
			"WORKER --> Archivo destino transformasion. Nombre %s, Nombre largo %d",
			msjTransformarWorker->archivo_destino_transformacion,
			msjTransformarWorker->archivo_destino_transformacion_largo);
*/
	t_mensaje_HEADER* headerTransformarWoker = malloc(sizeof(t_mensaje_HEADER));
	headerTransformarWoker->codigoMensaje = WORKER_MASTER_TRANSFORMACION;
	headerTransformarWoker->tamanio = *msjLargo;

	log_trace(master_log,
			"solicitarTransformacionWorker--> Enviando solicitud transformacion a WORKER ID:%d - Archivo: %s.",
			workerID, msjTransformarWorker->archivo_destino_transformacion);
	if(!enviar_mensaje_header(headerTransformarWoker, workerSoket)){
		log_error(master_log,
				"solicitarTransformacionWorker-->Falla enviando header solicitud a Worker ID:%d - Archivo: %s.",
				workerID, msjTransformarWorker->archivo_destino_transformacion);
		headerTransformarWoker->codigoMensaje = YAMA_TRANSFORMACION_ERROR;
	}

	if(!sendall(workerSoket,packTransformar, *msjLargo)){
		log_error(master_log,
				"solicitarTransformacionWorker-->Falla enviando Solicitur a Woker ID:%d - Archivo: %s.",
				workerID, msjTransformarWorker->archivo_destino_transformacion);
		headerTransformarWoker->codigoMensaje = YAMA_TRANSFORMACION_ERROR;
	}

	if(!recibir_mensaje_header(headerTransformarWoker, workerSoket)){
		log_error(master_log,
				"solicitarTransformacionWorker-->Falla recibiendo Header respuesta transformacion a Woker ID:%d - Archivo:%s.",
				pRespuestaEtapa->id_nodo, msjTransformarWorker->archivo_destino_transformacion);
		headerTransformarWoker->codigoMensaje = YAMA_TRANSFORMACION_ERROR;
	}

	if(headerTransformarWoker->codigoMensaje == WORKER_MASTER_ETAPA_OK){
		log_trace(master_log,"solicitarTransformacionWorker--> Transformacion a Woker ID:%d Bloque:%d, Master:%d - Archivo:%s.",
				pRespuestaEtapa->id_nodo, pRespuestaEtapa->bloque, pRespuestaEtapa->id_master, msjTransformarWorker->archivo_destino_transformacion);
		respuestaYama(YAMA_TRANSFORMACION_OK, pRespuestaEtapa);

	}else{
		pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
		pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
		log_error(master_log,
				"solicitarTransformacionWorker--> Transformacion a Woker ID:%d Bloque:%d, Master:%d - Archivo:%s.",
				pRespuestaEtapa->id_nodo, pRespuestaEtapa->bloque, pRespuestaEtapa->id_master, msjTransformarWorker->archivo_destino_transformacion);
		respuestaYama(YAMA_TRANSFORMACION_ERROR, pRespuestaEtapa);
		free(pRespuestaEtapa->nombreArchivo);
		cantidadFallos++;
	}
	if(maximoTareasParalelas < tareasParalelas)
		maximoTareasParalelas = tareasParalelas;
	tareasParalelas --;

	log_trace(master_log,
			"solicitarTransformacionWorker-> Finaliza Hilo de Transformacion, Archivo: %s.",
			msjTransformarWorker->archivo_destino_transformacion);
	gettimeofday(tFinalTransformacion, NULL);
	calcularIntervaloTiempo(tInicialTransformacion, tFinalTransformacion, tTotalTransformacion);

	list_add(tiemposTransformacion, tTotalTransformacion);
	free(msjTransformarWorker->archivo_destino_transformacion);
	free(msjTransformarWorker->scriptTransformador);
	free(msjTransformarWorker);
	free(pRespuestaEtapa);
	free(msjLargo);
	free(headerTransformarWoker);
	free(packTransformar);
	free(tInicialTransformacion);
	free(tFinalTransformacion);
	pthread_exit(NULL);
}

void* solicitarReduccionLocalWorker(t_hilo_reduccion_local_worker* pWorker){
	pthread_t self;
	self = pthread_self();

	t_mensaje_HEADER* headerReducirWoker = malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
	int32_t* msjLargo = malloc(sizeof(int32_t));
	int32_t workerID = pWorker->worker_id;
	int32_t workerSocket = pWorker->socket_worker;

	struct timeval *tInicialReduccionLocal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tFinalReduccionLocal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tTotalReduccionLocal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	gettimeofday(tInicialReduccionLocal, NULL);

	char* packReduccionLocal = serializeReducirLocalWorker(pWorker->reduccion_local_worker, msjLargo);

	char* archivoReduLocal = string_duplicate(pWorker->reduccion_local_worker->destino_reduccion);

	pRespuestaEtapa->bloque = 0;
	pRespuestaEtapa->id_master = idMaster;
	pRespuestaEtapa->id_nodo = pWorker->worker_id;
	pRespuestaEtapa->nombreArchivoLargo = 0;

	if(list_size(pWorker->reduccion_local_worker->archivos_reduccion)>0)
		list_destroy_and_destroy_elements(pWorker->reduccion_local_worker->archivos_reduccion, (void*) liberarArchivosReduccionLocal);
	else
		list_destroy(pWorker->reduccion_local_worker->archivos_reduccion);
	free(pWorker->reduccion_local_worker->destino_reduccion);
	free(pWorker->reduccion_local_worker->scriptReduccion);
	free(pWorker->reduccion_local_worker);
	free(pWorker);

	log_debug(master_log, "REDUCCION LOCAL UNLOCK THREAD %lu", self);
	pthread_mutex_unlock(&mutex_redu_local);

	headerReducirWoker->codigoMensaje = WORKER_MASTER_REDUCCION_LOCAL;
	headerReducirWoker->tamanio = *msjLargo;

	log_trace(master_log,
			"solicitarReduccionLocalWorker--> Enviando solicitud reduccion LOCAL a WORKER ID:%d.",
			workerID);
	if(!enviar_mensaje_header(headerReducirWoker, workerSocket)){
		log_error(master_log,
				"solicitarTransformacionWorker-->Falla enviando header solicitud a Worker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_LOCAL_ERROR;
	}

	if(!sendall(workerSocket,packReduccionLocal, *msjLargo)){
		log_error(master_log,
				"solicitarReduccionLocalWorker-->Falla enviando Solicitur a Woker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_LOCAL_ERROR;
	}

	if(!recibir_mensaje_header(headerReducirWoker, workerSocket)){
		log_error(master_log,
				"solicitarReduccionLocalWorker-->Falla recibiendo Header respuesta reduccion local a Woker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_LOCAL_ERROR;
	}

	if(headerReducirWoker->codigoMensaje == WORKER_MASTER_ETAPA_OK){
		respuestaYama(YAMA_REDUCCION_LOCAL_OK, pRespuestaEtapa);
	}else{
		pRespuestaEtapa->nombreArchivoLargo = pJob->archivo_datos_largo;
		pRespuestaEtapa->nombreArchivo = string_duplicate(pJob->archivo_dato);
		log_error(master_log,
				"solicitarReduccionLocalWorker--> Reduccion Local a Woker ID:%d - Archivo: %s.",
				workerID, archivoReduLocal);
		respuestaYama(YAMA_REDUCCION_LOCAL_ERROR, pRespuestaEtapa);
		free(pRespuestaEtapa->nombreArchivo);
		cantidadFallos++;
	}
	if(tareasParalelas > maximoTareasParalelas)
		maximoTareasParalelas = tareasParalelas;
	tareasParalelas --;

	log_trace(master_log,
			"solicitarReduccionLocalWorker-->Finaliza hilo de reduccion local WORKER ID %d - Archivo: %s.",
			workerID, archivoReduLocal);

	gettimeofday(tFinalReduccionLocal, NULL);
	calcularIntervaloTiempo(tInicialReduccionLocal, tFinalReduccionLocal, tTotalReduccionLocal);

	list_add(tiemposReduccionLocal, tTotalReduccionLocal);

	free(packReduccionLocal);
	free(msjLargo);
	free(pRespuestaEtapa);
	free(headerReducirWoker);
	pthread_exit(NULL);
}

void* solicitarReduccionGlobalWorker(t_hilo_reduccion_global_worker* pWorker){
	pthread_t self;
	self = pthread_self();

	t_mensaje_HEADER* headerReducirWoker = malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
	int32_t* msjLargo = malloc(sizeof(int32_t));
	int32_t workerID = pWorker->worker_id;

	struct timeval *tInicialReduccionGlobal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tFinalReduccionGlobal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	struct timeval *tTotalReduccionGlobal = malloc(sizeof(__suseconds_t ) + sizeof(__time_t ));
	gettimeofday(tInicialReduccionGlobal, NULL);

	char* packReducirGlobal = serializeReducirGlobalWorker(pWorker->reduccion_global_worker, msjLargo);
	headerReducirWoker->codigoMensaje = WORKER_MASTER_REDUCCION_GLOBAL;
	headerReducirWoker->tamanio = *msjLargo;

	log_trace(master_log,
			"solicitarReduccionGlobalWorker--> Enviando solicitud transformacion GLOBAL a WORKER ID:%d.",
			workerID);
	if(!enviar_mensaje_header(headerReducirWoker, pWorker->socket_worker)){
		log_error(master_log,
				"solicitarReduccionGlobalWorker-->Falla enviando header solicitud a Worker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_GLOBAL_ERROR;
	}

	if(!sendall(pWorker->socket_worker,packReducirGlobal, *msjLargo)){
		log_error(master_log,
				"solicitarReduccionGlobalWorker-->Falla enviando Solicitur a Woker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_GLOBAL_ERROR;
	}

	if(!recibir_mensaje_header(headerReducirWoker, pWorker->socket_worker)){
		log_error(master_log,
				"solicitarReduccionGlobalWorker-->Falla recibiendo Header respuesta reduccion global a Woker ID:%d.",
				workerID);
		headerReducirWoker->codigoMensaje = YAMA_REDUCCION_GLOBAL_ERROR;
	}

	pRespuestaEtapa->nombreArchivoLargo = pWorker->reduccion_global_worker->destino_reduccion_largo;
	pRespuestaEtapa->nombreArchivo = string_duplicate(pWorker->reduccion_global_worker->destino_reduccion);
	pRespuestaEtapa->bloque = 0;
	pRespuestaEtapa->id_master = idMaster;
	pRespuestaEtapa->id_nodo = pWorker->worker_id;

	if(headerReducirWoker->codigoMensaje == WORKER_MASTER_ETAPA_OK){
		respuestaYama(YAMA_REDUCCION_GLOBAL_OK, pRespuestaEtapa);
	}else{
		log_error(master_log,
				"solicitarReduccionGlobalWorker-->Falla reduccion global FINAL WORKER ID:%d.",
				workerID);
		respuestaYama(YAMA_REDUCCION_GLOBAL_ERROR, pRespuestaEtapa);
		free(pRespuestaEtapa->nombreArchivo);
		cantidadFallos++;
	}

	gettimeofday(tFinalReduccionGlobal, NULL);
	calcularIntervaloTiempo(tInicialReduccionGlobal, tFinalReduccionGlobal, tTotalReduccionGlobal);

	list_add(tiemposReduccionGlobal, tTotalReduccionGlobal);

	log_trace(master_log,
			"solicitarReduccionGlobalWorker-->Finaliza hilo de reduccion Global WORKER ID:%d.",
			workerID);
	free(packReducirGlobal);
	free(msjLargo);
	free(headerReducirWoker);
	free(pRespuestaEtapa);
	if(list_size(pWorker->reduccion_global_worker->archivos_reduccion)>0)
		list_destroy_and_destroy_elements(pWorker->reduccion_global_worker->archivos_reduccion, (void*) liberarArchivosReduccionGlobal);
	else
		list_destroy(pWorker->reduccion_global_worker->archivos_reduccion);
	free(pWorker->reduccion_global_worker->destino_reduccion);
	free(pWorker->reduccion_global_worker->scriptReduccion);
	free(pWorker->reduccion_global_worker);
	free(pWorker);

	log_debug(master_log, "REDUCCION GLOBAL UNLOCK THREAD %lu", self);
	pthread_mutex_unlock(&mutex_redu_global);
	pthread_exit(NULL);
}

void* solicitarAlmacenamientoFinalWorker(t_hilo_almacenamiento_final_worker* pWorker){
	t_mensaje_HEADER* headerAlmacenamientoFinal = malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_resultado_etapa* pRespuestaEtapa = malloc(sizeof(t_mensaje_resultado_etapa));
	int32_t* msjLargo = malloc(sizeof(int32_t));
	int32_t workerID = pWorker->worker_id;

	char* packAlmacenamientoFinal = serializeAlmacenamientoFinalWorker(pWorker->almacenamiento_final_worker, msjLargo);

	headerAlmacenamientoFinal->codigoMensaje = WORKER_MASTER_ALMACENAMIENTO_FINAL;
	headerAlmacenamientoFinal->tamanio = *msjLargo;

	log_trace(master_log,
			"solicitarAlmacenamientoFinalWorker--> Enviando solicitud transformacion GLOBAL a WORKER ID:%d.",
			workerID);
	if(!enviar_mensaje_header(headerAlmacenamientoFinal, pWorker->socket_worker)){
		log_error(master_log,
				"solicitarAlmacenamientoFinalWorker-->Falla enviando header solicitud a Worker ID:%d.",
				workerID);
		headerAlmacenamientoFinal->codigoMensaje = YAMA_ALMACENAMIENTO_FINAL_ERROR;
	}

	if(!sendall(pWorker->socket_worker,packAlmacenamientoFinal, *msjLargo)){
		log_error(master_log,
				"solicitarAlmacenamientoFinalWorker-->Falla enviando Solicitur a Woker ID:%d.",
				workerID);
		headerAlmacenamientoFinal->codigoMensaje = YAMA_ALMACENAMIENTO_FINAL_ERROR;
	}

	if(!recibir_mensaje_header(headerAlmacenamientoFinal, pWorker->socket_worker)){
		log_error(master_log,
				"solicitarAlmacenamientoFinalWorker-->Falla recibiendo Header respuesta reduccion global a Woker ID:%d.",
				workerID);
		headerAlmacenamientoFinal->codigoMensaje = YAMA_ALMACENAMIENTO_FINAL_ERROR;
	}

	pRespuestaEtapa->nombreArchivoLargo = pWorker->almacenamiento_final_worker->archivo_almacenamiento_final_largo;
	pRespuestaEtapa->nombreArchivo = string_duplicate(pWorker->almacenamiento_final_worker->archivo_almacenamiento_final);
	pRespuestaEtapa->bloque = 0;
	pRespuestaEtapa->id_master = idMaster;
	pRespuestaEtapa->id_nodo = pWorker->worker_id;

	if(headerAlmacenamientoFinal->codigoMensaje == WORKER_MASTER_ETAPA_OK){
		respuestaYama(YAMA_ALMACENAMIENTO_FINAL_OK, pRespuestaEtapa);
	}else{
		respuestaYama(YAMA_ALMACENAMIENTO_FINAL_ERROR, pRespuestaEtapa);
		log_error(master_log,
				"solicitarAlmacenamientoFinalWorker-->Falla Almacenamiento FINAL WORKER ID:%d.",
				workerID);
		free(pRespuestaEtapa->nombreArchivo);
		cantidadFallos++;
	}

	log_trace(master_log,
			"solicitarAlmacenamientoFinalWorker-->Finaliza hilo de almacenamiento final WORKER ID:%d.",
			workerID);
	free(pWorker->almacenamiento_final_worker->archivo_almacenamiento_final);
	free(pWorker->almacenamiento_final_worker);
	free(pWorker);
	free(pRespuestaEtapa);
	free(msjLargo);
	free(headerAlmacenamientoFinal);
	free(packAlmacenamientoFinal);
	pthread_exit(NULL);
}
