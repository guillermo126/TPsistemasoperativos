/*
 ============================================================================
 Name        : SIGNAL-Master.c
 Author      : marcelocejas
 Version     :
 Copyright   : Your copyright notice
 Description : proceso principal de Master
 ============================================================================
 */

#include "Master.h"

//Este es un ejemplo de los parametros que debe recibir el proceso.
//scripts/transformador.sh /scripts/reductor.rb yamafs:/datos.csv yamafs:/analisis/resultado.json

int main(int argc, char* argv[]) {
	//inicializacion estruvturas y variables globales
	master_cfg = malloc(sizeof(master_config));
	master_log =  log_create(PATH_LOG_MASTER, PROGRAM_NAME, true, LOG_LEVEL_TRACE);
	//se carga la estructura de config del master

	if(argc != 5){
		log_error(master_log,
				"main-> Se ingresaron incorrectametne los parametros del proceso.\nLa forma correcta "
				"es \"./<nombreProceso> <scriptTransformador> <scriptReductor> <OrigenDatos> <ArchivoResultado>");
		goto finalizar;
	}

	pJob = malloc(sizeof(t_pJob_Master));

	leerParametros(argv);

	if(!master_config_create(master_cfg,PATH_CONFIG_MASTER)){
		log_error(master_log, "main-> Error al cargar el archivo de configuracion");
		return EXIT_FAILURE;
	}
	log_config(master_cfg);

	socket_yama = socket_create(master_cfg->ip_yama, master_cfg->puerto_yama, (char)TIPO_CLIENTE, 0, master_log);

	if (socket_yama < 1) {
		log_error(master_log, "main-> No de pudo abrir la conexion para YAMA.");
		goto finalizar;
	}

	if (conectarYama()) {
		log_error(master_log, "main-> No se pudo conectar a YAMA.");
		goto finalizar;
	}
	scriptTransformadorLargo = malloc(sizeof(int32_t));
	scriptReductorLargo = malloc(sizeof(int32_t));

	scriptTransformador = leerScript(pJob->script_transformador, scriptTransformadorLargo);

	if(scriptTransformador == NULL){
		log_error(master_log, "main-> No se pudo leer el script de Transformacion");
		goto finalizar;
	}

	scriptReductor = leerScript(pJob->script_reductor, scriptReductorLargo);

	if(scriptReductor == NULL){
		log_error(master_log, "main-> No se pudo leer el script de Reduccion");
		goto finalizar;
	}

	ls_workerConectado = list_create();

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	pthread_attr_init(&attr_hilo_worker);
	pthread_attr_setdetachstate(&attr_hilo_worker, PTHREAD_CREATE_DETACHED);

	if(threadClienteYama()){
		goto finalizar;
	}
	pthread_join(threadYama,NULL);
	log_trace(master_log, "MAIN-> Hilo de JOB cerrado.");

	//////liberacion de estructuras variables globales////////
	free(scriptTransformador);
	free(scriptReductor);
	finalizar:
	master_config_destroy(master_cfg);
	free(scriptTransformadorLargo);
	free(scriptReductorLargo);
	liberarParametros();
	log_trace(master_log, "MAIN-> Parametros liberados. FIN");
	log_destroy(master_log);
	pthread_attr_destroy(&attr);
	pthread_attr_destroy(&attr_hilo_worker);
	pthread_exit(NULL);

}

void leerParametros(char** argv){
	pJob->script_transformador = string_duplicate(argv[1]);
	pJob->script_transformador_largo = string_length(pJob->script_transformador);
	pJob->script_reductor = string_duplicate(argv[2]);
	pJob->script_reductor_largo = string_length(pJob->script_reductor);
	pJob->archivo_dato = string_duplicate(argv[3]);
	pJob->archivo_datos_largo = string_length(pJob->archivo_dato);
	pJob->archivo_resultado = string_duplicate(argv[4]);
	pJob->archivo_resultado_largo = string_length(pJob->archivo_resultado);
}

void liberarParametros(){
	free(pJob->archivo_dato);
	free(pJob->archivo_resultado);
	free(pJob->script_reductor);
	free(pJob->script_transformador);
	free(pJob);
}

char* leerScript(char* nombreScript, int32_t* scriptLargo) {
	if (strcmp(nombreScript, "") == 0) {
		log_trace(master_log, "leerScript: El archivo %s (nulo) no existe.", nombreScript);
		return NULL;
	}

	FILE *fp;
	int32_t fileSize;

	fp = fopen(nombreScript, "r");
	if (fp == NULL) {
		log_error(master_log, "leerScript: No se pudo abrir el archivo %s", nombreScript);
		if (errno == ENOENT) {
			log_trace(master_log, "leerScript: El archivo %s no existe.", nombreScript);
		}
		return NULL;
	}
	fseek(fp, 0L, SEEK_END);
	fileSize = ftell(fp);
	rewind(fp);
	char* script = malloc(fileSize);
	fread(script, fileSize, 1, fp);
	fclose(fp);
	*scriptLargo = fileSize;
	return script;
}
