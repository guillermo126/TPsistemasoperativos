/*
 * funcionesWorker.h
 *
 *  Created on: 8/9/2017
 *      Author: marcelocejas
 */

#ifndef SRC_FUNCIONESWORKER_H_
#define SRC_FUNCIONESWORKER_H_

#include "config.h"

int32_t idMaster;

typedef struct metricaJob_t{
	int32_t tiempoEjecucion;
	int32_t tiempoMedioTransformasion;
	int32_t tiempoMedioReduccionLocal;
	int32_t tiempoMedioReduddionGlobal;
	int32_t maximoTareasParalelas;//SOLO PARA TRANSFORMACION Y REDUCCION LOCAL.
	int32_t cantidadTotalTransformasion;
	int32_t cantidadTotalReduccionLocal;
	int32_t cantidadTotalReduccionGlobal;
	int32_t cantidadFallos;
}t_metricaJob;

typedef struct workerConectado{
	char* ipWorker;
	char* puertoWorker;
	int32_t socket;
}t_worker_conectado;

/*
 * Parametros necesarios para el manejo del hilo worker.
 * */
typedef struct hilo_transformacion_worker_t{
	int32_t parche;
	//t_msj_transformacion_worker
	int32_t worker_id;
	int32_t socket_worker;
	//t_msj_transformacion_worker
	int32_t bloqueATransformar;
	int32_t bloqueATransformar_tamanio;
	int32_t scriptTransformador_largo;
	int32_t archivo_destino_transformacion_largo;
	char* scriptTransformador;
	char* archivo_destino_transformacion;
} t_hilo_transformacion_worker;

/*
 * Parametros necesarios para el manejo del hilo de reduccion local worker.
 * */
typedef struct hilo_reduccion_local_worker_t{
	t_msj_reduccion_local_worker* reduccion_local_worker;
	int32_t worker_id;
	int32_t socket_worker;
} t_hilo_reduccion_local_worker;

/*
 * Parametros necesarios para el manejo del hilo de reduccion global worker.
 * */
typedef struct hilo_reduccion_global_worker_t{
	t_msj_reduccion_global_worker* reduccion_global_worker;
	int32_t worker_id;
	int32_t socket_worker;
} t_hilo_reduccion_global_worker;

/*
 * Parametros necesarios para el manejo del hilo de almacenamiento final worker.
 * */
typedef struct hilo_almacenamiento_final_worker_t{
	t_msj_almacenamiento_final_worker* almacenamiento_final_worker;
	int32_t worker_id;
	int32_t socket_worker;
} t_hilo_almacenamiento_final_worker;

/*
 * Parametros necesarios para el manejo del Job en Master
 * */
typedef struct pJob_Master_t{
	int32_t script_transformador_largo;
	char* script_transformador;
	int32_t script_reductor_largo;
	char* script_reductor;
	int32_t archivo_datos_largo;
	char* archivo_dato;
	int32_t archivo_resultado_largo;
	char* archivo_resultado;
} t_pJob_Master;

t_list* ls_workerConectado;

int tareasParalelas;
int maximoTareasParalelas;
int cantidadFallos;
t_pJob_Master* pJob;
t_list* tiemposTransformacion;
t_list* tiemposReduccionLocal;
t_list* tiemposReduccionGlobal;

int conectarWorker(int socket_worker);
int inciarConexionWorker(char* nodo_ip, char* nodo_puerto);
void* solicitarTransformacionWorker(t_hilo_transformacion_worker* pWorker);
void* solicitarReduccionLocalWorker(t_hilo_reduccion_local_worker* pWorker);
void* solicitarReduccionGlobalWorker(t_hilo_reduccion_global_worker* pWorker);
void* solicitarAlmacenamientoFinalWorker(t_hilo_almacenamiento_final_worker* pWorker);
int respuestaYama(mensaje_t resultado, t_mensaje_resultado_etapa* pRespuestaEtapa);
void liberarArchivosReduccionLocal(t_archivo_reducir_local* lsReduccionLocal);
void liberarArchivosReduccionGlobal(t_archivo_reducir_global* archivoReduccionGlobal);
void liberarWorkerConectado(t_worker_conectado* workerConectado);
void liberarTiempos(struct timeval *tiempo);
int calcularIntervaloTiempo(struct timeval *tInicial, struct timeval *tFinal, struct timeval * tIntervalo);

#endif /* SRC_FUNCIONESWORKER_H_ */
