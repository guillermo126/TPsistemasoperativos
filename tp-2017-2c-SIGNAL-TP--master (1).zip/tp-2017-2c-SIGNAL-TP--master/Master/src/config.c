/*
 * config.c
 *
 *  Created on: 3/9/2017
 *      Author: marcelocejas
 */
#include "config.h"
t_config* tConfig;

int master_config_create(master_config *config,char* config_path){
	t_config *cfg_config;
	cfg_config = config_create(config_path);
	if(cfg_config == NULL){
		pthread_mutex_lock(&mutex_master_log);
		log_error(master_log, "master_config_create->No se pudo acceder al archivo de config");
		pthread_mutex_unlock(&mutex_master_log);
		return 0;
	}

	if (config_keys_amount(cfg_config) == CANTIDAD_PARAMETROS_CONFIG) {
		if (config_has_property(cfg_config, "YAMA_IP")) {
			config->ip_yama = string_new();
			string_append(&config->ip_yama,config_get_string_value(cfg_config, "YAMA_IP"));
		} else {
			pthread_mutex_lock(&mutex_master_log);
			log_error(master_log, "master_config_create->Falta el parametro: IP_FILESYSTEM");
			pthread_mutex_unlock(&mutex_master_log);
			return 0;
		}
		if (config_has_property(cfg_config, "YAMA_PUERTO")) {
			config->puerto_yama = string_new();
			string_append(&config->puerto_yama,config_get_string_value(cfg_config, "YAMA_PUERTO"));
		} else {
			pthread_mutex_lock(&mutex_master_log);
			log_error(master_log, "master_config_create->Falta el parametro: YAMA_PUERTO");
			pthread_mutex_unlock(&mutex_master_log);
			return 0;
		}
	}else{
		pthread_mutex_lock(&mutex_master_log);
		log_error(master_log, "master_config_create->El archivo de configuracion no tiene todos los parametros necesarios");
		pthread_mutex_unlock(&mutex_master_log);
		return 0;
	}
	pthread_mutex_lock(&mutex_master_log);
	log_trace(master_log, "master_config_create->Se ha cargado el archivo de configuracion del master exitosamente");
	pthread_mutex_unlock(&mutex_master_log);
	config_destroy(cfg_config);
	return 1;
}

void master_config_destroy(master_config *config){
	free(config->ip_yama);
	free(config->puerto_yama);
	free(config);
	pthread_mutex_lock(&mutex_master_log);
	log_trace(master_log, "master_config_destroy->Estructura master liberada exitosamente");
	pthread_mutex_unlock(&mutex_master_log);
}

void log_config(master_config *config){
	pthread_mutex_lock(&mutex_master_log);
	log_trace(master_log,"-----Archivo de configuracion del proceso master -----\n");
	log_trace(master_log,"YAMA_IP: %s\n",config->ip_yama);
	log_trace(master_log,"YAMA_PUERTO: %s\n",config->puerto_yama);
	log_trace(master_log,"-----Fin archivo de configuracion del proceso master-----\n");
	pthread_mutex_unlock(&mutex_master_log);
}
