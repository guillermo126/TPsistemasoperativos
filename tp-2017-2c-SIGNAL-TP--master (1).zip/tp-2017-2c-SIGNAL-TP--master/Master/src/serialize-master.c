/*
 * serialize-master.c
 *
 *  Created on: 5/9/2017
 *      Author: marcelocejas
 */

#include "serialize-master.h"

t_pNodo_transformacion* deserializeMsjTransformacion(char* mensaje_transformacion) {
	t_pNodo_transformacion* auxNodo = malloc(sizeof(t_pNodo_transformacion));

	int offset = 0, tmp_len = 0;
		//DESERIALIZO NODO_ID
		memcpy(&auxNodo->nodo_id, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->nodo_id)));
		offset += tmp_len;
		//DESERIALIZO ARCHIVO_RESULTADO_LARGO
		memcpy(&auxNodo->archivo_resultado_largo, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->archivo_resultado_largo)));
		offset += tmp_len;
		if(auxNodo->archivo_resultado_largo>0){
		auxNodo->archivo_resultado = malloc(auxNodo->archivo_resultado_largo + 1);
			//DESERIALIZO EL ARCHIVO_RESULTADO
			memcpy(auxNodo->archivo_resultado, mensaje_transformacion + offset,tmp_len = auxNodo->archivo_resultado_largo);
			auxNodo->archivo_resultado[auxNodo->archivo_resultado_largo] = '\0';
			offset += tmp_len;
		}
		//DESERIALIZO E NODO_IP_LARGO
		memcpy(&auxNodo->nodo_ip_largo, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->nodo_ip_largo)));
		offset += tmp_len;
		if(auxNodo->nodo_ip_largo>0){

			auxNodo->nodo_ip= malloc(auxNodo->nodo_ip_largo + 1);
			//DESERIALIZO EL nodo_IP
			memcpy(auxNodo->nodo_ip, mensaje_transformacion + offset,tmp_len = auxNodo->nodo_ip_largo );
			auxNodo->nodo_ip[auxNodo->nodo_ip_largo] = '\0';
			offset += tmp_len;
		}
		//DESERIALIZO EL NODO_PUERTO_LARGO
		memcpy(&auxNodo->nodo_puerto_largo, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->nodo_puerto_largo)));
		offset += tmp_len;
		if (auxNodo->nodo_puerto_largo > 0) {
			//DESERIALIZO EL NODO_PUERTO
			auxNodo->nodo_puerto = malloc(auxNodo->nodo_puerto_largo + 1);
			memcpy(auxNodo->nodo_puerto, mensaje_transformacion + offset,tmp_len = auxNodo->nodo_puerto_largo);
			auxNodo->nodo_puerto[auxNodo->nodo_puerto_largo] = '\0';
			offset += tmp_len;
		}
		memcpy(&auxNodo->bloque, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->bloque)));
		offset += tmp_len;
		memcpy(&auxNodo->bytesOcupados, mensaje_transformacion + offset, tmp_len = sizeof(typeof(auxNodo->bytesOcupados)));
		offset += tmp_len;
		free(mensaje_transformacion);
		return auxNodo;
}

t_pNodo_reduccion_local* deserializeMsjReduccionLocal(char* mensaje_Reduccion_Local) {
	t_pNodo_reduccion_local* auxNodo = malloc(sizeof(t_pNodo_reduccion_local));

	int offset = 0, tmp_len = 0;

	//DESERIALIZO NODO_ID
	memcpy(&auxNodo->nodo_id, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(auxNodo->nodo_id)));
	offset += tmp_len;
	//DESERIALIZO ARCHIVO_RESULTADO_LARGO
	memcpy(&auxNodo->destino_reduccion_largo, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(auxNodo->destino_reduccion_largo)));
	offset += tmp_len;
	if (auxNodo->destino_reduccion_largo > 0) {
		auxNodo->destino_reduccion = malloc(auxNodo->destino_reduccion_largo + 1);
		//DESERIALIZO EL ARCHIVO_RESULTADO
		memcpy(auxNodo->destino_reduccion, mensaje_Reduccion_Local + offset, tmp_len = auxNodo->destino_reduccion_largo);
		auxNodo->destino_reduccion[auxNodo->destino_reduccion_largo] = '\0';
		offset += tmp_len;
	}
	//DESERIALIZO E NODO_IP_LARGO
	memcpy(&auxNodo->nodo_ip_largo, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(auxNodo->nodo_ip_largo)));
	offset += tmp_len;
	if (auxNodo->nodo_ip_largo > 0) {

		auxNodo->nodo_ip = malloc(auxNodo->nodo_ip_largo + 1);
		//DESERIALIZO EL nodo_IP
		memcpy(auxNodo->nodo_ip, mensaje_Reduccion_Local + offset, tmp_len = auxNodo->nodo_ip_largo);
		auxNodo->nodo_ip[auxNodo->nodo_ip_largo] = '\0';
		offset += tmp_len;
	}
	//DESERIALIZO EL NODO_PUERTO_LARGO
	memcpy(&auxNodo->nodo_puerto_largo, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(auxNodo->nodo_puerto_largo)));
	offset += tmp_len;
	if (auxNodo->nodo_puerto_largo > 0) {
		//DESERIALIZO EL NODO_PUERTO
		auxNodo->nodo_puerto = malloc(auxNodo->nodo_puerto_largo + 1);
		memcpy(auxNodo->nodo_puerto, mensaje_Reduccion_Local + offset, tmp_len = auxNodo->nodo_puerto_largo);
		auxNodo->nodo_puerto[auxNodo->nodo_puerto_largo] = '\0';
		offset += tmp_len;
	}

	memcpy(&auxNodo->archivos_reduccion_cantidad, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(auxNodo->archivos_reduccion_cantidad)));
	offset += tmp_len;
	int i;
	auxNodo->archivos_reduccion = list_create();
	for (i = 0; i < auxNodo->archivos_reduccion_cantidad; i++) {
		t_archivo_reducir_local* archivo = malloc(sizeof(t_archivo_reducir_local));
		////DESERIALIZO NOMBRE DE ARCHIVO LARGO
		memcpy(&archivo->nombreArchivoLargo, mensaje_Reduccion_Local + offset, tmp_len = sizeof(typeof(archivo->nombreArchivoLargo)));
		offset += tmp_len;
		if (archivo->nombreArchivoLargo > 0) {
			//DESERIALIZO NOMBRE DE ARCHIVO
			archivo->nombreArchivo = malloc(archivo->nombreArchivoLargo + 1);
			memcpy(archivo->nombreArchivo, mensaje_Reduccion_Local + offset, tmp_len = archivo->nombreArchivoLargo);
			archivo->nombreArchivo[archivo->nombreArchivoLargo] = '\0';
			offset += tmp_len;
		list_add(auxNodo->archivos_reduccion, archivo);
		}
	}
	free(mensaje_Reduccion_Local);
	return auxNodo;
}

t_pNodo_reduccion_global* deserializeMsjReduccionGlobal(char* mensaje_Reduccion_Global) {
	t_pNodo_reduccion_global* auxNodo = malloc(sizeof(t_pNodo_reduccion_global));

	int offset = 0, tmp_len = 0;

	//DESERIALIZO NODO_ID
	memcpy(&auxNodo->nodo_id, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(auxNodo->nodo_id)));
	offset += tmp_len;
	//DESERIALIZO ARCHIVO_RESULTADO_LARGO
	memcpy(&auxNodo->destino_reduccion_largo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(auxNodo->destino_reduccion_largo)));
	offset += tmp_len;
	if (auxNodo->destino_reduccion_largo > 0) {
		auxNodo->destino_reduccion = malloc(auxNodo->destino_reduccion_largo + 1);
		//DESERIALIZO EL ARCHIVO_RESULTADO
		memcpy(auxNodo->destino_reduccion, mensaje_Reduccion_Global + offset, tmp_len = auxNodo->destino_reduccion_largo);
		auxNodo->destino_reduccion[auxNodo->destino_reduccion_largo] = '\0';
		offset += tmp_len;
	}
	//DESERIALIZO E NODO_IP_LARGO
	memcpy(&auxNodo->nodo_ip_largo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(auxNodo->nodo_ip_largo)));
	offset += tmp_len;
	if (auxNodo->nodo_ip_largo > 0) {

		auxNodo->nodo_ip = malloc(auxNodo->nodo_ip_largo + 1);
		//DESERIALIZO EL nodo_IP
		memcpy(auxNodo->nodo_ip, mensaje_Reduccion_Global + offset, tmp_len = auxNodo->nodo_ip_largo);
		auxNodo->nodo_ip[auxNodo->nodo_ip_largo] = '\0';
		offset += tmp_len;
	}
	//DESERIALIZO EL NODO_PUERTO_LARGO
	memcpy(&auxNodo->nodo_puerto_largo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(auxNodo->nodo_puerto_largo)));
	offset += tmp_len;
	if (auxNodo->nodo_puerto_largo > 0) {
		//DESERIALIZO EL NODO_PUERTO
		auxNodo->nodo_puerto = malloc(auxNodo->nodo_puerto_largo + 1);
		memcpy(auxNodo->nodo_puerto, mensaje_Reduccion_Global + offset, tmp_len = auxNodo->nodo_puerto_largo);
		auxNodo->nodo_puerto[auxNodo->nodo_puerto_largo] = '\0';
		offset += tmp_len;
	}
	//DESERIALIZO EL NODO_PUERTO_LARGO
	memcpy(&auxNodo->archivos_reduccion_cantidad, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(auxNodo->archivos_reduccion_cantidad)));
	offset += tmp_len;

	int i;
	auxNodo->archivos_reduccion = list_create();
	for (i = 0; i < auxNodo->archivos_reduccion_cantidad; i++) {
		t_archivo_reducir_global* archivo = malloc(sizeof(t_archivo_reducir_global));

		////DESERIALIZO IP LARGO
		memcpy(&archivo->nodo_ip_largo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(archivo->nodo_ip_largo)));
		offset += tmp_len;
		if (archivo->nodo_ip_largo > 0) {
			//DESERIALIZO IP
			archivo->nodo_ip = malloc(archivo->nodo_ip_largo + 1);
			memcpy(archivo->nodo_ip, mensaje_Reduccion_Global + offset, tmp_len = archivo->nodo_ip_largo);
			archivo->nodo_ip[archivo->nodo_ip_largo] = '\0';
			offset += tmp_len;
		}
		////DESERIALIZO PUERTO LARGO
		memcpy(&archivo->nodo_puerto_largo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(archivo->nodo_puerto_largo)));
		offset += tmp_len;
		if (archivo->nodo_puerto_largo > 0) {
			//DESERIALIZO PUERTO
			archivo->nodo_puerto = malloc(archivo->nodo_puerto_largo + 1);
			memcpy(archivo->nodo_puerto, mensaje_Reduccion_Global + offset, tmp_len = archivo->nodo_puerto_largo);
			archivo->nodo_puerto[archivo->nodo_puerto_largo] = '\0';
			offset += tmp_len;
		}
		////DESERIALIZO NOMBRE DE ARCHIVO LARGO
		memcpy(&archivo->nombreArchivoLargo, mensaje_Reduccion_Global + offset, tmp_len = sizeof(typeof(archivo->nombreArchivoLargo)));
		offset += tmp_len;
		if (archivo->nombreArchivoLargo > 0) {
			//DESERIALIZO NOMBRE DE ARCHIVO
			archivo->nombreArchivo = malloc(archivo->nombreArchivoLargo + 1);
			memcpy(archivo->nombreArchivo, mensaje_Reduccion_Global + offset, tmp_len = archivo->nombreArchivoLargo);
			archivo->nombreArchivo[archivo->nombreArchivoLargo] = '\0';
			offset += tmp_len;
		}
		list_add(auxNodo->archivos_reduccion, archivo);
	}
	free(mensaje_Reduccion_Global);
	return auxNodo;
}

t_pNodo_almacenamiento_final* deserializeMsjAlmacenamientoFinal(char* mensaje_AlmacenamientoFinal) {
	t_pNodo_almacenamiento_final* auxNodo = malloc(sizeof(t_pNodo_almacenamiento_final));

	int offset = 0, tmp_len = 0;
		//DESERIALIZO NODO_ID
		memcpy(&auxNodo->nodo_id, mensaje_AlmacenamientoFinal + offset, tmp_len = sizeof(typeof(auxNodo->nodo_id)));
		offset += tmp_len;
		//DESERIALIZO E NODO_IP_LARGO
		memcpy(&auxNodo->nodo_ip_largo, mensaje_AlmacenamientoFinal + offset, tmp_len = sizeof(typeof(auxNodo->nodo_ip_largo)));
		offset += tmp_len;
		if(auxNodo->nodo_ip_largo>0){

			auxNodo->nodo_ip= malloc(auxNodo->nodo_ip_largo + 1);
			//DESERIALIZO EL nodo_IP
			memcpy(auxNodo->nodo_ip, mensaje_AlmacenamientoFinal + offset,tmp_len = auxNodo->nodo_ip_largo );
			auxNodo->nodo_ip[auxNodo->nodo_ip_largo] = '\0';
			offset += tmp_len;
		}
		//DESERIALIZO EL NODO_PUERTO_LARGO
		memcpy(&auxNodo->nodo_puerto_largo, mensaje_AlmacenamientoFinal + offset, tmp_len = sizeof(typeof(auxNodo->nodo_puerto_largo)));
		offset += tmp_len;
		if (auxNodo->nodo_puerto_largo > 0) {
			//DESERIALIZO EL NODO_PUERTO
			auxNodo->nodo_puerto = malloc(auxNodo->nodo_puerto_largo + 1);
			memcpy(auxNodo->nodo_puerto, mensaje_AlmacenamientoFinal + offset,tmp_len = auxNodo->nodo_puerto_largo);
			auxNodo->nodo_puerto[auxNodo->nodo_puerto_largo] = '\0';
			offset += tmp_len;
		}
		//DESERIALIZO ARCHIVO_FINAL_LARGO
		memcpy(&auxNodo->archivo_final_largo, mensaje_AlmacenamientoFinal + offset, tmp_len = sizeof(typeof(auxNodo->archivo_final_largo)));
		offset += tmp_len;
		if(auxNodo->archivo_final_largo>0){
		auxNodo->archivo_final = malloc(auxNodo->archivo_final_largo + 1);
			//DESERIALIZO EL ARCHIVO_FINAL
			memcpy(auxNodo->archivo_final, mensaje_AlmacenamientoFinal + offset,tmp_len = auxNodo->archivo_final_largo);
			auxNodo->archivo_final[auxNodo->archivo_final_largo] = '\0';
			offset += tmp_len;
		}
		free(mensaje_AlmacenamientoFinal);
	return auxNodo;
}

char* serializeSolicitarJob(t_pSolicitar_Job* param_Solicitar_Job, int* largo){
	char* empaquetado = malloc(sizeof(typeof(param_Solicitar_Job->largoArchivoTransformar))
			+ param_Solicitar_Job->largoArchivoTransformar);

	int offset = 0, tmp_size = 0;
	memset(empaquetado + offset, 0, sizeof(typeof(param_Solicitar_Job->largoArchivoTransformar)));
	memcpy(empaquetado + offset, &param_Solicitar_Job->largoArchivoTransformar,
			tmp_size = sizeof(typeof(param_Solicitar_Job->largoArchivoTransformar)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, param_Solicitar_Job->largoArchivoTransformar);
	memcpy(empaquetado + offset, param_Solicitar_Job->nombreArchivoTransformar,
			tmp_size = param_Solicitar_Job->largoArchivoTransformar);
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

char* serializeRespuestaEtapa(t_mensaje_resultado_etapa* pRespuestaEtapa, int* largo){
	char* empaquetado = malloc(sizeof(pRespuestaEtapa->bloque)
			+ sizeof(pRespuestaEtapa->id_master)
			+ sizeof(pRespuestaEtapa->id_nodo)
			+ sizeof(pRespuestaEtapa->nombreArchivoLargo)
			+ pRespuestaEtapa->nombreArchivoLargo);

	int offset = 0, tmp_size = 0;

	memset(empaquetado + offset, 0, sizeof(typeof(pRespuestaEtapa->id_nodo)));
	memcpy(empaquetado + offset, &pRespuestaEtapa->id_nodo,
			tmp_size = sizeof(typeof(pRespuestaEtapa->id_nodo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(pRespuestaEtapa->id_master)));
	memcpy(empaquetado + offset, &pRespuestaEtapa->id_master,
			tmp_size = sizeof(typeof(pRespuestaEtapa->id_master)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(pRespuestaEtapa->bloque)));
	memcpy(empaquetado + offset, &pRespuestaEtapa->bloque,
			tmp_size = sizeof(typeof(pRespuestaEtapa->bloque)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(pRespuestaEtapa->nombreArchivoLargo)));
	memcpy(empaquetado + offset, &pRespuestaEtapa->nombreArchivoLargo,
			tmp_size = sizeof(typeof(pRespuestaEtapa->nombreArchivoLargo)));
	offset += tmp_size;
	if(pRespuestaEtapa->nombreArchivoLargo > 0) {
		memset(empaquetado + offset, 0, pRespuestaEtapa->nombreArchivoLargo);
		memcpy(empaquetado + offset, pRespuestaEtapa->nombreArchivo,
		tmp_size = pRespuestaEtapa->nombreArchivoLargo);
		offset += tmp_size;
	}
	*largo = offset;
	return empaquetado;
}

char* serializeTransformarWorker(t_msj_transformacion_worker* msj_transformar_worker, int* largo){
	char* empaquetado = malloc(sizeof(typeof(msj_transformar_worker->bloqueATransformar))
			+ sizeof(typeof(msj_transformar_worker->bloqueATransformar_tamanio))
			+ sizeof(typeof(msj_transformar_worker->scripTransformador_largo))
			+ msj_transformar_worker->scripTransformador_largo
			+ sizeof(typeof(msj_transformar_worker->archivo_destino_transformacion_largo))
			+ msj_transformar_worker->archivo_destino_transformacion_largo);

	int offset = 0, tmp_size = 0;
	memset(empaquetado + offset, 0, sizeof(typeof(msj_transformar_worker->bloqueATransformar)));
	memcpy(empaquetado + offset, &msj_transformar_worker->bloqueATransformar,
			tmp_size = sizeof(typeof(msj_transformar_worker->bloqueATransformar)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_transformar_worker->bloqueATransformar_tamanio)));
	memcpy(empaquetado + offset, &msj_transformar_worker->bloqueATransformar_tamanio,
			tmp_size = sizeof(typeof(msj_transformar_worker->bloqueATransformar_tamanio)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_transformar_worker->scripTransformador_largo)));
	memcpy(empaquetado + offset, &msj_transformar_worker->scripTransformador_largo,
			tmp_size = sizeof(typeof(msj_transformar_worker->scripTransformador_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_transformar_worker->scripTransformador_largo);
	memcpy(empaquetado + offset, msj_transformar_worker->scriptTransformador,
			tmp_size = msj_transformar_worker->scripTransformador_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_transformar_worker->archivo_destino_transformacion_largo)));
	memcpy(empaquetado + offset, &msj_transformar_worker->archivo_destino_transformacion_largo,
			tmp_size = sizeof(typeof(msj_transformar_worker->archivo_destino_transformacion_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_transformar_worker->archivo_destino_transformacion_largo);
	memcpy(empaquetado + offset, msj_transformar_worker->archivo_destino_transformacion,
			tmp_size = msj_transformar_worker->archivo_destino_transformacion_largo);
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

char* serializeReducirLocalWorker(t_msj_reduccion_local_worker* msj_reducir_worker, int* largo){

	char* empaquetado = malloc(sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)) + msj_reducir_worker->scriptReduccion_largo
		+ sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)) + msj_reducir_worker->destino_reduccion_largo
		+ sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));

	int offset = 0, tmp_size = 0;
	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)));
	memcpy(empaquetado + offset, &msj_reducir_worker->scriptReduccion_largo,
			tmp_size = sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_reducir_worker->scriptReduccion_largo);
	memcpy(empaquetado + offset, msj_reducir_worker->scriptReduccion,
			tmp_size = msj_reducir_worker->scriptReduccion_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)));
	memcpy(empaquetado + offset, &msj_reducir_worker->destino_reduccion_largo,
			tmp_size = sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_reducir_worker->destino_reduccion_largo);
	memcpy(empaquetado + offset, msj_reducir_worker->destino_reduccion,
			tmp_size = msj_reducir_worker->destino_reduccion_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));
	memcpy(empaquetado + offset, &msj_reducir_worker->archivos_reduccion_cantidad,
			tmp_size = sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));
	offset += tmp_size;

	int i;

	for (i = 0; i < msj_reducir_worker->archivos_reduccion_cantidad; i++){
		t_archivo_reducir_local* archivoLocal = malloc(sizeof(t_archivo_reducir_local));
		archivoLocal = list_get(msj_reducir_worker->archivos_reduccion, i);

		empaquetado = realloc(empaquetado,offset + sizeof(typeof(archivoLocal->nombreArchivoLargo))
						+ archivoLocal->nombreArchivoLargo);

		memset(empaquetado + offset, 0, sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		memcpy(empaquetado + offset, &archivoLocal->nombreArchivoLargo, tmp_size = sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		offset += tmp_size;

		memset(empaquetado + offset, 0, archivoLocal->nombreArchivoLargo);
		memcpy(empaquetado + offset, archivoLocal->nombreArchivo, tmp_size = archivoLocal->nombreArchivoLargo);
		offset += tmp_size;
	}
	*largo = offset;
	return empaquetado;
}

char* serializeReducirGlobalWorker(t_msj_reduccion_global_worker* msj_reducir_worker, int* largo){
	char* empaquetado = malloc(sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)) + msj_reducir_worker->scriptReduccion_largo
			+ sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)) + msj_reducir_worker->destino_reduccion_largo
			+ sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));

	int offset = 0, tmp_size = 0;
	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)));
	memcpy(empaquetado + offset, &msj_reducir_worker->scriptReduccion_largo,
			tmp_size = sizeof(typeof(msj_reducir_worker->scriptReduccion_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_reducir_worker->scriptReduccion_largo);
	memcpy(empaquetado + offset, msj_reducir_worker->scriptReduccion,
			tmp_size = msj_reducir_worker->scriptReduccion_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)));
	memcpy(empaquetado + offset, &msj_reducir_worker->destino_reduccion_largo,
			tmp_size = sizeof(typeof(msj_reducir_worker->destino_reduccion_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_reducir_worker->destino_reduccion_largo);
	memcpy(empaquetado + offset, msj_reducir_worker->destino_reduccion,
			tmp_size = msj_reducir_worker->destino_reduccion_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));
	memcpy(empaquetado + offset, &msj_reducir_worker->archivos_reduccion_cantidad,
			tmp_size = sizeof(typeof(msj_reducir_worker->archivos_reduccion_cantidad)));
	offset += tmp_size;

	int i;

	for(i=0;i<msj_reducir_worker->archivos_reduccion_cantidad; i++){
		t_archivo_reducir_global* archivoLocal = malloc(sizeof(t_archivo_reducir_global));
		archivoLocal = list_get(msj_reducir_worker->archivos_reduccion, i);

		int nuevoTamanio = offset
		+ sizeof(typeof(archivoLocal->nombreArchivoLargo))
		+ archivoLocal->nombreArchivoLargo
		+ sizeof(typeof(archivoLocal->nodo_ip_largo))
		+ archivoLocal->nodo_ip_largo
		+ sizeof(typeof(archivoLocal->nodo_puerto_largo))
		+ archivoLocal->nodo_puerto_largo;

		empaquetado = (char*)realloc(empaquetado, nuevoTamanio);

		memset(empaquetado + offset, 0, sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		memcpy(empaquetado + offset, &archivoLocal->nombreArchivoLargo,
				tmp_size = sizeof(typeof(archivoLocal->nombreArchivoLargo)));
		offset += tmp_size;

		memset(empaquetado + offset, 0, archivoLocal->nombreArchivoLargo);
		memcpy(empaquetado + offset, archivoLocal->nombreArchivo, tmp_size = archivoLocal->nombreArchivoLargo);
		offset += tmp_size;

		memset(empaquetado + offset, 0, sizeof(typeof(archivoLocal->nodo_ip_largo)));
		memcpy(empaquetado + offset, &archivoLocal->nodo_ip_largo, tmp_size = sizeof(typeof(archivoLocal->nodo_ip_largo)));
		offset += tmp_size;

		memset(empaquetado + offset, 0, archivoLocal->nodo_ip_largo);
		memcpy(empaquetado + offset, archivoLocal->nodo_ip, tmp_size = archivoLocal->nodo_ip_largo);
		offset += tmp_size;

		memset(empaquetado + offset, 0, sizeof(typeof(archivoLocal->nodo_puerto_largo)));
		memcpy(empaquetado + offset, &archivoLocal->nodo_puerto_largo, tmp_size = sizeof(typeof(archivoLocal->nodo_puerto_largo)));
		offset += tmp_size;

		memset(empaquetado + offset, 0, archivoLocal->nodo_puerto_largo);
		memcpy(empaquetado + offset, archivoLocal->nodo_puerto, tmp_size = archivoLocal->nodo_puerto_largo);
		offset += tmp_size;
	}
	*largo = offset;
	return empaquetado;
}

char* serializeAlmacenamientoFinalWorker(t_msj_almacenamiento_final_worker* msj_almacenamiento_final_worker, int* largo){

	char* empaquetado = malloc(sizeof(typeof(msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo))
						+ msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo
						+ sizeof(typeof(msj_almacenamiento_final_worker->archivo_reduccion_global_largo))
						+ msj_almacenamiento_final_worker->archivo_reduccion_global_largo);

	int offset = 0, tmp_size = 0;
	memset(empaquetado + offset, 0, sizeof(typeof(msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo)));
	memcpy(empaquetado + offset, &msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo,
			tmp_size = sizeof(typeof(msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo);
	memcpy(empaquetado + offset, msj_almacenamiento_final_worker->archivo_almacenamiento_final,
			tmp_size = msj_almacenamiento_final_worker->archivo_almacenamiento_final_largo);
	offset += tmp_size;

	memset(empaquetado + offset, 0, sizeof(typeof(msj_almacenamiento_final_worker->archivo_reduccion_global_largo)));
	memcpy(empaquetado + offset, &msj_almacenamiento_final_worker->archivo_reduccion_global_largo,
			tmp_size = sizeof(typeof(msj_almacenamiento_final_worker->archivo_reduccion_global_largo)));
	offset += tmp_size;

	memset(empaquetado + offset, 0, msj_almacenamiento_final_worker->archivo_reduccion_global_largo);
	memcpy(empaquetado + offset, msj_almacenamiento_final_worker->archivo_reduccion_global,
			tmp_size = msj_almacenamiento_final_worker->archivo_reduccion_global_largo);
	offset += tmp_size;

	*largo = offset;

	return empaquetado;
}
