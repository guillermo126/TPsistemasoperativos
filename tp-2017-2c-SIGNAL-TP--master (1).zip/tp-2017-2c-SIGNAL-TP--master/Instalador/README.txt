Para correr el script install_signal.sh tener en cuenta lo siguiente:

El script recibe dos parametros:

install_signal.sh <modo de ejecucion> <proceso a instalar> <flag_primera_vez>

donde <modo de ejecucion> puede ser:

	online: el script utilizara el comando git clone para bajar de github todos los repositorios de los proyectos usados.

	usb: el script no se conectara a github y asumira que los directorios ya se encuentran en sus rutas correspondientes, 	que son las siguientes

	el repositorio de Yama se debe encontrar descargado en el directorio /home/utnso/git/signal-TP-/Yama
	el repositorio de las Commons se debe encontrar descargado en el directorio /home/utnso/git/commons
	el repositorio del Readline se debe encontrar descargado en el directorio /home/utnso/git/readline


donde <proceso a instalar> puede ser:

	datanode
	workernode
	yama
	master
	filesystem
	
donde <flag_primera_vez> puede ser:

	0:Es la primera vez que se corre el script, se instala todo, commons, shared library,parser y proceso
	1:No se instalan las commons,parser y shared library ya que es la segunda vez que se corre el script

Directorio de ejecutables:
	Al finalizar la instalación todos los ejecutables se encontraran en /home/utnso/signal-TP-/<proceso>
	junto a sus directorios de config y log, por lo cual, los ejecutables estan en un directorio DISTINTO del repositorio
	git que contiene los archivos fuentes.
