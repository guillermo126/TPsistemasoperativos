#!/usr/bin/env bash

repository_commons="https://github.com/sisoputnfrba/so-commons-library.git"
repository_signal="https://github.com/sisoputnfrba/tp-2017-2c-SIGNAL-TP-.git"
localFolder_git="/home/utnso/git/"
localFolder_SIGNAL="/home/utnso/git/SIGNAL-TP-"
localFolder_commons="/home/utnso/git/commons"

file_commons="/usr/lib/libcommons.so"
file_signal="/home/utnso/SIGNAL-TP-/SharedLibrarySignalTP/src/build/libSharedLibrary.so"

localFolder_Master="/home/utnso/SIGNAL-TP-/Master"
localFolder_Yama="/home/utnso/SIGNAL-TP-/Yama/"
localFolder_FileSystem="/home/utnso/SIGNAL-TP-/FileSystem/metadata/archivos"
localFolder_FileSystem_Bitmaps="/home/utnso/SIGNAL-TP-/FileSystem/metadata/bitmaps"
localFolder_WorkerNode="/home/utnso/SIGNAL-TP-/WorkerNode/temp/scripts"
localFolder_DataNode="/home/utnso/SIGNAL-TP-/DataNode/databin"

export LD_LIBRARY_PATH=/home/utnso/git/SIGNAL-TP-/SharedLibrarySignalTP/src/build

#desinstalo instalaciones pasadas para volver a ejecutar el script
if ! [ "$3" = "1" ] ; then
echo 'utnso' | sudo -S rm -f /usr/lib/libcommons.so
echo 'utnso' | sudo -S rm -rf /usr/include/commons
fi
#borro directorios de instalacion pasada, para poder volver a ejecutar el script
#echo 'utnso' | sudo -S rm -rf /home/utnso/SIGNAL-TP-
#echo 'utnso' | sudo -S rm -rf /home/utnso/commons

mkdir -p "$localFolder_git"
mkdir -p "$localFolder_SIGNAL"
mkdir -p "$localFolder_commons"
mkdir -p "$localFolder_Master"
mkdir -p "$localFolder_Yama"
mkdir -p "$localFolder_FileSystem"
mkdir -p "$localFolder_FileSystem_Bitmaps"
mkdir -p "$localFolder_WorkerNode"
mkdir -p "$localFolder_DataNode"

#Se clona e instalan las commons

if ! [ -f "$file_commons" ] ; then
	echo instalando las commons
	if [ "$1" = "online" ] ; then
		git clone "$repository_commons" "$localFolder_commons"
		if [ "$?" = "0" ] ; then
			echo se clono el repositorio las commons satisfactoriamente
		else
			echo no se pudo clonar el repositorio de las commons
			exit 1
		fi
	fi
	cd "$localFolder_commons"
	echo 'utnso' | sudo -S make install 
	echo se instalaron las commons satisfactoriamente
fi

#Se clona repositorio SIGNAL
if ! [ -f "$file_signal" ] ; then
echo file_signal
	if [ "$1" = "online" ] ; then
		echo clonando el repositorio SIGNAL
		git clone "$repository_signal" "$localFolder_SIGNAL" -b master --depth=1
		if [ "$?" = "0" ] ; then
			echo se clono el repositorio SIGNAL-TP- satisfactoriamente
		else
			echo no se pudo clonar el repositorio SIGNAL-TP-
			exit 1
		fi
	fi


	#Se instala shared library SIGNAL
	echo instalando la shared library de SIGNAL-TP-
	cd "$localFolder_SIGNAL"
	cd SharedLibrarySignalTP
	cd src
	make clean
	make all
	echo se genero SharedLibrary.so en la ruta /home/utnso/git/SIGNAL-TP-/SharedLibrarySignalTP/src/build
	export LD_LIBRARY_PATH=/home/utnso/git/SIGNAL-TP-/SharedLibrarySignalTP/src/build
fi
case $2 in

#Dejo este ejemplo por si algun proceso necesita que se instalen otras librerias de usuario
#FileSystem)
	#Se clona e instala la libreria pkmn-utils
#	echo instalando pkmn-utils
#	if [ "$1" = "online" ] ; then
#		git clone "$repository_pkmn_utils" "$localFolder_pkmn_utils"
#		if [ "$?" = "0" ] ; then
#			echo se clono el repositorio pkmn-utils satisfactoriamente
#		else
#			echo no se pudo clonar el repositorio pkmn-utils
#			exit 1
#		fi
#	fi
	
#	cd "$localFolder_pkmn_utils"
#	cd src
#	make all
#	echo 'utnso' | sudo -S make install
#	echo se instalo pkmn-utils satisfactoriamente

yama)
	#Se instala proceso YAMA
	echo Instalando el proceso Yama
	cd "$localFolder_SIGNAL"
	cd Yama
	make clean
	make all
	cd "$localFolder_Yama"
	mkdir log
	mkdir config
	cd config
	cp /home/utnso/git/SIGNAL-TP-/Yama/config/yama.cfg . 
	echo Se termino la instalacion del proceso Yama
	echo El directorio del ejecutable es /home/utnso/SIGNAL-TP-/Yama/
	echo "Ejecutar mediante ./Yama"
	echo Suerte maquinola;;
master)
	#Se instala proceso Master
	echo Instalando el proceso Master
	cd "$localFolder_SIGNAL"
	cd Master
	make clean
	make all
	cd "$localFolder_Master"
	mkdir log
	mkdir config
	mkdir scripts
	cd config
	cp /home/utnso/git/SIGNAL-TP-/Master/config/master.cfg . 
	cd ..
	cd scripts
	cp /home/utnso/git/SIGNAL-TP-/Master/scripts/* .
	echo Se termino la instalacion del proceso Master
	echo El directorio del ejecutable es /home/utnso/SIGNAL-TP-/Master/
	echo "Ejecutar mediante ./Master"
	echo Suerte lince;;
filesystem)
	#Se instala proceso FileSystem
	echo Instalando el proceso FileSystem
	echo instalando readline
	echo 'utnso' | sudo -S apt-get -y install libreadline6 libreadline6-dev
	echo instalando openssl
	echo 'utnso' | sudo -S apt-get -y install openssl
	echo instalando libssl-dev
	echo 'utnso' | sudo -S apt-get update
	echo 'utnso' | sudo -S apt-get -y install libssl-dev
	cd "$localFolder_SIGNAL"	
	cd FileSystem
	make clean
	make all
	cd "$localFolder_FileSystem"
	cd ..
	cd ..
	mkdir log
	mkdir config
	mkdir DataSets
	cd config
	cp /home/utnso/git/SIGNAL-TP-/FileSystem/config/filesystem.cfg . 
	cd ..
	cd DataSets
	cp /home/utnso/git/SIGNAL-TP-/FileSystem/DataSets/* .
	echo Se termino la instalacion del proceso FileSystem
	echo El directorio del ejecutable es /home/utnso/SIGNAL-TP-/FileSystem/
	echo "Ejecutar mediante ./FileSystem"
	echo Esta es la vencida;;
worker)
	#Se instala proceso WorkerNode
	echo Instalando el proceso WorkerNode
	cd "$localFolder_SIGNAL"	
	cd WorkerNode
	make clean
	make all
	cd "$localFolder_WorkerNode"
	cd ..
	cd ..
	mkdir log
	mkdir config
	cd config
	cp /home/utnso/git/SIGNAL-TP-/WorkerNode/config/workernode.cfg . 
	echo Se termino la instalacion del proceso WorkerNode
	echo El directorio del ejecutable es /home/utnso/SIGNAL-TP-/Memoria/
	echo "Ejecutar mediante ./WorkerNode"
	echo Te tengo una fe barbara;;
datanode)
	#Se instala proceso DataNode
	echo Instalando el proceso DataNode
	cd "$localFolder_SIGNAL"	
	cd DataNode
	make clean
	make all
	cd "$localFolder_DataNode"
	cd ..
	mkdir log
	mkdir config
	cd config
	cp /home/utnso/git/SIGNAL-TP-/DataNode/config/datanode.cfg . 
	echo Se termino la instalacion del proceso DataNode
	echo El directorio del ejecutable es /home/utnso/SIGNAL-TP-/DataNode/
	echo "Ejecutar mediante ./DataNode"
	echo Esta es la vencida;;
esac
exit 0
