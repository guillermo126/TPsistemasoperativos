/*
 * config.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/config.h>
#include <commons/log.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <pthread.h>

extern pthread_mutex_t mutex_yama_cfg;
//
#define PROGRAM_NAME "YAMA_SIGNAL_TP"
#define PATH_CONFIG_YAMA "config/yama.cfg"
#define PATH_LOG_YAMA "log/yama.log"
#define CANTIDAD_PARAMETROS_CONFIG 5

//estructura config del yama
typedef struct {
	char* ip_fs;
	int32_t puerto_fs;
	int32_t retardo;
	char* algoritmo;
	int disponibilidad;
} yama_config;

//Estructura global que contiene el archivo de configuración actual del yama
yama_config* yama_cfg;
//mutex para modificar la variable global del archivo de configuracion

//Estructura que representa el log del proceso yama
t_log* yama_log;
//mutex para usar el log
pthread_mutex_t mutex_yama_log;

/*
 * yama_config_create:
 * genera una estructura del tipo yama_config leyendo los parametros
 * desde el archivo de configuracion
 */
int yama_config_create(yama_config *config,char* config_path);

/*
 * yama_config_destroy:
 * destruye una estructura del tipo yama_config
 */
void yama_config_destroy(yama_config *config);

/*
 * log_config:
 * loguea los valores de una estructura del tipo config
 * */
void log_config(yama_config *config);

int configYlogDeYama();

#endif /* SRC_CONFIG_H_ */
