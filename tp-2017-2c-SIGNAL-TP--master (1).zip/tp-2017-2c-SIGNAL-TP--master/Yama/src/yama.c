/*
 * yama.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#include "yama.h"

int main(int argc, char* argv[]) {
	//
	signal(SIGPIPE, SIG_IGN);
	int resultadoDeConfiguracion = configYlogDeYama();

	crearEstructurasGlobales();

	/*
	 if(resultadoDeConfiguracion){
	 log_error(yama_log, "main-> Error al cargar el archivo de configuracion");
	 return EXIT_FAILURE;
	 }



	 if(!crearServerMultiplexor()){
	 log_error(yama_log, "main-> Error al el servidor multiplexor");
	 return EXIT_FAILURE;

	 }

	 */
	if (resultadoDeConfiguracion) {
		log_error(yama_log, "main-> Error al cargar el archivo de configuracion");
		return EXIT_FAILURE;
	}


	if(!conectarseAProcesoFyleSystem()){
		log_error(yama_log, "main-> Error al conectar al FS");
				return EXIT_FAILURE;
	}

	handshake_t handshakeFs;

	handshakeFs = HANDSHAKE_YAMA;


	if(!enviar_handshake(&handshakeFs,socket_FS)){
	log_trace(yama_log,"Error al querer enviar HANDSHAKE al Fyle System");
	return EXIT_FAILURE;
	}

	if(!recibir_handshake(&handshakeFs,socket_FS)){
		log_trace(yama_log,"Error al querer enviar HANDSHAKE al Fyle System");
			return EXIT_FAILURE;
	}
	if(handshakeFs == ERROR_HANDSHAKE){
		log_error(yama_log,"Error de Handshake, solicitud rechazada por el proceso Fyle System");
		return EXIT_FAILURE;
	}
//	if(!create_thread_signal_monitor(SIGUSR1, &recargar_configuracion, yama_log)){
//		log_error(yama_log, "main-> Error creando senial de recarga de configuracion.");
//	}


	crear_hilos_para_signals(recargar_configuracion);

	//Se crea hilo para escuchar conexiones de master, multiplexacion

	crear_hilo_escuchar_conexiones_master(yama_log);
	crear_hilo_planificador(yama_log);
	crear_hilo_replanificacion(yama_log);

	liberarMemoria();

	return EXIT_SUCCESS;

}

void recargar_configuracion(int signal){
	if (signal == SIGUSR1) {
		log_trace(yama_log, "Recargando configuracion YAMA.");
		if (configYlogDeYama()) {
			log_error(yama_log, "MAIN->No se pudo recargar la configuracion.");
		}
	}
}

void* thread_signal_usr1(void* th_signal) {

	struct sigaction susr;

	susr.sa_handler = th_signal; //un struct para cada signal a tratar, struct del sigusr1
	susr.sa_flags = SA_RESTART; // si no se coloca este flag, la system call se interrumpe
	sigemptyset(&susr.sa_mask); //sa_mask contiene los signals que se pueden bloquear mientras, se trata el signal actual

	if (sigaction(SIGUSR1, &susr, NULL) == -1) {
		log_error(yama_log, "thread_signal_usr1 -> error al catchear signal SIGUSR1");
		exit(1);
	}

	while (1)
		sleep(1);
}

void crear_hilos_para_signals(void* th_signal) {

	pthread_attr_t attr;
	pthread_t thread_usr1;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_create(&thread_usr1, &attr, &thread_signal_usr1, th_signal) < 0) {
		log_error(yama_log, "crear_hilos_para_signals -> error al crear el hilo para atender signal usr1");
	}
	log_trace(yama_log, "crear_hilos_para_signals -> hilo para atender signal usr1 creado");

	pthread_attr_destroy(&attr);
}
