/*
 * serialize-yama.h
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */
//
#ifndef SRC_SERIALIZE_YAMA_H_
#define SRC_SERIALIZE_YAMA_H_

#include "config.h"
#include "yama.h"

void liberarMemoria();
char* serializeMsjTransformacion(t_pNodo_transformacion*  nodo_para_master , int* largo);
t_mensaje_resultado_etapa* deserializarResultado(char * buffer);
//void ejecutarAlgoritmo(t_list *listaNodosBloques,t_list* listaHistorialNodos);


#endif /* SRC_SERIALIZE_YAMA_H_ */
