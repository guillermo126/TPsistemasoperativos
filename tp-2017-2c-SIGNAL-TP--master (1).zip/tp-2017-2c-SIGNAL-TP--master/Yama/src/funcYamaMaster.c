/*
 * funcYamaMaster.c
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */
#include "funcYamaMaster.h"


//
bool es_master_aceptado(master_aceptado *master){
	if(master->sock_fd == socket_lectura_master)return true;
	return false;
}

int buscar_en_master_aceptados(int sock_fd){

	socket_lectura_master = sock_fd;
	t_list* master_encontrado=list_filter(yama_masters_aceptados, (void*)es_master_aceptado);
	if(list_is_empty(master_encontrado)){
		list_destroy(master_encontrado);
		return 0;
		}
	list_destroy(master_encontrado);
		return 1;
}


master_aceptado *master_create(int sock) {
	master_aceptado *nuevo_master = malloc(sizeof(master_aceptado));
	nuevo_master->sock_fd = sock;
	return nuevo_master;
}

void aceptar_master(int sock_fd){
	master_aceptado *nuevo_master = master_create(sock_fd);
	list_add(yama_masters_aceptados,nuevo_master);

	log_trace(yama_log, "aceptar_master-> Handshake correcto. Se ingresa master al sistema");
	log_trace(yama_log, "aceptar_master-> Cantidad de masters activos en el sistema: %d",list_size(yama_masters_aceptados));
}

int validar_handshake(handshake_t codigoValidar, int sock_fd){

	t_mensaje_HANDSHAKE *msjeHandshake = malloc(sizeof(t_mensaje_HANDSHAKE));
	if(!recibir_handshake(msjeHandshake,sock_fd)){

		log_error(yama_log,"validar_handshake->Error al recibir el mensaje de Handshake");

		return 0;
	}

	log_trace(yama_log,"validar_handshake->Se recibio el mensaje de handshake");

	if(msjeHandshake->codigoHandshake == codigoValidar){

		log_trace(yama_log,"validar_handshake->Proceso autenticado");
		msjeHandshake->codigoHandshake =  HANDSHAKE_YAMA;

		if(!enviar_handshake(msjeHandshake,sock_fd)){

			log_error(yama_log,"validar_handshake->Error al enviar la respuesta de Handshake");

			return 0;
		}else{

			log_trace(yama_log,"validar_handshake->Se envio la respuesta OK de handshake");

		}
	}else{

		log_trace(yama_log,"validar_handshake->Proceso no autenticado");

		msjeHandshake->codigoHandshake = ERROR_HANDSHAKE;
		if(!enviar_handshake(msjeHandshake,sock_fd)){

			log_error(yama_log,"validar_handshake->Error al enviar la respuesta de Handshake");

			return 0;
		}else{

			log_trace(yama_log,"validar_handshake->Se envio la respuesta NO_OK de handshake");

			return 0;
		}
	}
	free(msjeHandshake);
	return 1;
}
void mostrarLista(){
	void obtenerDato( void* data){
		estado_de_un_job* estado = (estado_de_un_job*) data;
		log_trace(yama_log," el numero de master es:%d, el nodo es:%s, el bloque es:%d, la estapa es:%s,el archivo es:%s, el estado es:%s",
				estado->master,estado->nodo,estado->bloque,estado->etapa,estado->archivoTemporal,estado->estado);

	}

	list_iterate(tabla_de_estados, obtenerDato);

}


estado_de_un_job* tomarElemento(char* etapa,int master_id,int nodo_num,int num_bloque, char* estado){
	estado_de_un_job* unNodo;// = malloc(sizeof(estado_de_un_job));
	//estado_de_un_job* unNodo = malloc(sizeof(estado_de_un_job));
	t_list* listaConSoloUnaEtapa ;
	t_list* nueva = list_create();

	bool etapa_selecionada(estado_de_un_job *nodo){
		if(strcmp(etapa,nodo->etapa) == 0){
			return true;
		}else{
		return false;
		}
	}

	//filtramos por etapa
	pthread_mutex_lock(&mutex_tabla_de_estados);
	list_add_all(nueva,tabla_de_estados);
	//t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)etapa_selecionada);
	pthread_mutex_unlock(&mutex_tabla_de_estados);
	listaConSoloUnaEtapa = list_filter(nueva,(void*)etapa_selecionada);

	if(nodo_num == -1){
	bool busquedaPorEstado(estado_de_un_job *nodo){
		if(strcmp(nodo->estado,estado) == 0 && nodo->id_master == master_id ){
			return true;
		}else{
		return false;
		}



	}
	// elegimos el primero que no tenga nada
				 unNodo=(estado_de_un_job*) list_find(listaConSoloUnaEtapa,(void*)busquedaPorEstado);
	}else{
	bool busquedaPorBloque(estado_de_un_job *nodo){

		//char**nodo1 = string_split(nodo->nodo, " ");

		char*num_nodo_s = string_itoa(nodo_num);

		char* string_a_comparar = string_new();
		string_append(&string_a_comparar,"NODO ");
		string_append(&string_a_comparar,num_nodo_s);

		//strsplit(nodo->nodo, " ", nodo1);


		//por ahora elimino strcmp(nodo->estado,estado) == 0
		//agrego la comparacion tambien por bloque
		//atoi(nodo1[1]) == nodo_num &&
		if(  nodo->id_master == master_id  && strcmp(string_a_comparar,nodo->nodo) == 0 && nodo->bloque == num_bloque && strcmp(nodo->estado,estado) == 0 ){
//			free(nodo1[0]);
//			free(nodo1[1]);
			free(num_nodo_s);
			free(string_a_comparar);
			return true;
		}else {
//			free(nodo1[0]);
//			free(nodo1[1]);
			free(num_nodo_s);
			free(string_a_comparar);
			return false;
		}
	}


	bool busquedaPorNodo(estado_de_un_job *nodo){

//			char**nodo1 = string_split(nodo->nodo, " ");

			//strsplit(nodo->nodo, " ", nodo1);
			char*num_nodo_s = string_itoa(nodo_num);

			char* string_a_comparar = string_new();
			string_append(&string_a_comparar,"NODO ");
			string_append(&string_a_comparar,num_nodo_s);



			//por ahora elimino strcmp(nodo->estado,estado) == 0
			//agrego la comparacion tambien por bloque
			//atoi(nodo1[1]) == nodo_num
			if(  nodo->id_master == master_id  && strcmp(string_a_comparar,nodo->nodo) == 0  && strcmp(nodo->estado,estado) == 0 ){
//				free(nodo1[0]);
//				free(nodo1[1]);
				free(num_nodo_s);
				free(string_a_comparar);
				return true;
			}else{
//				free(nodo1[0]);
//				free(nodo1[1]);
				free(num_nodo_s);
				free(string_a_comparar);
			return false;
			}

		}


	// elegimos el primero que conicida con el master,
	if(num_bloque != -1){
		unNodo= (estado_de_un_job*)list_find(listaConSoloUnaEtapa,(void*)busquedaPorBloque);
	} else{
		unNodo= (estado_de_un_job*)list_find(listaConSoloUnaEtapa,(void*)busquedaPorNodo);
	}

}
	list_clean(nueva);
	list_destroy(nueva);
	list_clean(listaConSoloUnaEtapa);
	list_destroy(listaConSoloUnaEtapa);
	return unNodo;
}

void pasarDeEstructura(estado_de_un_job* nodo_estado,t_pNodo_transformacion* nodomaster){
	char* puerto;

  char**nodo = string_split(nodo_estado->nodo, " ");

	nodomaster->nodo_id = atoi(nodo[1]);
	nodomaster->nodo_ip =string_new();
    string_append(&nodomaster->nodo_ip,nodo_estado->ip);
    nodomaster->nodo_ip_largo = string_length(nodomaster->nodo_ip);

    nodomaster->nodo_puerto = string_new();
    puerto = string_itoa(nodo_estado->puerto);
    string_append(&nodomaster->nodo_puerto,puerto);
    nodomaster->nodo_puerto_largo = string_length(nodomaster->nodo_puerto);

    nodomaster->archivo_resultado = string_new();
    string_append(&nodomaster->archivo_resultado,nodo_estado->archivoTemporal);
    nodomaster->archivo_resultado_largo = string_length(nodomaster->archivo_resultado);

    nodomaster->bloque = nodo_estado->bloque;

    nodomaster->bytesOcupados = nodo_estado->bytesOcupados;
    free(puerto);
    free(nodo[0]);
    free(nodo[1]);
    free(nodo);

}

bool se_terminaron_transformacion(int nodo_selecionado, int master_selecionado){
	char* nodoAComparar = string_new();
	string_append(&nodoAComparar,"NODO ");
	char*nod_select = string_itoa(nodo_selecionado);
	string_append(&nodoAComparar,nod_select);
	bool retorno;

	bool etapa_transformacion(estado_de_un_job *nodo){
		//char**nodoaux = string_split(nodo->nodo, " ");     //atoi(nodoaux[1]) == nodo_selecionado
		if(strcmp(nodo->etapa, "TRANSFORMACION")== 0 && nodo->id_master == master_selecionado && strcmp(nodo->nodo,nodoAComparar) ==0 )return true;
		return false;
	}

	//filtramos por etapa
	pthread_mutex_lock(&mutex_tabla_de_estados);
	t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)etapa_transformacion);
	pthread_mutex_unlock(&mutex_tabla_de_estados);

	bool transformaciones_echas(estado_de_un_job *nodo){
		//char**nodoaux = string_split(nodo->nodo, " ");
		//nodo->id_master == master_selecionado && atoi(nodoaux[1]) == nodo_selecionado &&
		if( strcmp(nodo->estado,"FINALIZADO")== 0 )return true;
		return false;
	}

	free(nodoAComparar);
	free(nod_select);
	retorno = list_all_satisfy(listaConSoloUnaEtapa,(void*)transformaciones_echas);
	list_destroy(listaConSoloUnaEtapa);
	return retorno;

}

bool se_terminaron_reducciones_locales( int master_selecionado){
	bool retorno;
	bool etapa_reduccionLocal(estado_de_un_job *nodo){
			if(strcmp(nodo->etapa, "REDUCCION LOCAL")  == 0 && nodo->id_master == master_selecionado && strcmp(nodo->estado,"ABORTIVO") != 0 )return true;
			return false;
		}

		//filtramos por etapa
		pthread_mutex_lock(&mutex_tabla_de_estados);
		t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)etapa_reduccionLocal);
		pthread_mutex_unlock(&mutex_tabla_de_estados);

		bool reducciones_echas(estado_de_un_job *nodo){
			//char**nodoaux = string_split(nodo->nodo, " ");
			if( nodo->id_master == master_selecionado && strcmp(nodo->estado,"FINALIZADO") == 0  )return true;
			return false;
		}

		retorno = list_all_satisfy(listaConSoloUnaEtapa,(void*)reducciones_echas);
		list_destroy(listaConSoloUnaEtapa);
		return retorno;

}






int crear_hilo_escuchar_conexiones_master(t_log *logger){
	pthread_attr_t attr;
	pthread_t thread_multiplexing;
//	pthread_attr_init(&attr);
//	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	void *res;
	st_escuchar_conexion *arg_escuchar_conexion = malloc(sizeof(st_escuchar_conexion));
	arg_escuchar_conexion->cola = 50;

	arg_escuchar_conexion->puerto = string_itoa(5000);

	arg_escuchar_conexion->logger = yama_log;

	//pthread_create(&thread_multiplexing, &attr, &escuchar_conexiones_master, (void*)arg_escuchar_conexion);

	if (pthread_create(&thread_multiplexing, NULL, &escuchar_conexiones_master, (void*)arg_escuchar_conexion) < 0) {

		log_error(logger,
				"funciones_estructuras_yama->crear_hilo_escuchar_conexiones_master -> error al crear el hilo para multiplexar");

		return 1;
	}
//	if(!pthread_attr_destroy(&attr)){
//
//		log_trace(logger,
//				"funciones_estructuras_yama->crear_hilo_escuchar_conexiones_master -> hilo para multiplexar creado");
//
//	}else{
//
//		log_error(logger,
//				"funciones_estructuras_yama->crear_hilo_escuchar_conexiones_master -> fallo el pthread destroy");
//
//		return 1;
//	}


	//pthread_join(thread_multiplexing, NULL);
//	if(!pthread_join(thread_multiplexing, NULL)){
//		log_trace(logger,
//				"funciones_estructuras_kernel->crear_hilo_escuchar_conexiones_consola -> hilo joineado");
//	}else{
//		log_error(logger,
//				"funciones_estructuras_kernel->crear_hilo_escuchar_conexiones_consola -> fallo el pthread join");
//		return 1;
//	}
//	free(res);
	return 0;
}

void *escuchar_conexiones_master(void* arg_escuchar_conexion){
	st_escuchar_conexion  *st_esc = arg_escuchar_conexion;
	if (!socket_multiplexing( "127.0.0.1", st_esc->puerto , st_esc->cola, &conexion_nuevo_ProcesoMaster, &recibir_mensajesDeMaster, &dummy_func_escribir,st_esc->logger)){

		log_error(st_esc->logger,
				"funciones_estructuras_yama->escuchar_conexiones_master -> la funcion socket_multiplexing devolvió error");

	}

	log_trace(st_esc->logger,"Servidor para MASTERS creado.");

	free(arg_escuchar_conexion);
	return NULL;
}

void mandarArchivosAMasterReduccion(t_pNodo_reduccion_global* nodoAMasterReduccionGlobal,t_mensaje_resultado_etapa* resultadoOperacion){
	estado_de_un_job *nodo_elegido;
	int index_tabla_filtrada = 0;
	int size_tabla_filtrada = 0;
	estado_de_un_job * elemento_archivo;
	t_archivo_reducir_global * archivo;
	t_list* lista_new;
	nodoAMasterReduccionGlobal->archivos_reduccion = list_create();


	bool filtros_reduccionLocal_finalizadas(estado_de_un_job *nodo){
		if(strcmp("REDUCCION LOCAL",nodo->etapa) == 0 && strcmp("FINALIZADO",nodo->estado) == 0 && nodo->id_master ==resultadoOperacion->id_master){
			return true;
		}else{
		return false;
		}
	}

	//filtramos por etapa
	pthread_mutex_lock(&mutex_tabla_de_estados);
	t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)filtros_reduccionLocal_finalizadas);
	pthread_mutex_unlock(&mutex_tabla_de_estados);
	size_tabla_filtrada = list_size(listaConSoloUnaEtapa);

	nodo_elegido = tomarElemento("REDUCCION GLOBAL",resultadoOperacion->id_master,resultadoOperacion->id_nodo,-1,"EN PROCESO");

	//primero mando el id
	nodoAMasterReduccionGlobal->nodo_id = resultadoOperacion->id_nodo;
	//mando la ip
	nodoAMasterReduccionGlobal->nodo_ip = string_new();
	string_append(&nodoAMasterReduccionGlobal->nodo_ip,nodo_elegido->ip);
	//largoip
	nodoAMasterReduccionGlobal->nodo_ip_largo = string_length(nodoAMasterReduccionGlobal->nodo_ip);
	//puerto
	nodoAMasterReduccionGlobal->nodo_puerto = string_new();
	char* nod_elegido_puer = string_itoa(nodo_elegido->puerto);
	string_append(&nodoAMasterReduccionGlobal->nodo_puerto,nod_elegido_puer);
	//largo puerto
	nodoAMasterReduccionGlobal->nodo_puerto_largo = string_length(nodoAMasterReduccionGlobal->nodo_puerto);
	//reduccion destino
	nodoAMasterReduccionGlobal->destino_reduccion = string_new();
	string_append(&nodoAMasterReduccionGlobal->destino_reduccion,nodo_elegido->archivoTemporal);
	//largo reduccuin destino
	nodoAMasterReduccionGlobal->destino_reduccion_largo = string_length(nodoAMasterReduccionGlobal->destino_reduccion);

	while(index_tabla_filtrada < size_tabla_filtrada){
			archivo = malloc(sizeof(t_archivo_reducir_global));
			elemento_archivo = (estado_de_un_job *) list_get(listaConSoloUnaEtapa,index_tabla_filtrada);

			//me fijo si tengo dos redus locales en el elemento y me quedo con la mas nueva
			bool filtrarPorNombre(void*data){
				estado_de_un_job* new = (estado_de_un_job*) data;

				return strcmp(new->archivoTemporal,elemento_archivo->archivoTemporal) == 0;

			}
			 lista_new= list_filter(listaConSoloUnaEtapa,filtrarPorNombre);

			if(list_size(lista_new) >1){
				//si tengo varios archivos con el mismo nombre tomo el ultimo
				estado_de_un_job * elemento_archivo1 = (estado_de_un_job *) list_get(listaConSoloUnaEtapa,list_size(lista_new)-1);
				archivo->nombreArchivo = string_new();
				string_append(&archivo->nombreArchivo,elemento_archivo1->archivoTemporal);

				archivo->nombreArchivoLargo = string_length(archivo->nombreArchivo);

			}else{
				//nombre archivo
				archivo->nombreArchivo = string_new();
				string_append(&archivo->nombreArchivo,elemento_archivo->archivoTemporal);

				archivo->nombreArchivoLargo = string_length(archivo->nombreArchivo);
			}
			char**nodo1 = string_split(nodo_elegido->nodo, " ");
			char**elem_ele = string_split(elemento_archivo->nodo," ");
			if(atoi(elem_ele[1]) != atoi(nodo1[1])){

			//ip
			archivo->nodo_ip = string_new();
			string_append(&archivo->nodo_ip,elemento_archivo->ip);

			archivo->nodo_ip_largo = string_length(archivo->nodo_ip);

			//puerto
			archivo->nodo_puerto = string_new();
			char*per = string_itoa(elemento_archivo->puerto);
			string_append(&archivo->nodo_puerto,per);
			free(per);
			archivo->nodo_puerto_largo = string_length(archivo->nodo_puerto);
			}else{
				//ip

			archivo->nodo_ip_largo = 0;

			//puerto
			archivo->nodo_puerto_largo = 0;


			}
			index_tabla_filtrada++;
			free(nodo1[0]);
			free(nodo1[1]);
			free(nodo1);
			free(elem_ele[0]);
			free(elem_ele[1]);
			free(elem_ele);

			list_add(nodoAMasterReduccionGlobal->archivos_reduccion,(void*)archivo);

		}

	nodoAMasterReduccionGlobal->archivos_reduccion_cantidad = list_size(nodoAMasterReduccionGlobal->archivos_reduccion);

free(nod_elegido_puer);
list_clean(listaConSoloUnaEtapa);
list_destroy(listaConSoloUnaEtapa);
list_clean(lista_new);
list_destroy(lista_new);



}

 void mandarAlmacenamientoFinal (t_pNodo_almacenamiento_final* nodoAMasterAlmacenamientoFinal,t_mensaje_resultado_etapa* resultadoOperacion){
	 estado_de_un_job * elemento_archivo;


		bool busquedaPorEstado(estado_de_un_job *nodo){
			if( strcmp("ALMACENAMIENTO FINAL",nodo->etapa) == 0 && strcmp(nodo->estado,"EN PROCESO") == 0 && nodo->id_master == resultadoOperacion->id_master ){
				return true;
			}else{
			return false;
			}
 }



		// elegimos el primero que no tenga nada
		pthread_mutex_lock(&mutex_tabla_de_estados);
		elemento_archivo= (estado_de_un_job*)list_find(tabla_de_estados,(void*)busquedaPorEstado);
		pthread_mutex_unlock(&mutex_tabla_de_estados);

		nodoAMasterAlmacenamientoFinal->archivo_final = string_new();
		string_append(&nodoAMasterAlmacenamientoFinal->archivo_final,resultadoOperacion->nombreArchivo);
		nodoAMasterAlmacenamientoFinal->archivo_final_largo = string_length(nodoAMasterAlmacenamientoFinal->archivo_final);

		nodoAMasterAlmacenamientoFinal->nodo_id = resultadoOperacion->id_nodo;
		nodoAMasterAlmacenamientoFinal->nodo_ip = string_new();
		string_append(&nodoAMasterAlmacenamientoFinal->nodo_ip,elemento_archivo->ip);
		nodoAMasterAlmacenamientoFinal->nodo_ip_largo =string_length(nodoAMasterAlmacenamientoFinal->nodo_ip);

		nodoAMasterAlmacenamientoFinal->nodo_puerto = string_new();
		char*puer = string_itoa(elemento_archivo->puerto);
		string_append(&nodoAMasterAlmacenamientoFinal->nodo_puerto,puer);

		nodoAMasterAlmacenamientoFinal->nodo_puerto_largo =string_length(nodoAMasterAlmacenamientoFinal->nodo_puerto);

		free(puer);


 }

void mandarArchivosAMasterTransformacion( t_pNodo_reduccion_local * nodoAMasterReduccionLocal,t_mensaje_resultado_etapa* resultadoOperacion){

	estado_de_un_job *nodo_elegido;
	int index_tabla_filtrada = 0;
	int size_tabla_filtrada = 0;
	estado_de_un_job * elemento_archivo;
	t_archivo_reducir_local * archivo;
	nodoAMasterReduccionLocal->archivos_reduccion = list_create();
	char* nuevo_string= string_new();
	char* resultado_operacion_id = string_itoa(resultadoOperacion->id_nodo);
	string_append(&nuevo_string,"NODO ");
	string_append(&nuevo_string,resultado_operacion_id);

	bool filtros_transformacion_finalizadas(estado_de_un_job *nodo){
		if(strcmp("TRANSFORMACION",nodo->etapa) == 0 && strcmp("FINALIZADO",nodo->estado) == 0 && nodo->id_master ==resultadoOperacion->id_master &&
				strcmp(nodo->nodo, nuevo_string) == 0){
			return true;
		}else{
		return false;
		}
	}

	//filtramos por etapa
	pthread_mutex_lock(&mutex_tabla_de_estados);
	t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)filtros_transformacion_finalizadas);
	pthread_mutex_unlock(&mutex_tabla_de_estados);

	size_tabla_filtrada = list_size(listaConSoloUnaEtapa);
	nodo_elegido = tomarElemento("REDUCCION LOCAL",resultadoOperacion->id_master,resultadoOperacion->id_nodo,-1,"EN PROCESO");
	//primero mando el id
	nodoAMasterReduccionLocal->nodo_id = resultadoOperacion->id_nodo;
	//mando la ip
	nodoAMasterReduccionLocal->nodo_ip = string_new();
	string_append(&nodoAMasterReduccionLocal->nodo_ip,nodo_elegido->ip);
	//largoip
	nodoAMasterReduccionLocal->nodo_ip_largo = string_length(nodoAMasterReduccionLocal->nodo_ip);
	//puerto
	nodoAMasterReduccionLocal->nodo_puerto = string_new();
	char* nod_elegi_puerto = string_itoa(nodo_elegido->puerto);
	string_append(&nodoAMasterReduccionLocal->nodo_puerto,nod_elegi_puerto);
	//largo puerto
	nodoAMasterReduccionLocal->nodo_puerto_largo = string_length(nodoAMasterReduccionLocal->nodo_puerto);
	//reduccion destino
	nodoAMasterReduccionLocal->destino_reduccion = string_new();
	string_append(&nodoAMasterReduccionLocal->destino_reduccion,nodo_elegido->archivoTemporal);
	//largo reduccuin destino
	nodoAMasterReduccionLocal->destino_reduccion_largo = string_length(nodoAMasterReduccionLocal->destino_reduccion);

	free(nod_elegi_puerto);


	while(index_tabla_filtrada < size_tabla_filtrada){
		archivo = malloc(sizeof(t_archivo_reducir_local));
		elemento_archivo = (estado_de_un_job *) list_get(listaConSoloUnaEtapa,index_tabla_filtrada);

		archivo->nombreArchivo = string_new();
		string_append(&archivo->nombreArchivo,elemento_archivo->archivoTemporal);

		archivo->nombreArchivoLargo = string_length(archivo->nombreArchivo);

		index_tabla_filtrada++;

		list_add(nodoAMasterReduccionLocal->archivos_reduccion,(void*)archivo);

	}

nodoAMasterReduccionLocal->archivos_reduccion_cantidad = list_size(nodoAMasterReduccionLocal->archivos_reduccion);

free(nuevo_string);
free(resultado_operacion_id);
list_clean(listaConSoloUnaEtapa);
list_destroy(listaConSoloUnaEtapa);
}

static void eliminarArchivos(void*data){
	t_archivo_reducir_local* archivos = (t_archivo_reducir_local* ) data;
	free(archivos->nombreArchivo);
	free(archivos);

}

int recibir_operacionMaster(int sock){
    t_mensaje_HEADER headermaster;

	estado_de_un_job* nodo_elegido;
	tratar_job* nuevo_job;
	carga_nodo * carga_de_nodo;
	//historial_nodo * historial_de_un_nodo;

	//t_pNodo_transformacion* nodoAmaster = malloc(sizeof(t_pNodo_transformacion));
	t_pNodo_reduccion_local * nodoAMasterReduccionLocal = malloc(sizeof(t_pNodo_reduccion_local));
	t_pNodo_reduccion_global * nodoAMasterReduccionGlobal = malloc(sizeof(t_pNodo_reduccion_global));
	t_pNodo_almacenamiento_final * nodoAMasterAlmacenamientoFinal = malloc(sizeof(t_pNodo_almacenamiento_final));
	t_mensaje_resultado_etapa* resultadoOperacion;//= malloc(sizeof(t_mensaje_resultado_etapa));

	//historial_de_un_nodo = malloc(sizeof(historial_nodo));
	char*buffer;
	int largo;
	bool transformaciones_termniadas;
	bool reduccionesLocales_terminadas;

	if(!recibir_mensaje_header(&headermaster,sock))return 0;

	switch(headermaster.codigoMensaje){
	case YAMA_CREAR_JOB:


			//recibo el NOMBRE del ARCHIVO de master
			buffer = malloc(headermaster.tamanio);
			//if(headermaster.tamanio>0){
			recvall(sock,buffer,headermaster.tamanio);



			//armo estructura y la pongo en la lista para que lo tome el otro hilo
			nuevo_job = malloc(sizeof(tratar_job));
			nuevo_job->master = idMaster;
			nuevo_job->sock_master = sock;
			nuevo_job->nodo = -1; //sirve para la replanificacion, ante la duda ver la parte de redu Global
			nuevo_job->nombre_archivo = string_substring(buffer,0,headermaster.tamanio);


			pthread_mutex_lock(&mutex_lista_jobs_nuevos);
			list_add(lista_jobs_nuevos,(void*)nuevo_job);
			pthread_mutex_unlock(&mutex_lista_jobs_nuevos);
			log_trace(yama_log,"Un Master Solicita Operar Sobre Archivo Llamado: %s",buffer);
			//sem_wait al semaforo que comunica entre hilos
			idMaster++;
			sem_post(&sem_job_nuevo);


			free(buffer);
//			free(nodoAMasterReduccionLocal);
//			free(nodoAMasterReduccionGlobal);
//			free(nodoAMasterAlmacenamientoFinal);
//			free(resultadoOperacion);

			free(nodoAMasterReduccionLocal);
			free(nodoAMasterReduccionGlobal);
			free(nodoAMasterAlmacenamientoFinal);




	break;

	case YAMA_TRANSFORMACION_OK:

		//actualizo el estado
		buffer = malloc(headermaster.tamanio);

		recvall(sock,buffer,headermaster.tamanio);


		//recibo el resultado de la operacion
		resultadoOperacion =  deserializarResultado(buffer);
		log_debug(yama_log,"la transformacion del NODO: %d hacia el bloque: %d, correspondiente al MASTER :%d"
									,resultadoOperacion->id_nodo,resultadoOperacion->bloque,resultadoOperacion->id_master);
		free(buffer);
		actualizarTablaDeEstados("MODIFICAR","TRANSFORMACION",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"FINALIZADO",NULL,NULL,resultadoOperacion->bloque,NULL,NULL,-1,NULL);
		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
		carga_de_nodo->cargaActual = carga_de_nodo->cargaActual - 1;
		carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;
		//me fijo si todos las transformaciones estan echas

				log_trace(yama_log,"-----------------------------------------------------------------------");
				imprimir_tabla_estados(tabla_de_estados);
				log_trace(yama_log,"-----------------------------------------------------------------------");
		 transformaciones_termniadas = se_terminaron_transformacion(resultadoOperacion->id_nodo,resultadoOperacion->id_master);
		if(transformaciones_termniadas != false){
			log_debug(yama_log,"Se terminaron todas las transformacion del NODO: %d Se envia la REDUCCION LOCAL al mismo, correspondiente al MASTER:%d"
					,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
		   //empiezo con la estapa de reduccion local
			headermaster.codigoMensaje = SOLICITUD_REDUCCION_LOCAL;//
			//le digo cual es el que e toca hacer la redu local
			//nodo_elegido = tomarElemento("REDUCCION LOCAL",resultadoOperacion->id_master,resultadoOperacion->id_nodo,NULL,"N");





							bool buscarElQueTieneElReduLocal(void* data){
								estado_de_un_job* j1 = (estado_de_un_job*) data;
								char** nodo =string_split(j1->nodo," ");
								if(strcmp(j1->etapa,"REDUCCION LOCAL") == 0 && j1->id_master ==resultadoOperacion->id_master && atoi(nodo[1]) == resultadoOperacion->id_nodo){
									free(nodo[1]);
									free(nodo[0]);
									free(nodo);
									return true;
								}else{
									free(nodo[1]);
									free(nodo[0]);
									free(nodo);
								    return	false;
								}


							}


							pthread_mutex_lock(&mutex_tabla_de_estados);
							estado_de_un_job* estado =  list_find(tabla_de_estados,buscarElQueTieneElReduLocal);
							free(estado->estado);
							estado->estado = string_new();
							string_append(&estado->estado,"EN PROCESO");
							//t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)etapa_selecionada);
							pthread_mutex_unlock(&mutex_tabla_de_estados);










			//actualizarTablaDeHistorialDeNodos(resultadoOperacion->id_master,resultadoOperacion->id_nodo,1,1);
			// actualizo mi tabla de estados
			//actualizarTablaDeEstados("MODIFICAR","REDUCCION LOCAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"EN PROCESO",NULL,NULL,NULL,NULL,NULL,NULL);

			//pasarDeEstructura(nodo_elegido,nodoAmaster);
			mandarArchivosAMasterTransformacion(nodoAMasterReduccionLocal,resultadoOperacion);
			buffer = serializarMsjReduccionLocal(nodoAMasterReduccionLocal,&largo);
			//headermaster.tamanio = sizeof(int32_t)*6 + nodoAmaster->archivo_resultado_largo + nodoAmaster->nodo_ip_largo + nodoAmaster->nodo_puerto_largo;
			headermaster.tamanio = largo;
			if(!enviar_mensaje_header(&headermaster,sock)){
			log_trace(yama_log,"Error al querer enviar la lista de NODOS para la REDUCCION LOCAL");
			}

			sendall(sock,buffer,largo);
			free(buffer);
			free(nodoAMasterReduccionLocal->destino_reduccion);
			free(nodoAMasterReduccionLocal->nodo_ip);
			free(nodoAMasterReduccionLocal->nodo_puerto);
			list_destroy_and_destroy_elements(nodoAMasterReduccionLocal->archivos_reduccion,(void*)eliminarArchivos);
			//free(nodo_elegido);

		}else{
		log_trace(yama_log,"NO SE TERMINARON LAS TRANSFORMACIONES del NODO: %d, correspondiente al MASTER:%d"
							,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
		}
//		log_trace(yama_log,"-----------------------------------------------------------------------");
//		imprimir_tabla_estados(tabla_de_estados);
//		log_trace(yama_log,"-----------------------------------------------------------------------");


//		free(nodoAMasterReduccionLocal);
//		free(nodoAMasterReduccionGlobal);
//		free(nodoAMasterAlmacenamientoFinal);
//		free(resultadoOperacion);
		free(nodoAMasterReduccionLocal);
		free(nodoAMasterReduccionGlobal);
		free(nodoAMasterAlmacenamientoFinal);



		free(resultadoOperacion);
		break;
	case YAMA_TRANSFORMACION_ERROR:


		//master me pasa el estado
		buffer = malloc(headermaster.tamanio);

		recvall(sock,buffer,headermaster.tamanio);


		//recibo el resultado de la operacion
		resultadoOperacion =  deserializarResultado(buffer);
		log_error(yama_log,"se produjo un error en la tranformacion del BLOQUE: %d en el NODO: %d, correspondiente al MASTER:%d"
								,resultadoOperacion->bloque,resultadoOperacion->id_nodo,resultadoOperacion->id_master);

		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
		carga_de_nodo->cargaActual = 0;

		//carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;


		//actualizo el estado a error

		//libero la redu local que no se va a poder hacer
//		nodo_elegido = tomarElemento("REDUCCION LOCAL",resultadoOperacion->id_master,resultadoOperacion->id_nodo,NULL,"N");
//		//free(nodo_elegido->estado);
//		if(nodo_elegido != NULL){
//		char*estado_new = string_new();
//		string_append(&estado_new,"ERROR");
//		nodo_elegido->estado = string_new();
//		string_append(&nodo_elegido->estado,estado_new);
//		free(estado_new);
//		}
		nodo_elegido = tomarElemento("JOB ABORTADO",resultadoOperacion->id_master,-1,-1,"N");


		actualizarTablaDeEstados("MODIFICAR","TRANSFORMACION",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"ERROR",NULL,NULL,resultadoOperacion->bloque,NULL,NULL,NULL,NULL);

		if(nodo_elegido== NULL){
		nuevo_job = malloc(sizeof(tratar_job));
		nuevo_job->master = resultadoOperacion->id_master;
		nuevo_job->sock_master = sock;
		nuevo_job->bloque = resultadoOperacion->bloque;
		nuevo_job->nodo =resultadoOperacion->id_nodo;

		nuevo_job->nombre_archivo = string_substring(resultadoOperacion->nombreArchivo,0,resultadoOperacion->nombreArchivoLargo);

		//carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo,lista_carga_de_nodos);
		pthread_mutex_lock(&mutex_lista_jobs_a_replanificar);
		list_add(lista_jobs_a_replanificar,(void*)nuevo_job);
		pthread_mutex_unlock(&mutex_lista_jobs_a_replanificar);
		sem_post(&sem_job_replanificar);
		}
		free(buffer);
//		log_trace(yama_log,"-----------------------------------------------------------------------");
//		imprimir_tabla_estados(tabla_de_estados);
//		log_trace(yama_log,"-----------------------------------------------------------------------");
//		free(nodoAMasterReduccionLocal);
//		free(nodoAMasterReduccionGlobal);
//		free(nodoAMasterAlmacenamientoFinal);
//		free(resultadoOperacion);
		free(resultadoOperacion->nombreArchivo);
		free(nodoAMasterReduccionLocal);
		free(nodoAMasterReduccionGlobal);
		free(nodoAMasterAlmacenamientoFinal);




		free(resultadoOperacion);
	break;
   case YAMA_REDUCCION_LOCAL_OK:
	   //recibo el nodo que termino bien la redu local
	   buffer = malloc(headermaster.tamanio);

	  recvall(sock,buffer,headermaster.tamanio);


	  resultadoOperacion =  deserializarResultado(buffer);
	  //actualizo mi tabla de estados
	  log_debug(yama_log,"se recibe reduccion local ok de master:%d, del nodo:%d",resultadoOperacion->id_master,resultadoOperacion->id_nodo);
	  actualizarTablaDeEstados("MODIFICAR","REDUCCION LOCAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"FINALIZADO",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	  //me fijo si todos los nodos ya tiene la redu local para empezar con la redu global
	  carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	  carga_de_nodo->cargaActual = carga_de_nodo->cargaActual- 1;
	  carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;

      reduccionesLocales_terminadas = se_terminaron_reducciones_locales(resultadoOperacion->id_master);
      if(reduccionesLocales_terminadas == true){


//    	  nodo_elegido = tomarElemento("REDUCCION GLOBAL",resultadoOperacion->id_master,NULL,NULL,"N");




			bool buscarElQueTieneElReduGLOBAL(void* data){
				estado_de_un_job* j1 = (estado_de_un_job*) data;
				char** nodo =string_split(j1->nodo," ");
				if(strcmp(j1->etapa,"REDUCCION GLOBAL") == 0 && j1->id_master ==resultadoOperacion->id_master && strcmp(j1->estado,"ABORTIVO") != 0){
					free(nodo[1]);
					free(nodo[0]);
					free(nodo);
					return true;
				}else{
					free(nodo[1]);
					free(nodo[0]);
					free(nodo);
				    return	false;
				}


			}


			pthread_mutex_lock(&mutex_tabla_de_estados);
			estado_de_un_job* estado =  list_find(tabla_de_estados,buscarElQueTieneElReduGLOBAL);
			free(estado->estado);
			estado->estado = string_new();
			string_append(&estado->estado,"EN PROCESO");
			//t_list* listaConSoloUnaEtapa = list_filter(tabla_de_estados,(void*)etapa_selecionada);
			pthread_mutex_unlock(&mutex_tabla_de_estados);


			char**nodo1 = string_split(estado->nodo, " ");

 //   	  actualizarTablaDeEstados("MODIFICAR","REDUCCION GLOBAL",resultadoOperacion->id_master,sock,atoi(nodo1[1]),"EN PROCESO",NULL,NULL,NULL,NULL,NULL,NULL);



    	  log_debug(yama_log,"Se terminaron todas las REDUCCIONES LOCAL del MASTER: %d Comienza la REDUCCION GLOBAL en NODO:%d"
    	      	  					,resultadoOperacion->id_master,atoi(nodo1[1]));



    	  headermaster.codigoMensaje = SOLICITUD_REDUCCION_GLOBAL;
    	  //este parche lo puse para que tome el nodo que es el encargado de la reduccion global
    	  resultadoOperacion->id_nodo = atoi(nodo1[1]);

    	  mandarArchivosAMasterReduccion(nodoAMasterReduccionGlobal,resultadoOperacion);


    	  //pasarDeEstructura(nodo_elegido,nodoAmaster);
    	  buffer = serializarMsjReduccionGlobal(nodoAMasterReduccionGlobal,&largo);
    	  headermaster.tamanio = largo;
    	  if(!enviar_mensaje_header(&headermaster,sock)){
    	  log_trace(yama_log,"Error al querer enviar el NODO: %d para la REDUCCION GLOBAL",nodo_elegido->nodo);
    	  }

    	  sendall(sock,buffer,largo);
    	  free(nodoAMasterReduccionGlobal->destino_reduccion);
    	  free(nodoAMasterReduccionGlobal->nodo_ip);
    	  free(nodoAMasterReduccionGlobal->nodo_puerto);
    	  free(nodo1[0]);
    	  free(nodo1[1]);
    	  free(nodo1);
    	  list_destroy_and_destroy_elements(nodoAMasterReduccionGlobal->archivos_reduccion,eliminarArchivos);


      }else{
    	  log_debug(yama_log,"no se terminaron las REDUCCIONES LOCALES, correspondiente al MASTER:%d"
    	      							,resultadoOperacion->id_master);
      }


      free(buffer);
      //free(nodo_elegido);
//      log_trace(yama_log,"-----------------------------------------------------------------------");
//      imprimir_tabla_estados(tabla_de_estados);
//      log_trace(yama_log,"-----------------------------------------------------------------------");
//  	free(nodoAMasterReduccionLocal);
//  	free(nodoAMasterReduccionGlobal);
//  	free(nodoAMasterAlmacenamientoFinal);
//  	free(resultadoOperacion);
  	free(nodoAMasterReduccionLocal);
  	free(nodoAMasterReduccionGlobal);
  	free(nodoAMasterAlmacenamientoFinal);


  	free(resultadoOperacion);

	break;
   case YAMA_REDUCCION_LOCAL_ERROR:
	   //recibo el nodo por el cual hubo un error en la redu local
	   buffer = malloc(headermaster.tamanio);

	   		recvall(sock,buffer,headermaster.tamanio);


	   		resultadoOperacion =  deserializarResultado(buffer);
	   		log_error(yama_log,"se produjo un error en la REDUCCION LOCAL en el NODO: %d correspondiente al master:%d"
	   			   						,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	   		carga_de_nodo->cargaActual = 0;
	   		//carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;

	   		//actualizo tabla de estados
	   		actualizarTablaDeEstados("MODIFICAR","REDUCCION LOCAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"ERROR",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	   		// le digo al proceso master que aborte
	   		headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
	   		if(!enviar_mensaje_header(&headermaster,sock)){
	   			log_trace(yama_log,"Error al querer enviar REDUCCION LOCAL en nodo:%d correspondiente al master:%d",resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		}



	   		free(buffer);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
//	   		imprimir_tabla_estados(tabla_de_estados);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
//	   		free(nodoAMasterReduccionLocal);
//	   		free(nodoAMasterReduccionGlobal);
//	   		free(nodoAMasterAlmacenamientoFinal);
//	   		free(resultadoOperacion);

	   		free(nodoAMasterReduccionLocal);
	   		free(nodoAMasterReduccionGlobal);
	   		free(nodoAMasterAlmacenamientoFinal);


	   		free(resultadoOperacion);
	break;

   case YAMA_REDUCCION_GLOBAL_OK:
	   //recibo el nodo por el cual la redu global se hizo bien
	   buffer = malloc(headermaster.tamanio);

	   recvall(sock,buffer,headermaster.tamanio);


	   resultadoOperacion =  deserializarResultado(buffer);
	   log_debug(yama_log," la REDUCCION GLOBAL en el NODO: %d correspondiente al master:%d se hizo satisfactoriamente"
	   	   			   						,resultadoOperacion->id_nodo,resultadoOperacion->id_master);

	   //actualizo tabla de estados
	   actualizarTablaDeEstados("MODIFICAR","REDUCCION GLOBAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"FINALIZADO",NULL,NULL,-1,NULL,NULL,NULL,NULL);
	   carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	   carga_de_nodo->cargaActual =carga_de_nodo->cargaActual - 1;
	   carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;
	  // nodo_elegido = tomarElemento("ALMACENAMIENTO FINAL",resultadoOperacion->id_master,NULL,NULL,"N");
	   actualizarTablaDeEstados("MODIFICAR","ALMACENAMIENTO FINAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"EN PROCESO",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	   mandarAlmacenamientoFinal(nodoAMasterAlmacenamientoFinal,resultadoOperacion);

	   buffer = serializeMsjAlmacenamientoFinal(nodoAMasterAlmacenamientoFinal,&largo);
	   //envio almacenamiento final
	   headermaster.codigoMensaje = YAMA_ALMACENAMIENTO_FINAL;
	   headermaster.tamanio = largo;

	   if(!enviar_mensaje_header(&headermaster,sock)){
	   	log_trace(yama_log,"Error al querer enviar REDUCCION GLOBAL a master:%d con nodo:%d",resultadoOperacion->id_master,resultadoOperacion->id_nodo);
	   }
	   // asigno el nodo que va a realizar el almacenamiento final



		sendall(sock,buffer,largo);
		free(buffer);

//		free(nodoAMasterReduccionLocal);
//		free(nodoAMasterReduccionGlobal);
//		free(nodoAMasterAlmacenamientoFinal);
//		free(resultadoOperacion);
		free(nodoAMasterAlmacenamientoFinal->archivo_final);
		free(nodoAMasterAlmacenamientoFinal->nodo_ip);
		free(nodoAMasterAlmacenamientoFinal->nodo_puerto);
	   log_debug(yama_log,"ENVIO DE ALMACENAMIENTO FINAL AL NODO: %d del MASTER: %d",resultadoOperacion->id_nodo,resultadoOperacion->id_master);

//	   log_trace(yama_log,"-----------------------------------------------------------------------");
//	   imprimir_tabla_estados(tabla_de_estados);
//	   log_trace(yama_log,"-----------------------------------------------------------------------");
		free(nodoAMasterReduccionLocal);
		free(nodoAMasterReduccionGlobal);
		free(nodoAMasterAlmacenamientoFinal);


		free(resultadoOperacion);
	   break;



   case YAMA_REDUCCION_GLOBAL_ERROR:
	   //recibo el nodo por el cual hubo un error en la redu global
	   buffer = malloc(headermaster.tamanio);

	   		recvall(sock,buffer,headermaster.tamanio);


	   		resultadoOperacion =  deserializarResultado(buffer);
	   		log_debug(yama_log," ERROR En el reduccion global en el NODO: %d correspondiente al master:%d se hizo satisfactoriamente"
	   			   			   	   			   						,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
//	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo,lista_carga_de_nodos);
//	   		carga_de_nodo->cargaActual = carga_de_nodo->cargaActual- 1;
//	   		carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;
	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	   		carga_de_nodo->cargaActual = 0;
	   		//carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;

	   		//actualizo tabla de estados
	   		actualizarTablaDeEstados("MODIFICAR","REDUCCION GLOBAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"ERROR",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	   		// le digo al proceso master que aborte
	   		headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
	   		if(!enviar_mensaje_header(&headermaster,sock)){
	   			log_trace(yama_log,"Error al querer enviar REDUCCION GLOBAL al master:%d",resultadoOperacion->id_master);
	   		}
	   		log_error(yama_log,"Error en la REDUCCION GLOBAL en el nodo: %d en el MASTER:%d",resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		free(buffer);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
//	   		imprimir_tabla_estados(tabla_de_estados);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
//	   		free(nodoAMasterReduccionLocal);
//	   		free(nodoAMasterReduccionGlobal);
//	   		free(nodoAMasterAlmacenamientoFinal);
//	   		free(resultadoOperacion);
	   		free(nodoAMasterReduccionLocal);
	   		free(nodoAMasterReduccionGlobal);
	   		free(nodoAMasterAlmacenamientoFinal);


			free(resultadoOperacion);

   	   break;
   case YAMA_ALMACENAMIENTO_FINAL_OK:
	   //recibo el nodo por el cual hubo un error en la redu global
	   buffer = malloc(headermaster.tamanio);

	   		recvall(sock,buffer,headermaster.tamanio);


	   		resultadoOperacion =  deserializarResultado(buffer);
	   		log_debug(yama_log," el ALMACENAMIENTO FINAL en el NODO: %d correspondiente al master:%d se hizo satisfactoriamente"
	   			   	   			   						,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	   		carga_de_nodo->cargaActual = carga_de_nodo->cargaActual- 1;
	   		carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;
	   		//actualizo tabla de estados
	   		actualizarTablaDeEstados("MODIFICAR","ALMACENAMIENTO FINAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"OK",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	   		// le digo al proceso master que aborte
	   		headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
	   		if(!enviar_mensaje_header(&headermaster,sock)){
	   			log_error(yama_log,"Error al queres enviar ALMACENAMIENTO FINAL a master:%d",resultadoOperacion->id_master);
	   		}
	   		log_debug(yama_log,"Se realizo exitosamente el almacenamiento final en el MASTER:%d",resultadoOperacion->id_master);
	   		free(buffer);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
//	   		imprimir_tabla_estados(tabla_de_estados);
//	   		log_trace(yama_log,"-----------------------------------------------------------------------");
	   		free(nodoAMasterReduccionLocal);
	   		free(nodoAMasterReduccionGlobal);
	   		free(nodoAMasterAlmacenamientoFinal);


			free(resultadoOperacion);

	   break;
   case YAMA_ALMACENAMIENTO_FINAL_ERROR:
	   //recibo el nodo por el cual hubo un error en la redu global
	   buffer = malloc(headermaster.tamanio);

	   		recvall(sock,buffer,headermaster.tamanio);


	   		resultadoOperacion =  deserializarResultado(buffer);
//	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo,lista_carga_de_nodos);
//	   		carga_de_nodo->cargaActual = carga_de_nodo->cargaActual- 1;
//	   		carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;
	   		log_debug(yama_log," ERROR En el almacenamiento final en el NODO: %d correspondiente al master:%d se hizo satisfactoriamente"
	   			   	   			   						,resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		carga_de_nodo = buscarNodoEnListaCargaNodos(resultadoOperacion->id_nodo);
	   		carga_de_nodo->cargaActual = 0;
	   		//carga_de_nodo->cargaHistorica = carga_de_nodo->cargaHistorica+ 1;

	   		//actualizo tabla de estados
	   		actualizarTablaDeEstados("MODIFICAR","ALMACENAMIENTO FINAL",resultadoOperacion->id_master,sock,resultadoOperacion->id_nodo,"ERROR",NULL,NULL,-1,NULL,NULL,NULL,NULL);

	   		// le digo al proceso master que aborte
	   		headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
	   		if(!enviar_mensaje_header(&headermaster,sock)){
	   			log_trace(yama_log,"Error al querer enviar ALMACENAMIENTO FINAL a master:%d",resultadoOperacion->id_master);
	   		}
	   		log_error(yama_log,"Error en la ALMACENAMIENTO en el nodo: %d en el MASTER:%d",resultadoOperacion->id_nodo,resultadoOperacion->id_master);
	   		free(buffer);

	   		log_trace(yama_log,"-----------------------------------------------------------------------");
	   		imprimir_tabla_estados(tabla_de_estados);
	   		log_trace(yama_log,"-----------------------------------------------------------------------");
	   		free(nodoAMasterReduccionLocal);
	   		free(nodoAMasterReduccionGlobal);
	   		free(nodoAMasterAlmacenamientoFinal);


			free(resultadoOperacion);

   	   break;

	}

	return 1;


}







void crearEstructurasGlobales(){
	//lista para los master sockets aceptados
	yama_masters_aceptados= list_create();
	//lista de tabla de estados
	tabla_de_estados = list_create();
	//tabla de historial de nodos
	tabla_historial_nodos = list_create();
	//tabla con la carga de los nodos
	lista_carga_de_nodos = list_create();
	//lista de jobs nuevos
	lista_jobs_nuevos = list_create();
	//lista de jobs a replanificar
	lista_jobs_a_replanificar = list_create();
	//lista para replanificar
	bloques_x_archivo = list_create();
	//lista que me envia llama
	lista_de_nodos_con_bloques = list_create();
	//lista transfoamciones enviadas
	lista_transformacion_enviadas = list_create();
	//inicializo el semaforo
	sem_init(&sem_job_nuevo, 1, 0);
	sem_init(&sem_job_replanificar, 1, 0);
	idMaster = 1;
	new_reducciones_locales = list_create();


	//condicion_de_corte= true;
	pthread_mutex_init(&mutex_bloques_x_archivo, NULL);
	pthread_mutex_init(&mutex_lista_carga_de_nodos, NULL);
	pthread_mutex_init(&mutex_lista_jobs_a_replanificar, NULL);
	pthread_mutex_init(&mutex_lista_jobs_nuevos, NULL);
	pthread_mutex_init(&mutex_tabla_de_estados, NULL);
	pthread_mutex_init(&mutex_tabla_historial_nodos, NULL);
	pthread_mutex_init(&mutex_yama_cfg, NULL);
}

void actualizarTablaDeEstados(char* TipoOperacion,char* etapa, int id_master,int master, int nodo, char* nuevoEstado
		,char*ip,int puerto, int bloque,int bytesOcupados,char* ArchivoTemporal,int es_encargado,int bloqueFic){


	estado_de_un_job* estado1;


	if(string_contains(TipoOperacion,"AGREGAR JOB")){
		estado_de_un_job* estado= malloc(sizeof(estado_de_un_job));


		estado->master = master;
		estado->id_master = id_master;
		estado->bloqueFicticio = bloqueFic;
//
//		estado->esta_activo = string_new();
//		string_append(&estado->esta_activo, es_activo);

		char * nodoActual = string_new();
		string_append(&nodoActual, "NODO ");
		char* n = string_itoa(nodo);
		string_append(&nodoActual, n);

		estado->nodo = string_new();
		string_append(&estado->nodo, nodoActual);


		estado->etapa = string_new();
		string_append(&estado->etapa, etapa);
		estado->estado = string_new();
		string_append(&estado->estado,nuevoEstado);

		if(ip != NULL){
		estado->ip = string_new();
		string_append(&estado->ip,ip);

		}
		estado->puerto = puerto;

		estado->bloque = bloque;

		estado->bytesOcupados = bytesOcupados;

		if(ArchivoTemporal!= NULL){
		estado->archivoTemporal = string_new();
		string_append(&estado->archivoTemporal,ArchivoTemporal);
		}
		estado->encargado = es_encargado;


		pthread_mutex_lock(&mutex_tabla_de_estados);
		//imprimir_tabla_estados(tabla_de_estados);
		list_add(tabla_de_estados,estado);
		pthread_mutex_unlock(&mutex_tabla_de_estados);
		free(n);
		free(nodoActual);

		//imprimir_tabla_estados(tabla_de_estados);

	}else if(string_contains(TipoOperacion,"MODIFICAR")){

		if(strcmp(nuevoEstado,"EN PROCESO")== 0){
			if(bloque!=-1){
				estado1 =  tomarElemento(etapa,id_master,nodo,bloque,"N");
			}else{
				estado1 =  tomarElemento(etapa,id_master,nodo,-1,"N");
			}
			free(estado1->estado);
			estado1->estado = string_new();
			string_append(&estado1->estado,nuevoEstado);

			if(es_encargado != NULL){

				estado1->encargado = es_encargado;
			}
		}else if(strcmp(nuevoEstado,"FINALIZADO") == 0){
			if(bloque!=-1){
				estado1 =  tomarElemento(etapa,id_master,nodo,bloque,"EN PROCESO");
			}else{
				estado1 =  tomarElemento(etapa,id_master,nodo,-1,"EN PROCESO");
			}
			free(estado1->estado);
			estado1->estado = string_new();
			string_append(&estado1->estado,nuevoEstado);

			if(es_encargado != NULL){

				estado1->encargado = es_encargado;
			}

		}else if(strcmp(nuevoEstado,"ERROR") == 0){
			if(bloque!=-1){
				estado1 =  tomarElemento(etapa,id_master,nodo,bloque,"EN PROCESO");
			}else{
				estado1 =  tomarElemento(etapa,id_master,nodo,-1,"EN PROCESO");
			}
			free(estado1->estado);
			estado1->estado = string_new();
			string_append(&estado1->estado,nuevoEstado);

			if(es_encargado != NULL){

				estado1->encargado = es_encargado;
			}
		}else if(strcmp(nuevoEstado,"N") == 0){
			if(bloque!=-1){
				estado1 =  tomarElemento(etapa,id_master,nodo,bloque,"FINALIZADO");
			}else{
				estado1 =  tomarElemento(etapa,id_master,nodo,-1,"FINALIZADO");
			}
			free(estado1->estado);
			estado1->estado = string_new();
			string_append(&estado1->estado,nuevoEstado);

			if(es_encargado != NULL){

				estado1->encargado = es_encargado;
			}

		}





	}

//	free(estado);


}

void imprimir_tabla_estados(tabla_de_estados){
		void imprimir(estado_de_un_job* estado_new){

	log_trace(yama_log,"se agrego id_master:%d con :%s con estado:%s, el Bloque real es:%d y el bloque ficticio es:%d y etapa:%s y el nombre del archivo es:%s",estado_new->id_master,estado_new->nodo,
			estado_new->estado,estado_new->bloque,estado_new->bloqueFicticio, estado_new->etapa,estado_new->archivoTemporal);


		}

		list_iterate(tabla_de_estados,imprimir);

	}

int recibir_mensajesDeMaster(int socket){




	if(buscar_en_master_aceptados(socket)){
		log_trace(yama_log,"Se responde Pedido de Master ya autenticado");

		if(!recibir_operacionMaster(socket)){
			bool borrarAMaster(void*data){
				master_aceptado* master = (master_aceptado*) data;
				return master->sock_fd == socket;

			}

			list_remove_and_destroy_by_condition(yama_masters_aceptados,borrarAMaster,(void*)free);

		return 0;
		}

	}else{

		//master nuevo
			handshake_t codigomaster = HANDSHAKE_MASTER;

			log_trace(yama_log,"Un master nuevo envio un mensaje, se realiza handshake");

			if(!validar_handshake(codigomaster,socket)){

				log_error(yama_log,"recibir_mensajesMaster-> error en funcion validar_handshake");

				if(!socket_close(socket)){

					log_error(yama_log,"Error al cerrar el socket");

				}
				return 0;
			}
			aceptar_master(socket);
			return 1;
		}
		return 1;

	}






void dummy_func_escribir(int sock_fd){
	return;
}

int crearServerMultiplexor(){

 int socket_server	= socket_multiplexing( "127.0.0.1", "5000" , 20, &conexion_nuevo_ProcesoMaster, &recibir_mensajesDeMaster, &dummy_func_escribir,yama_log);
 return socket_server;
}
void conexion_nuevo_ProcesoMaster(){
log_trace(yama_log, "conexion_nueva_consola->Se ha conectado un nuevo proceso en el puerto para consolas");

}

//int crear_conexion_con_fs(){
//	int socket_fs;
//	socket_fs = socket_create(yama_cfg->ip_fs, yama_cfg->puerto_fs, (char)TIPO_CLIENTE, 0, yama_log);
//}

int conectarseAProcesoFyleSystem(){
	char* puerto_fs = string_itoa( yama_cfg->puerto_fs);
	socket_FS = socket_create(yama_cfg->ip_fs,puerto_fs, (char)TIPO_CLIENTE, 0, yama_log);
	free(puerto_fs);
	return socket_FS;
}
