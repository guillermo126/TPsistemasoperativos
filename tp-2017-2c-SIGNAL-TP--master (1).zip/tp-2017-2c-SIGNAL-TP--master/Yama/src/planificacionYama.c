/*
 * planificacionYama.c
 *
 *  Created on: 3/10/2017
 *      Author: utnso
 */


#include "planificacionYama.h"

//
bool yaExisteNodoEnSistema(t_list* tabla_carga_nod,int nodo){
bool resultado;

	bool encontrar_nodo(void* data){
		carga_nodo * carga_de_nodo = (carga_nodo *) data;
		return carga_de_nodo->nodo == nodo;// && carga_de_nodo->esta_activo == 1;

	}
	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	resultado = list_any_satisfy(tabla_carga_nod,encontrar_nodo);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
	return resultado;

}


carga_nodo * obtenerNodoConMayorCargar(t_list* tabla_carga_nod){

	carga_nodo* nodoConMayorCarga;

	bool bloque_menor_a_mayor(carga_nodo *n1, carga_nodo *n2) {
	return n1->cargaActual >= n2->cargaActual;
	}
	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	list_sort(tabla_carga_nod, (void*)bloque_menor_a_mayor);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	nodoConMayorCarga=(carga_nodo*)list_get(tabla_carga_nod,0);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);


	return nodoConMayorCarga;

}

void obtenerDisponibilidadworkerWClock(t_list* lista_de_nodos_c_bloques,t_list* Thistorial_nodos,t_list* tabla_carga_nod,t_list* lista_j_nuevos,tratar_job* job_creado){
	bloques_en_archivo* nodo_con_bloques;
	carga_nodo * carga_de_nodo;
	carga_nodo * nodo_de_mayor_carga;
	carga_nodo * carga_de_nodo_actual;
	//tratar_job* job_creado;
	historial_nodo* nodo_creado;

	int tamanio = list_size(lista_de_nodos_c_bloques);
	int index = 0;

	//obtenemos el job nuevo del otro hilo, siempre nos fijamos en el ultimo de la lista
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	int tamanio_Lista_jobs_nuevos = list_size(lista_jobs_nuevos);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);
//
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	job_creado = (tratar_job*) list_get(lista_j_nuevos,tamanio_Lista_jobs_nuevos-1);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

	//obtener la mayor carga de entre todos los nodos
	if(list_size(tabla_carga_nod)>0){

	nodo_de_mayor_carga =obtenerNodoConMayorCargar(tabla_carga_nod);
 }



	while(tamanio>0){
	nodo_creado = malloc(sizeof(historial_nodo));
	carga_de_nodo = malloc(sizeof(carga_nodo));
	nodo_con_bloques = (bloques_en_archivo*)list_get(lista_de_nodos_c_bloques,index);


	//agrego en la tabla historia
	nodo_creado->nodo = nodo_con_bloques->nodo;
	nodo_creado->ip= string_new();
	string_append(&nodo_creado->ip,nodo_con_bloques->ip);
	nodo_creado->puerto = nodo_con_bloques->puerto;

	//obtenemos el nodo a analizar y vemos su carga actual
	if(yaExisteNodoEnSistema(tabla_carga_nod,nodo_con_bloques->nodo)){
	bool obtenerNodo(void*data){
	carga_nodo * nodo = (carga_nodo *) data;
	return nodo->nodo ==  nodo_con_bloques->nodo;

	}
	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	carga_de_nodo_actual = (carga_nodo * )list_find(tabla_carga_nod,obtenerNodo);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
	//realizamos la cuenta necesario para la disponibilidad en wclock
	pthread_mutex_lock(&mutex_yama_cfg);
	nodo_creado->disponibilidad = yama_cfg->disponibilidad -(nodo_de_mayor_carga->cargaActual - carga_de_nodo_actual->cargaActual);
	pthread_mutex_unlock(&mutex_yama_cfg);
	}else{
		pthread_mutex_lock(&mutex_yama_cfg);
		nodo_creado->disponibilidad = yama_cfg->disponibilidad ;//por archivo de configuracion
		pthread_mutex_unlock(&mutex_yama_cfg);
	}
	//carga_de_nodo = (carga_nodo * )list_find(tabla_carga_nod,obtenerNodo);


    nodo_creado->master = job_creado->master;

	nodo_creado->sock_master = job_creado->sock_master; // viene del otro hilo variable global
	nodo_creado->enviar_a_master = 1;
	nodo_creado->punteroClock = 0;
	nodo_creado->encargado = 0;
	nodo_creado->bloques= list_create();
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	list_add(Thistorial_nodos,(void*)nodo_creado);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
		//agregamos a la lista de carga de nodos
		if(!yaExisteNodoEnSistema(tabla_carga_nod,nodo_con_bloques->nodo)){
			carga_de_nodo->nodo = nodo_con_bloques->nodo;
			carga_de_nodo->cargaActual = 1; // siempre le cargo 1 al principio que seria la redu local
			carga_de_nodo->cargaHistorica = 0;
			carga_de_nodo->esta_activo = 1;
			pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			list_add(tabla_carga_nod,(void*)carga_de_nodo);
			pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
		}else{
			bool obtenerNodo(void*data){
				carga_nodo * nodo = (carga_nodo *) data;
				return nodo->nodo ==  nodo_con_bloques->nodo;

			}
			 pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			 carga_de_nodo = (carga_nodo * )list_find(tabla_carga_nod,obtenerNodo);
			 pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
			 carga_de_nodo->cargaActual++;
			 carga_de_nodo->esta_activo = 1;
		}

	//	idMaster++;




			index ++;
			tamanio --;
		}



}
// recibo la lista que me daria fs por pedirle transformar un archivo
void obtenerDisponibilidadworkerClock(t_list* lista_de_nodos_c_bloques,t_list* Thistorial_nodos,t_list* tabla_carga_nod,t_list* lista_j_nuevos,tratar_job* job_creado){
	bloques_en_archivo* nodo_con_bloques;
	carga_nodo * carga_de_nodo;

	historial_nodo* nodo_creado;


	int tamanio = list_size(lista_de_nodos_c_bloques);
	int index = 0;

	//obtenemos el job nuevo del otro hilo, siempre nos fijamos en el ultimo de la lista
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	int tamanio_Lista_jobs_nuevos = list_size(lista_jobs_nuevos);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	job_creado = (tratar_job*) list_get(lista_j_nuevos,tamanio_Lista_jobs_nuevos-1);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

	//tambien pongo en mi lista de bloques por achivos los nodos con los bloques que tenga
	while(tamanio>0){
		nodo_creado = malloc(sizeof(historial_nodo));
		carga_de_nodo = malloc(sizeof(carga_nodo));
	nodo_con_bloques = (bloques_en_archivo*)list_get(lista_de_nodos_c_bloques,index);


	//agrego en la tabla historia
	nodo_creado->nodo = nodo_con_bloques->nodo;
	nodo_creado->ip= string_new();
	string_append(&nodo_creado->ip,nodo_con_bloques->ip);
	nodo_creado->puerto = nodo_con_bloques->puerto;
	pthread_mutex_lock(&mutex_yama_cfg);
	nodo_creado->disponibilidad = yama_cfg->disponibilidad;//por archivo de configuracion
	pthread_mutex_unlock(&mutex_yama_cfg);
	nodo_creado->master = job_creado->master;
	nodo_creado->sock_master = job_creado->sock_master; // viene del otro hilo variable global
	nodo_creado->enviar_a_master = 1;
	nodo_creado->punteroClock = 0;
	nodo_creado->encargado = 0;
	nodo_creado->bloques= list_create();
	//list_add_all(nodo_creado->bloques,nodo_con_bloques->bloques);
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	list_add(Thistorial_nodos,(void*)nodo_creado);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	//agregamos a la lista de carga de nodos
	if(!yaExisteNodoEnSistema(tabla_carga_nod,nodo_con_bloques->nodo)){
		carga_de_nodo->nodo = nodo_con_bloques->nodo;
		carga_de_nodo->cargaActual = 1; // siempre le cargo 1 al principio que seria la redu local
		carga_de_nodo->cargaHistorica = 0;
		carga_de_nodo->esta_activo = 1;
		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
		list_add(tabla_carga_nod,(void*)carga_de_nodo);
		pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

	}else{
		bool obtenerNodo(void*data){
			carga_nodo * nodo = (carga_nodo *) data;
			return nodo->nodo ==  nodo_con_bloques->nodo;

		}
		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
		 carga_de_nodo = (carga_nodo * )list_find(tabla_carga_nod,obtenerNodo);
		 pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
		 carga_de_nodo->cargaActual++;
		 carga_de_nodo->esta_activo = 1;
	}

	//idMaster++;




		index ++;
		tamanio --;
	}
//	posicionarPuntero(Thistorial_nodos);
//	ejecutarAlgoritmo(lista_de_nodos_con_bloques,Thistorial_nodos);
	log_trace(yama_log," se obtiene la disponibilidad de los nodos");

}

bool todosLosNodosConDispoEnCero(t_list* LHistorialNodos){
	bool resultado;


	bool todasDispoEnCero(void*data){
		historial_nodo* nodo =(historial_nodo*) data;
		return nodo->disponibilidad == 0;
	}
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	resultado = list_all_satisfy(LHistorialNodos,(void*)todasDispoEnCero);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	return resultado;

}
void asignarAtodosDispo( t_list* LHistorialNodos){
	int index_LHistorialNodos = 0;
	historial_nodo* nodo;
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	while(index_LHistorialNodos < list_size(LHistorialNodos)){
	nodo = (historial_nodo*)list_get(LHistorialNodos,index_LHistorialNodos);
	pthread_mutex_lock(&mutex_yama_cfg);
	nodo->disponibilidad = yama_cfg->disponibilidad; //debo asigno lo que tiene el archivo de configuracion
	pthread_mutex_unlock(&mutex_yama_cfg);
	index_LHistorialNodos ++;

	}
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);

}

carga_nodo*  buscarNodoEnListaCargaNodos(int numero_nodo){

	carga_nodo* carga_de_un_nodo;

	bool encontrar_nodo(void*data){

		carga_nodo* un_nodo = (carga_nodo*) data;

		return un_nodo->nodo == numero_nodo;

	}

	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	carga_de_un_nodo = (carga_nodo*) list_find(lista_carga_de_nodos,encontrar_nodo);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);


	return carga_de_un_nodo;
}

void ejecutarAlgoritmo(t_list *listaNodosBloques,t_list* l_Historial_Nodos,t_list* tabla_carga_nod,tratar_job* job_creado) {
	int index_tabla_historial = 0;
	int index_tabla_sin_repetidos = 0;
	historial_nodo* nodo_elegido;
	carga_nodo * carga_de_nodo;
	t_list* lista_sin_repetidos;
	t_list*listaHistorialNodos;// = list_create();
	bool condicion_de_corte ; // condicion de corte para el caso en el que usemos los nodos sin puntero clock
	bool incrementar_indice = true;
	bloque* bloque_num;

	//pongo esto por solo el algoritmo debe ejecuatar correspondiente al job que se crea por pedido de master

	bool filtrarPorMaster(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->master == job_creado->master;// && nodo->enviar_a_master == 1;

	}

	//primer busco todos los nodo del master a filtrar y me fijo que el enviar a master este en 1 en la T.historial
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	listaHistorialNodos= list_filter(l_Historial_Nodos,filtrarPorMaster);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);



	lista_sin_repetidos = obtenerListaDeBloquesOrdenadosSinRepetir(listaNodosBloques);
	//buscamos primer nodo con disponibilidad >0 y que tenga el proximo bloque asignado
	while(index_tabla_sin_repetidos < list_size(lista_sin_repetidos)){
		//primero me fijo si todos tiene la disponibilidad en cero
		// de ser asi le sumo el valor que tiene en la config
		if(todosLosNodosConDispoEnCero(listaHistorialNodos)){
			//asigno a todos la dispo del archivo config
			asignarAtodosDispo(listaHistorialNodos);
		}

		condicion_de_corte = true;
		//tomamos el primer bloque a analizar
		bloque_num =(bloque*) list_get(lista_sin_repetidos,index_tabla_sin_repetidos);
		log_trace(yama_log,"se analiza el Bloque numero:%d",bloque_num->num_bloque_ficticio);
		// tomamos el primero que tenga el puntero, tomo el indice de la lista de historial
		index_tabla_historial = obtenerElqueTengaPuntero(listaHistorialNodos);
		// tomamos el primero que tenga el puntero, TOMO EL NODO de la lista historial
		nodo_elegido = nodoConPuntero(listaHistorialNodos);
		log_trace(yama_log,"el puntero esta en el Nodo numero:%d y su disponibilidad es de:%d"
				,nodo_elegido->nodo,nodo_elegido->disponibilidad);
		// nos fijamos si cumple con las condiciones de disponibiliada  y si tiene el bloque asignado
		if(nodo_elegido->disponibilidad >0 && el_nodo_tiene_el_bloque(nodo_elegido,listaNodosBloques,bloque_num)){
			nodo_elegido->disponibilidad--;
			nodo_elegido->punteroClock = 0;
			//agrego el bloque a la lista del nodo y actualizo la carga en la lista de cargas de nodos
			carga_de_nodo = buscarNodoEnListaCargaNodos(nodo_elegido->nodo);
			carga_de_nodo->cargaActual ++;
			nodo_elegido->bytesOcupados = bloque_num->bytes_ocupados;
			list_add(nodo_elegido->bloques,(void*)bloque_num);
			log_trace(yama_log,"el Bloque:%d es asignado al Nodo:%d",bloque_num->num_bloque_ficticio
					,nodo_elegido->nodo);
			pthread_mutex_lock(&mutex_yama_cfg);
						usleep(yama_cfg->retardo* 10000); //la que tenga en el archivo de configuracion
						pthread_mutex_unlock(&mutex_yama_cfg);
			//primero sumo el indice y me fijo si supera el tamaño de la lista
			index_tabla_historial++;
			pthread_mutex_lock(&mutex_tabla_historial_nodos);
			if(index_tabla_historial==list_size(listaHistorialNodos)){
				index_tabla_historial = 0;
			}
			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
			// tomo el nodo siguiente y le pongo el clock al mismo
			pthread_mutex_lock(&mutex_tabla_historial_nodos);
			nodo_elegido = (historial_nodo* )list_get(listaHistorialNodos,index_tabla_historial);
			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
			nodo_elegido->punteroClock = 1;

			//index_tabla_sin_repetidos++;

		}else{
			//me fijo si es que no tiene disponibilidad o si es porque no tiene el bloque asignado
		if(nodo_elegido->disponibilidad  <= 0){
			log_trace(yama_log,"el Nodo:%d tiene disponibilidad igual a 0"
								,nodo_elegido->nodo);
			//restauro disponibilidad y pongo puntero clock en 0
			pthread_mutex_lock(&mutex_yama_cfg);
			nodo_elegido->disponibilidad = yama_cfg->disponibilidad; //la que tenga en el archivo de configuracion
			pthread_mutex_unlock(&mutex_yama_cfg);
			//nodo_elegido->punteroClock = 0;
			//tomo el siguiente y lo pongo en 1

			//primero sumo el indice y me fijo si supera el tamaño de la lista
//			index_tabla_historial++;
//			pthread_mutex_lock(&mutex_tabla_historial_nodos);
//			if(index_tabla_historial==list_size(listaHistorialNodos)){
//			index_tabla_historial = 0;
//			}
//			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
//
//			pthread_mutex_lock(&mutex_tabla_historial_nodos);
//			nodo_elegido = (historial_nodo* )list_get(listaHistorialNodos,index_tabla_historial);
//			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
//			nodo_elegido->punteroClock = 1;
			incrementar_indice = false;

		}else{
			// tomo el siguiente sin modificar el puntero clock y  tiene dispo >0 y bloque asociado
			//primero sumo el indice y me fijo si supera el tamaño de la lista
			log_trace(yama_log,"el Nodo:%d no contiene al Bloque:%d ",nodo_elegido->nodo
					,bloque_num->num_bloque_ficticio);
			while(condicion_de_corte){
				if(incrementar_indice == true){
			index_tabla_historial++;
			pthread_mutex_lock(&mutex_tabla_historial_nodos);
			if(index_tabla_historial==list_size(listaHistorialNodos)){
			index_tabla_historial = 0;
			}
				}else{
					incrementar_indice= true;
				}
			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
			pthread_mutex_lock(&mutex_tabla_historial_nodos);
			nodo_elegido = (historial_nodo* )list_get(listaHistorialNodos,index_tabla_historial);
			log_trace(yama_log,"se analiza si el Nodo:%d contiene al Bloque:%d ",nodo_elegido->nodo
								,bloque_num->num_bloque_ficticio);
			pthread_mutex_unlock(&mutex_tabla_historial_nodos);
			if(nodo_elegido->disponibilidad > 0){
				if(el_nodo_tiene_el_bloque(nodo_elegido,listaNodosBloques,bloque_num)){
					nodo_elegido->disponibilidad--;
					log_trace(yama_log,"el Bloque:%d es asignado al Nodo:%d",bloque_num->num_bloque_ficticio
										,nodo_elegido->nodo);
					//agrego el bloque a la lista del nodo y actualizo la lista de carga de nodos
					carga_de_nodo = buscarNodoEnListaCargaNodos(nodo_elegido->nodo);
					carga_de_nodo->cargaActual ++;
					nodo_elegido->bytesOcupados = bloque_num->bytes_ocupados;
					list_add(nodo_elegido->bloques,(void*)bloque_num);
					condicion_de_corte=false; // TOnodo_con_bloquesl
					pthread_mutex_lock(&mutex_yama_cfg);
					usleep(yama_cfg->retardo* 10000); //la que tenga en el archivo de configuracion
					pthread_mutex_unlock(&mutex_yama_cfg);

		    		}else{
				log_trace(yama_log," el Nodo:%d no contiene el bloque:%d",nodo_elegido->nodo
						,bloque_num->num_bloque_ficticio);
				//incrementar_indice = false;
		    		}

	    		}else{
	    			log_trace(yama_log," el Nodo:%d tiene disponibilidad igual a 0 se restaura la misma"
	    					,nodo_elegido->nodo);
	    			pthread_mutex_lock(&mutex_yama_cfg);
					nodo_elegido->disponibilidad = yama_cfg->disponibilidad;
					pthread_mutex_unlock(&mutex_yama_cfg);
					incrementar_indice = false;
	    		}
    		}

    	}

	}


		if(incrementar_indice == false){

			incrementar_indice = true;
		}else{
			index_tabla_sin_repetidos++;
		}
	}

	list_clean(lista_sin_repetidos);
	list_destroy(lista_sin_repetidos);
	list_clean(listaHistorialNodos);
	list_destroy(listaHistorialNodos);

}




bool el_nodo_tiene_el_bloque(historial_nodo* nodo_elegido,t_list *listaNodosBloques,bloque* bloque_num){
	bloques_en_archivo* nodo_con_bloque;

	bool encontrarNodo(void*data){
		bloques_en_archivo* ncb = (bloques_en_archivo*)data;
		return ncb->nodo == nodo_elegido->nodo;

	}

	//del nodo que tiene el puntero me fijo en la lista que me pasa el FS, cual es
	nodo_con_bloque = (bloques_en_archivo*) list_find(listaNodosBloques,encontrarNodo);



		bool tieneABloque(void* data){
			bloque* unBloq = (bloque*) data;

			return unBloq->num_bloque_ficticio == bloque_num->num_bloque_ficticio;

		}
		//luego con el mismo me fijo si esta en la lista de bloqe que tiene ese nodo con el puntero
	return list_any_satisfy(nodo_con_bloque->bloques,tieneABloque);

}
int obtenerElqueTengaPuntero(t_list* tabla_h_nodos){
	bool condicion_de_corte = true;
	int indice_tabla_historial = 0;
	historial_nodo* nodo_local;

	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	while(condicion_de_corte){

		nodo_local = (historial_nodo*)list_get(tabla_h_nodos, indice_tabla_historial);
		if(nodo_local->punteroClock == 1){
			condicion_de_corte = false;
		}else{
		indice_tabla_historial++;
		}

	}
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);

	return indice_tabla_historial;



}
bool establoqueEnLista(bloque* Bloque, t_list *listaOrdSinRepe){
	bool estaEnLista(bloque *data){

		if(data->num_bloque_ficticio == Bloque->num_bloque_ficticio){
			return true;
		}else{
			return false;
		}


	}

	return list_any_satisfy(listaOrdSinRepe,(void*)estaEnLista);

}

t_list* obtenerListaDeBloquesOrdenadosSinRepetir(t_list *lista_Nodos_Bloques){
	bloques_en_archivo* nodo_con_bloques;
	bloque* unBloque;
	t_list* listaOrdSinRepe = list_create();
	int size_lista_nodo_bloques = list_size(lista_Nodos_Bloques);
	int index_lista_nodo_bloques = 0;
	int index_lista_bloques = 0;
	//primero tomo el primer elemento de la lista que me da FS
	while (size_lista_nodo_bloques >0){
		//luego tomo la lista de los bloques
		nodo_con_bloques = (bloques_en_archivo*)list_get(lista_Nodos_Bloques,index_lista_nodo_bloques);
		int size_lista_bloques = list_size(nodo_con_bloques->bloques);
		//tomo los bloques y lo asigno a mi lista de numeros
		while(size_lista_bloques > 0){
			unBloque = (bloque*) list_get(nodo_con_bloques->bloques,index_lista_bloques);

			if(!establoqueEnLista(unBloque,listaOrdSinRepe)){
			list_add(listaOrdSinRepe,unBloque);
			}
			index_lista_bloques ++;
			size_lista_bloques--;
		}
		index_lista_bloques = 0;
		index_lista_nodo_bloques++;
		size_lista_nodo_bloques--;
	}


	bool bloque_menor_a_mayor(bloque *b1, bloque *b2) {
	return b1->num_bloque_ficticio <= b2->num_bloque_ficticio;
	}

	list_sort(listaOrdSinRepe, (void*)bloque_menor_a_mayor);
	//eliminarRepetidos(listaOrdSinRepe);

return listaOrdSinRepe;

}
//void eliminarRepetidos(t_list* listaSinRepe){
//	int i = 0;
//	int j = 1;
//	bloque b1;
//	bloque b2;
//	while(i <(list_size(listaSinRepe)-1)){
//		 b1 = (bloque) list_get(listaSinRepe,i);
//		 b2 = (bloque) list_get(listaSinRepe,j);
//		 if(b1.num_bloque == b2.num_bloque){
//			 list_remove(listaSinRepe,j);
//
//		 }else{
//			 i++;
//			 j++;
//		 }
//
//
//
//	}
//
//}
//lo pongo en el primero porque el algortimo es clock
void posicionarPuntero(t_list* tabla_historial,tratar_job* job_creado){
	historial_nodo* nodo;
	t_list* lista_resultante_del_job;
	bool obtenerPorJob(void* data){
		historial_nodo* h1 = (historial_nodo*) data;
		return h1->master == job_creado->master;

	}

	//obtener lista de solo ese job
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	lista_resultante_del_job = list_filter(tabla_historial_nodos,obtenerPorJob);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);


	nodo = (historial_nodo*) list_get(lista_resultante_del_job,0);

	nodo->punteroClock = 1;

	list_destroy(lista_resultante_del_job);

	//log_trace(yama_log,"se posiciona el puntero en NODO: %d",nodo->nodo);


}

void agregarATablaDeEstados(t_list* T_H_NODOS){
	int	index_historial_nodo = 0;
	int index_bloques_nodo = 0;
	historial_nodo* un_nodo;
	char* nombreNuevoArchivo;
	//tomamos de la tabla historial de nodos que armamos y con eso armamos la tabla de estados
	//transformaciones y redu locales

	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	int tam_T_H_NODOS = list_size(T_H_NODOS);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);


	while(index_historial_nodo < tam_T_H_NODOS){
	 pthread_mutex_lock(&mutex_tabla_historial_nodos);
	 un_nodo =(historial_nodo*) list_get(T_H_NODOS,index_historial_nodo);
	 pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	 if(un_nodo->enviar_a_master == 1){
	while(index_bloques_nodo <list_size(un_nodo->bloques)){

		bloque* unBloque = (bloque*) list_get(un_nodo->bloques,index_bloques_nodo);

		nombreNuevoArchivo= string_new();

		 char* master_p_r = string_itoa(un_nodo->master);
		 char* nodo_p_r = string_itoa(un_nodo->nodo);
		 char* bloque_p_r = string_itoa(unBloque->num_bloque_real);
		string_append(&nombreNuevoArchivo,"TransformacionMaster");
		string_append(&nombreNuevoArchivo,master_p_r);
		string_append(&nombreNuevoArchivo,"Nodo");
		string_append(&nombreNuevoArchivo,nodo_p_r);
		string_append(&nombreNuevoArchivo,"Bloque");
		string_append(&nombreNuevoArchivo,bloque_p_r);
		string_append(&nombreNuevoArchivo,".txt");

		actualizarTablaDeEstados("AGREGAR JOB","TRANSFORMACION",un_nodo->master,un_nodo->sock_master,un_nodo->nodo,"N",un_nodo->ip,un_nodo->puerto,unBloque->num_bloque_real,unBloque->bytes_ocupados,nombreNuevoArchivo,0,unBloque->num_bloque_ficticio);
		log_trace(yama_log,"SE AGREGA A TABLA DE ESTADOS LA TRANSFORMACION PARA EL NODO:%d CON BLOQUE REAL:%d del BLOQUE FICTICIO",un_nodo->nodo,unBloque->num_bloque_real,unBloque->num_bloque_real);
		free(nombreNuevoArchivo);
		free(master_p_r);
		free(nodo_p_r);
		free(bloque_p_r);
		index_bloques_nodo++;

	}

	nombreNuevoArchivo= string_new();

	 char* master_p_r = string_itoa(un_nodo->master);
	 char* nodo_p_r = string_itoa(un_nodo->nodo);
	string_append(&nombreNuevoArchivo,"ReduccionLocalMaster");
	string_append(&nombreNuevoArchivo,master_p_r);
	string_append(&nombreNuevoArchivo,"Nodo");
	string_append(&nombreNuevoArchivo,nodo_p_r);
	string_append(&nombreNuevoArchivo,".txt");

	actualizarTablaDeEstados("AGREGAR JOB","REDUCCION LOCAL",un_nodo->master,un_nodo->sock_master,un_nodo->nodo,"N",un_nodo->ip,un_nodo->puerto,NULL,un_nodo->bytesOcupados,nombreNuevoArchivo,0,NULL);
	log_trace(yama_log,"SE AGREGA A TABLA DE ESTADOS REDUCCION LOCAL PARA EL NODO:%d",un_nodo->nodo);
	free(nombreNuevoArchivo);
	free(master_p_r);
	free(nodo_p_r);

	}
	 index_bloques_nodo = 0;
	index_historial_nodo ++;

	}
}

historial_nodo * nodoListoParaEjecutar(t_list* lista_H_nodos){

	bool nodo_preparado(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->enviar_a_master == 1;
	}

	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	historial_nodo* nodo_listo = (historial_nodo*)list_find(lista_H_nodos,nodo_preparado);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	return nodo_listo;

}

historial_nodo * nodoConPuntero(t_list* lista_H_nodos){

	bool nodo_con_puntero(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->punteroClock == 1;
	}

	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	historial_nodo* nodo_listo = (historial_nodo*)list_find(lista_H_nodos,nodo_con_puntero);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);

	return nodo_listo;

}
//primero busco en la tabla historial si hay uno busco en la tabla de estados
// y desde la misma mando a ejecutar a todos los bloques de los nodos
// y actualizo el historial

void enviarTransformaciones(t_list* lista_H_nodos){
	bool condicion_de_corte_Thistorial = true;
	bool condicion_de_corte_TEstados = true;
	estado_de_un_job* nodo_estado;
	t_mensaje_HEADER headermaster;
	char* buffer;
	int largo;
	t_pNodo_transformacion* nodoAmaster;// = malloc(sizeof(t_pNodo_transformacion));




	while(condicion_de_corte_Thistorial){
	// tomamos el que esta listo para enviar
	historial_nodo * nodo_a_enviar = nodoListoParaEjecutar(lista_H_nodos);
	condicion_de_corte_TEstados= true;

		if(nodo_a_enviar != NULL){
	while(condicion_de_corte_TEstados){

		//tomo el primer elemento de a tabla de estados
		nodo_estado = tomarElemento("TRANSFORMACION",nodo_a_enviar->master,nodo_a_enviar->nodo,-1,"N");


		if (nodo_estado != NULL){
			nodoAmaster = malloc(sizeof(t_pNodo_transformacion));

		//actualizo el estado del nodo
		actualizarTablaDeEstados("MODIFICAR","TRANSFORMACION",nodo_a_enviar->master,nodo_a_enviar->sock_master,nodo_a_enviar->nodo,"EN PROCESO",NULL,NULL,nodo_estado->bloque,NULL,NULL,NULL,NULL);

		log_trace(yama_log,"Se envia a Master a transformar el BLOQUE REAL: %d del BLOQUE FICTICIO:%d al NODO: %d y bytes ocupados:%d",nodo_estado->bloque,nodo_estado->bloqueFicticio,nodo_a_enviar->nodo,
				nodo_estado->bytesOcupados);
		 //paso estructuras para enviar a master
		pasarDeEstructura(nodo_estado,nodoAmaster);


	    headermaster.codigoMensaje = PARAMETROS_TRANSFORMACION;
	    //esto solamente manda el tamaño de la lista junto con el tamaño de la cantidad de niveles es decir el
		//sizeof
		headermaster.tamanio = sizeof(int32_t)*6 + nodoAmaster->archivo_resultado_largo + nodoAmaster->nodo_ip_largo + nodoAmaster->nodo_puerto_largo;
		//sizeof(int32_t)+tamanioLista(mensajeTrasnformacion.listaNodos);
		if(!enviar_mensaje_header(&headermaster,nodo_a_enviar->sock_master)){
			log_trace(yama_log,"Error al querer enviar la TRANSFORMACION al nodo");
		}
		buffer = serializeMsjTransformacion(nodoAmaster,&largo);
		sendall(nodo_a_enviar->sock_master,buffer,largo);
		free(buffer);

		free(nodoAmaster->archivo_resultado);
		free(nodoAmaster->nodo_ip);
		free(nodoAmaster->nodo_puerto);
		free(nodoAmaster);
		//free(nodo_estado);
		//condicion_de_corte_TEstados = false;

		}else{
		condicion_de_corte_TEstados = false;
		// ponemos para que no se envia a master
		//nodo_a_enviar->enviar_a_master = 0;
			nodo_a_enviar->enviar_a_master = 0;

		}
	}

		}
		else{

			condicion_de_corte_Thistorial= false;

		}
	}



}
t_list* filtarPorNombreArchivo(t_list* bloques_por_archivo,char* job_a_replanificar){
	bool es_mismoArchivo(void*data){
	bloques_en_archivo* bloques = (bloques_en_archivo*) data;
	return strcmp(bloques->nombre_archivo,job_a_replanificar) == 0;
	}
	pthread_mutex_lock(&mutex_bloques_x_archivo);
	t_list* nodos_de_archivo =  list_filter(bloques_por_archivo,es_mismoArchivo);
	pthread_mutex_unlock(&mutex_bloques_x_archivo);
	return nodos_de_archivo;
}

void agregarATablaBloquesPorArchivo(t_list* lista_de_n_con_bloques,t_list* x,t_list* lista_j_nuevos){
	pthread_mutex_lock(&mutex_bloques_x_archivo);
	int list_size_bloques_x_nodo = list_size(bloques_x_archivo);
	pthread_mutex_unlock(&mutex_bloques_x_archivo);

	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
	tratar_job* job_creado = (tratar_job*) list_get(lista_jobs_nuevos,0);
	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);



	int tm1;
	int list_size_lista_de_nod_con_bloques= tm1 =list_size(lista_de_nodos_con_bloques);
	int i = 0;
	bloques_en_archivo* nuevoNodo;
	bloques_en_archivo* nodoEnBloquesPorArchivo;// elemento que se encuentra en lista blques por archivo
	if(list_size_bloques_x_nodo == 0){
		while(tm1>0){
	pthread_mutex_lock(&mutex_bloques_x_archivo);
	nuevoNodo = (bloques_en_archivo*)list_get(lista_de_nodos_con_bloques,i);
	//list_add_all(bloques_x_archivo,lista_de_nodos_con_bloques);
	list_add(bloques_x_archivo,(void*)nuevoNodo);
	pthread_mutex_unlock(&mutex_bloques_x_archivo);
	tm1--;
	i++;
		}
		 //i = 0;
	}else{

		//

		t_list* temporal =filtarPorNombreArchivo(bloques_x_archivo,job_creado->nombre_archivo);

		if(list_size(temporal) !=0){
			list_destroy(temporal);
		while(i < list_size_lista_de_nod_con_bloques){
			nuevoNodo = (bloques_en_archivo*)list_get(lista_de_nodos_con_bloques,i);
			bool estaEnListaBloques_por_archivo( void*data){
				bloques_en_archivo* nodo = (bloques_en_archivo*)data;

				return nodo->nodo == nuevoNodo->nodo;
			}
			pthread_mutex_lock(&mutex_bloques_x_archivo);
			if(!list_any_satisfy(bloques_x_archivo,estaEnListaBloques_por_archivo)){
				pthread_mutex_unlock(&mutex_bloques_x_archivo);
				//si no esta agrego el nodo con los bloques
				pthread_mutex_lock(&mutex_bloques_x_archivo);
				list_add(bloques_x_archivo,(void*)nuevoNodo);
				pthread_mutex_unlock(&mutex_bloques_x_archivo);

			}else{
				pthread_mutex_unlock(&mutex_bloques_x_archivo);
				//si ya esta agrego el bloque en el nodo
				bool encontrarNodo(void*data){
					bloques_en_archivo* ncb = (bloques_en_archivo*)data;
					return ncb->nodo == nuevoNodo->nodo;

				}

				//busco el nodo de la lista que me viene del FS
				pthread_mutex_lock(&mutex_bloques_x_archivo);
				nodoEnBloquesPorArchivo = (bloques_en_archivo*) list_find(bloques_x_archivo,encontrarNodo);
				pthread_mutex_unlock(&mutex_bloques_x_archivo);
				int tamListaBloques = list_size(nuevoNodo->bloques);
				int indexListaBloques = 0;
				bloque* unBlock;

				while(indexListaBloques< tamListaBloques){
				unBlock = (bloque*) list_get(nuevoNodo->bloques,indexListaBloques);
				//preguntamos si lo tiene el bloque de ser asi no lo agregamos

				bool tieneElBloque(void* data){
					bloque* unbloque = (bloque*) data;

					return unbloque->num_bloque_real == unBlock->num_bloque_real && unbloque->num_bloque_ficticio
							== unBlock->num_bloque_ficticio;

				}


				if(!list_any_satisfy(nodoEnBloquesPorArchivo->bloques,tieneElBloque)){
					list_add(nodoEnBloquesPorArchivo->bloques, (void*)unBlock);
				}



				indexListaBloques++;
				}

			}
			i++;
		}


	}else{
		list_destroy(temporal);
		while(tm1>0){
		pthread_mutex_lock(&mutex_bloques_x_archivo);
		nuevoNodo = (bloques_en_archivo*)list_get(lista_de_nodos_con_bloques,i);
		//list_add_all(bloques_x_archivo,lista_de_nodos_con_bloques);
		list_add(bloques_x_archivo,(void*)nuevoNodo);
		pthread_mutex_unlock(&mutex_bloques_x_archivo);
		tm1--;
		i++;
			}



	}
	}
}

bool elNodotieneEseBloque(bloques_en_archivo* nodo_nuevo,int bloque_num){
	bool tieneElBloque(void* data){
		bloque* unbloque = (bloque*) data;

		return unbloque->num_bloque_ficticio == bloque_num;

	}

	return list_any_satisfy(nodo_nuevo->bloques,(void*)tieneElBloque);
}



bool eraElNodoEncagardo(tratar_job* job_a_replani, carga_nodo*c_de_nodo,t_list* tabla_h_nodos){
	historial_nodo * nodoEncargado;

	bool  encontrarNodoDeMaster(void*data){
		historial_nodo * h1 = (historial_nodo * )data;
		return h1->master == job_a_replani->master && h1->nodo == c_de_nodo->nodo;
	}
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	nodoEncargado = (historial_nodo *)list_find(tabla_h_nodos,encontrarNodoDeMaster);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);



	return nodoEncargado->encargado == 1;


}


void ponerAtodosLosElementosConError (int master,int nodo_num){


	t_list* listaFiltrada;
	bool filtrarPorMasterYNodo(void*data){
		estado_de_un_job* estado = (estado_de_un_job*) data;
		char** nodo = string_split(estado->nodo," ");
		if(estado->id_master == master && atoi(nodo[1]) == nodo_num){
			free(nodo[0]);
			free(nodo[1]);
			free(nodo);

			return true;
		}else{
			free(nodo[0]);
			free(nodo[1]);
			free(nodo);

			return false;
		}

	}


	pthread_mutex_lock(&mutex_tabla_de_estados);
	listaFiltrada= list_filter(tabla_de_estados,filtrarPorMasterYNodo);
	pthread_mutex_unlock(&mutex_tabla_de_estados);

	int tamanioLista=list_size(listaFiltrada);
	int i;
	for(i=0;i< tamanioLista;i++){
		estado_de_un_job* estado = list_get(listaFiltrada,i);
		if(strcmp(estado->etapa,"TRANSFORMACION")!= 0 && strcmp(estado->estado,"ERROR") != 0){
			free(estado->estado);
			estado->estado = string_new();
			string_append(&estado->estado,"ABORTIVO");

		}



	}



list_destroy(listaFiltrada);
}



void enviar_transformaciones_finalizadas(int master_id, int nodo_id,int socket_id, t_list* lista_bloques_archivos){

	t_list*listaFiltrada_t_e;
	t_list* listaFiltradas_transf_terminadas;
	estado_de_un_job* estado;
	bloques_en_archivo* nodo_nuevo;
	estado_de_un_job* nodo_estado;
	carga_nodo*carga_de_nodo;
	char* buffer;
	int largo;
	t_mensaje_HEADER headermaster;
	log_debug(yama_log,"enviar_transformaciones_finalizadas --> init");
	int index_tabla_filtrada = 0;
	bool condicionDeCorte;
	transfomaciones_enviadas* transformacionAEnviar;
	//transfomaciones_enviadas* transformacionAEnviar1;
	t_pNodo_transformacion* nodoAmaster;

	bool seEnvioTransformaciones(void *data){
		transfomaciones_enviadas* t_e = (transfomaciones_enviadas*) data;
		return t_e->master == master_id && t_e->nodo == nodo_id;

	}

	listaFiltrada_t_e = list_filter(lista_transformacion_enviadas,seEnvioTransformaciones);

	if(list_size(listaFiltrada_t_e) == 0){
		//agregamos a la lista
		transformacionAEnviar = malloc(sizeof(transfomaciones_enviadas));
		transformacionAEnviar->master = master_id;
		transformacionAEnviar->nodo = nodo_id;

		list_add(lista_transformacion_enviadas,(void*)transformacionAEnviar);
		//buscamos las transformaciones ya enviadas


		bool transformacionesFinalizadas(void* data){
			estado_de_un_job* j1 = (estado_de_un_job*) data;
			char** nodo =string_split(j1->nodo," ");
			if(strcmp(j1->etapa,"TRANSFORMACION") == 0 && j1->id_master == master_id &&atoi(nodo[1]) == nodo_id && strcmp(j1->estado,"FINALIZADO") == 0){
				free(nodo[1]);
				free(nodo[0]);
				free(nodo);
				return true;
			}else{
				free(nodo[1]);
				free(nodo[0]);
				free(nodo);
			    return	false;
			}


		}




		pthread_mutex_lock(&mutex_tabla_de_estados);
		listaFiltradas_transf_terminadas = list_filter(tabla_de_estados,transformacionesFinalizadas);
		pthread_mutex_unlock(&mutex_tabla_de_estados);
		if(list_size(listaFiltradas_transf_terminadas)!=0){
			//tomamos bolque por bloque ya transformado y lo enviamos al que tenga la copia
		int i;
		int tamanioListaDeNodosDelArchivo = list_size(lista_bloques_archivos);
		for(i = 0; i <list_size(listaFiltradas_transf_terminadas) ;i++  ){
			condicionDeCorte = true;
		 estado = list_get(listaFiltradas_transf_terminadas,i);

		while(condicionDeCorte){
		log_debug(yama_log,"Se asigna el bloque:%d a el nodo que contenga la copia",estado->bloque);

			//nodo_nuevo = obtenerNodoDistintoAlReplanificado(listadenodosDelArchivo,job_a_replanificar);
			nodo_nuevo = list_get(lista_bloques_archivos,index_tabla_filtrada);
			if(nodo_nuevo->nodo !=nodo_id){
			if(elNodotieneEseBloque(nodo_nuevo,estado->bloqueFicticio)){
			log_debug(yama_log,"Se envia el bloque:%d a al nodo:%d ,el mismo contiene la copia",
					estado->bloqueFicticio,nodo_nuevo->nodo);

			nodoAmaster = malloc(sizeof(t_pNodo_transformacion));

			//tomo el nuevo bloque real
			bool buscarElReal(void*data){
				bloque* bloqueR = (bloque*)data;
				return bloqueR->num_bloque_ficticio == estado->bloqueFicticio;
			}

			bloque * bloqueReal =list_find(nodo_nuevo->bloques,buscarElReal);



			char* nombreNuevoArchivo;
			char* master_p_r = string_itoa(master_id);
			char*nodo_p_r = string_itoa(nodo_nuevo->nodo);
			char*bloque_p_r = string_itoa(estado->bloque);

			nombreNuevoArchivo= string_new();
			string_append(&nombreNuevoArchivo,"TransformacionMaster");
			string_append(&nombreNuevoArchivo,master_p_r);
			string_append(&nombreNuevoArchivo,"Nodo");
			string_append(&nombreNuevoArchivo,nodo_p_r);
			string_append(&nombreNuevoArchivo,"Bloque");
		    string_append(&nombreNuevoArchivo,bloque_p_r);
			string_append(&nombreNuevoArchivo,".txt");

			// al nodo que tiene el bloque le agregamos la transformacion y la reduccion local le cambiamos denuvo el estado
		actualizarTablaDeEstados("AGREGAR JOB","TRANSFORMACION",master_id,socket_id,nodo_nuevo->nodo,"N",nodo_nuevo->ip,nodo_nuevo->puerto,bloqueReal->num_bloque_real,bloqueReal->bytes_ocupados,nombreNuevoArchivo,0,bloqueReal->num_bloque_ficticio);
		free(master_p_r);
					free(nodo_p_r);
					free(bloque_p_r);
					free(nombreNuevoArchivo);

					nodo_estado = tomarElemento("TRANSFORMACION",master_id,nodo_nuevo->nodo,estado->bloque,"N");

					//imprimir_tabla_estados(tabla_de_estados);


					//modifico estado
				actualizarTablaDeEstados("MODIFICAR","TRANSFORMACION",master_id,socket_id,nodo_nuevo->nodo,"EN PROCESO",NULL,NULL,estado->bloque,NULL,NULL,NULL,NULL);


					//sumar la carga al nodo nuevo
					carga_de_nodo = buscarNodoEnListaCargaNodos(nodo_nuevo->nodo);
					carga_de_nodo->cargaActual = carga_de_nodo->cargaActual +1;

					//envio la nueva transformacion
					pasarDeEstructura(nodo_estado,nodoAmaster);
				    headermaster.codigoMensaje = PARAMETROS_TRANSFORMACION;
				    //esto solamente manda el tamaño de la lista junto con el tamaño de la cantidad de niveles es decir el
					//sizeof
					headermaster.tamanio = sizeof(int32_t)*6 + nodoAmaster->archivo_resultado_largo + nodoAmaster->nodo_ip_largo + nodoAmaster->nodo_puerto_largo;
					//sizeof(int32_t)+tamanioLista(mensajeTrasnformacion.listaNodos);
					if(!enviar_mensaje_header(&headermaster,socket_id)){
						log_trace(yama_log,"Error al querer enviar la TRANSFORMACION al nodo");
					}
					buffer = serializeMsjTransformacion(nodoAmaster,&largo);
					sendall(socket_id,buffer,largo);
					free(buffer);
					//free(nodo_estado);

					free(nodoAmaster->archivo_resultado);
					free(nodoAmaster->nodo_ip);
					free(nodoAmaster->nodo_puerto);
					free(nodoAmaster);



					index_tabla_filtrada = -1;
					//cambiar la condicion de corte
					condicionDeCorte= false;

			}
		    }
			index_tabla_filtrada++;
			if(tamanioListaDeNodosDelArchivo == index_tabla_filtrada && condicionDeCorte != false){
			t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
			condicionDeCorte = false;
			estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",master_id,-1,-1,"N");
			if(nodo_elegido == NULL){
			if(!enviar_mensaje_header(&headermaster,socket_id)){
			log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");
			}
			log_trace(yama_log,"ERROR no se encuentra una copia para el BLOQUE: %d  del bloque ficticio:%d master: %d SE ABORTA EL JOB",
					estado->bloque,estado->bloqueFicticio,master_id);


					 }
		    	}

	       }

     	}

	}

		list_destroy(listaFiltradas_transf_terminadas);

	}

	list_destroy(listaFiltrada_t_e);
	log_debug(yama_log,"enviar_transformaciones_finalizadas --> END");
}


void replanificarTarea(t_list* bloques_por_archivo,t_list* lista_j_a_replanificar,t_list* lista_carga_de_n,t_list* tabla_h_nodos){
	tratar_job* job_a_replanificar;
	bloques_en_archivo* nodo_nuevo;
	int * error= malloc(sizeof(int));
	*error = 0; // error necesario para ver si se puede asignar algun nodo para que haga la redu global
	carga_nodo*carga_de_nodo;
	char* buffer;
	int largo;
	t_mensaje_HEADER headermaster;
	estado_de_un_job* nodo_estado;
	estado_de_un_job* nodo_estado1;
	t_pNodo_transformacion* nodoAmaster = malloc(sizeof(t_pNodo_transformacion));
	//esta seria la tarea a replanificar me fijo si lo hacemos hilo y obtenemos siempre el ultimo
	pthread_mutex_lock(&mutex_lista_jobs_a_replanificar);
	job_a_replanificar = (tratar_job* ) list_get(lista_jobs_a_replanificar,0);
	pthread_mutex_unlock(&mutex_lista_jobs_a_replanificar);
	bool condicionDeCorte = true;
	int index_tabla_filtrada = 0;



	//marcamos el nodo como inactivo

//	bool obtenerNodo(void*data){
//			carga_nodo * nodo = (carga_nodo *) data;
//			return nodo->nodo ==  job_a_replanificar->nodo;
//
//		}
//		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
//		 carga_de_nodo = (carga_nodo * )list_find(lista_carga_de_nodos,obtenerNodo);
//		 pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
//		 carga_de_nodo->esta_activo = 0;
	carga_de_nodo = buscarNodoEnListaCargaNodos(job_a_replanificar->nodo);
	carga_de_nodo->esta_activo = 0;
	carga_de_nodo->cargaActual = 0;
	//carga_de_nodo = list_get(lista_carga_de_nodos,0);
		 //nos fijamos si era nodo encargado de la reduccion global
		 if(eraElNodoEncagardo(job_a_replanificar,carga_de_nodo,tabla_h_nodos)){
	log_debug(yama_log,"el bloque a replanificar era de un nodo encargado");

		ponerAtodosLosElementosConError(job_a_replanificar->master,job_a_replanificar->nodo);

		registrarReduccionGlobalEnTabla_replanificacion(tabla_historial_nodos,lista_carga_de_nodos,lista_jobs_a_replanificar,job_a_replanificar,error);

		 }else{
			 log_debug(yama_log,"el bloque a replanificar NO era de un nodo encargado");
			 ponerAtodosLosElementosConError(job_a_replanificar->master,job_a_replanificar->nodo);

		 }

		 if(*error == 0){
		 //filtramos por nombre de archivo
		 	t_list*listadenodosDelArchivo = filtarPorNombreArchivo(bloques_por_archivo,job_a_replanificar->nombre_archivo);
		 	int tamanioListaDeNodosDelArchivo = list_size(listadenodosDelArchivo);

		 //enviamos las transformaciones que ya hizo el nodo si es que ya las hiso
		 	enviar_transformaciones_finalizadas(job_a_replanificar->master,job_a_replanificar->nodo
		 			,job_a_replanificar->sock_master,listadenodosDelArchivo);

		 	nodo_estado1 = tomarElemento("TRANSFORMACION",job_a_replanificar->master,job_a_replanificar->nodo,job_a_replanificar->bloque,"ERROR");
	while(condicionDeCorte){
		log_debug(yama_log,"Se asigna el bloque ficticio:%d a el nodo que contenga la copia",nodo_estado1->bloqueFicticio);

		//nodo_nuevo = obtenerNodoDistintoAlReplanificado(listadenodosDelArchivo,job_a_replanificar);
		nodo_nuevo = list_get(listadenodosDelArchivo,index_tabla_filtrada);
		if(nodo_nuevo->nodo !=job_a_replanificar->nodo){

			//tomo el bloque ficticio




		if(elNodotieneEseBloque(nodo_nuevo,nodo_estado1->bloqueFicticio)){
			log_debug(yama_log,"Se envia el bloque ficticio:%d a al nodo:%d ,el mismo contiene la copia",
					nodo_estado1->bloqueFicticio,nodo_nuevo->nodo);


			//tomo el bloque real
			//tomo el nuevo bloque real
			bool buscarElReal(void*data){
			bloque* bloqueR = (bloque*)data;
			return bloqueR->num_bloque_ficticio == nodo_estado1->bloqueFicticio;
			}

			bloque * bloqueReal =list_find(nodo_nuevo->bloques,buscarElReal);



			char* nombreNuevoArchivo;
			char* master_p_r = string_itoa(job_a_replanificar->master);
			char*nodo_p_r = string_itoa(nodo_nuevo->nodo);
			char*bloque_p_r = string_itoa(job_a_replanificar->bloque);

			nombreNuevoArchivo= string_new();
			string_append(&nombreNuevoArchivo,"TransformacionMaster");
			string_append(&nombreNuevoArchivo,master_p_r);
			string_append(&nombreNuevoArchivo,"Nodo");
			string_append(&nombreNuevoArchivo,nodo_p_r);
			string_append(&nombreNuevoArchivo,"Bloque");
			string_append(&nombreNuevoArchivo,bloque_p_r);
			string_append(&nombreNuevoArchivo,".txt");

			// al nodo que tiene el bloque le agregamos la transformacion y la reduccion local le cambiamos denuvo el estado
			actualizarTablaDeEstados("AGREGAR JOB","TRANSFORMACION",job_a_replanificar->master,job_a_replanificar->sock_master,nodo_nuevo->nodo,"N",nodo_nuevo->ip,nodo_nuevo->puerto,bloqueReal->num_bloque_real,bloqueReal->bytes_ocupados,nombreNuevoArchivo,0,bloqueReal->num_bloque_ficticio);


		//al nodo que hay que fallo, le ponemos estado abortivoa todas las demas etapas


			free(master_p_r);
			free(nodo_p_r);
			free(bloque_p_r);
			free(nombreNuevoArchivo);

			nodo_estado = tomarElemento("TRANSFORMACION",job_a_replanificar->master,nodo_nuevo->nodo,job_a_replanificar->bloque,"N");

			//imprimir_tabla_estados(tabla_de_estados);


			//modifico estado
		actualizarTablaDeEstados("MODIFICAR","TRANSFORMACION",job_a_replanificar->master,job_a_replanificar->sock_master,nodo_nuevo->nodo,"EN PROCESO",NULL,NULL,job_a_replanificar->bloque,NULL,NULL,NULL,NULL);


			//sumar la carga al nodo nuevo
			carga_de_nodo = buscarNodoEnListaCargaNodos(nodo_nuevo->nodo);
			carga_de_nodo->cargaActual = carga_de_nodo->cargaActual +1;

			//envio la nueva transformacion
			pasarDeEstructura(nodo_estado,nodoAmaster);
		    headermaster.codigoMensaje = PARAMETROS_TRANSFORMACION;
		    //esto solamente manda el tamaño de la lista junto con el tamaño de la cantidad de niveles es decir el
			//sizeof
			headermaster.tamanio = sizeof(int32_t)*6 + nodoAmaster->archivo_resultado_largo + nodoAmaster->nodo_ip_largo + nodoAmaster->nodo_puerto_largo;
			//sizeof(int32_t)+tamanioLista(mensajeTrasnformacion.listaNodos);
			if(!enviar_mensaje_header(&headermaster,job_a_replanificar->sock_master)){
				log_trace(yama_log,"Error al querer enviar la TRANSFORMACION al nodo");
			}
			buffer = serializeMsjTransformacion(nodoAmaster,&largo);
			sendall(job_a_replanificar->sock_master,buffer,largo);
			free(buffer);
			//free(nodo_estado);
			log_trace(yama_log,"Se envia a Master a transformar el BLOQUE REAL: %d del BLOQUE FICTICIO:%d al NODO: %d y bytes ocupados:%d",nodo_estado->bloque,nodo_estado->bloqueFicticio
					,nodo_nuevo->nodo,nodo_estado->bytesOcupados);
			free(nodoAmaster->archivo_resultado);
			free(nodoAmaster->nodo_ip);
			free(nodoAmaster->nodo_puerto);
			free(nodoAmaster);




			//cambiar la condicion de corte
			condicionDeCorte= false;
		}
		}

		index_tabla_filtrada++;
		if(tamanioListaDeNodosDelArchivo == index_tabla_filtrada && condicionDeCorte != false){
			 t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
			condicionDeCorte = false;
		estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",job_a_replanificar->master,-1,-1,"N");
			if(nodo_elegido == NULL){
	   		if(!enviar_mensaje_header(&headermaster,job_a_replanificar->sock_master)){
   			log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");
		   		}
		log_trace(yama_log,"ERROR no se encuentra una copia para el BLOQUE: %d master: %d SE ABORTA EL JOB",
				job_a_replanificar->bloque,job_a_replanificar->master);


		}
		}
	}


		 }
	//free(nodoAmaster);
	free(error);
//	pthread_mutex_lock(&mutex_lista_jobs_a_replanificar);
//	list_remove(lista_j_a_replanificar,0);
//	pthread_mutex_unlock(&mutex_lista_jobs_a_replanificar);

}

static void eliminar_trata_job(void*data){
	tratar_job* job =(tratar_job*) data;
	free(job->nombre_archivo);
	free(job);

}

void* ejecutar_replanificacion(){
	while (1){
		sem_wait(&sem_job_replanificar);
		//me fijo en los otros nodos
		log_debug(yama_log,"COMIENZO DE RE PLANIFICACION");
		replanificarTarea(bloques_x_archivo,lista_jobs_a_replanificar,lista_carga_de_nodos,tabla_historial_nodos);
		pthread_mutex_lock(&mutex_lista_jobs_a_replanificar);
		list_remove_and_destroy_element(lista_jobs_a_replanificar,0,eliminar_trata_job);
		pthread_mutex_unlock(&mutex_lista_jobs_a_replanificar);
		//borrarListaREplanificacion();
	}


	return NULL;
}
carga_nodo* tomarcargaDeNodoSegunTablaHistorial(t_list*tabla_H_nodos,t_list* lista_carga_de_N, tratar_job* job, int indice){
	t_list* listaFiltrada;
	historial_nodo* nodo_del_indice;
	carga_nodo* carga_nodo_indice;
	bool condicion_de_corte= true;
	bool filtrarPorMaster(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->master == job->master;// && nodo->enviar_a_master == 1;

	}

	bool filtrarPorMasterYdistintoDeNodo(void*data){
		historial_nodo* nodo = (historial_nodo*) data;

				return nodo->master == job->master  && nodo->nodo != job->nodo ;

	}


	//primer busco todos los nodo del master a filtrar y me fijo que el enviar a master este en 1 en la T.historial
	if(indice != 9999){
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	listaFiltrada= list_filter(tabla_H_nodos,filtrarPorMaster);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);

	}else{
		pthread_mutex_lock(&mutex_tabla_historial_nodos);
		listaFiltrada= list_filter(tabla_H_nodos,filtrarPorMasterYdistintoDeNodo);
		pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	}
	//tomo el primero de la lista filtrada y de eso tomo el nodo que me voy a en la carga del mismo
	if(indice != 9999){
		nodo_del_indice = (historial_nodo*) list_get(listaFiltrada,indice);

		bool tomarCargaDeNodo(void* data){
			carga_nodo* carga_nod = (carga_nodo*) data;

			return carga_nod->nodo == nodo_del_indice->nodo && carga_nod->esta_activo == 1;
		}

		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
		carga_nodo_indice = (carga_nodo*) list_find(lista_carga_de_N,tomarCargaDeNodo);
		pthread_mutex_unlock(&mutex_lista_carga_de_nodos);



	}else{
		int i = 0;
		while(condicion_de_corte){

		nodo_del_indice = (historial_nodo*) list_get(listaFiltrada,i);

		bool tomarCargaDeNodo(void* data){
		carga_nodo* carga_nod = (carga_nodo*) data;

		return carga_nod->nodo == nodo_del_indice->nodo && carga_nod->esta_activo == 1;
		}

		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
		carga_nodo_indice = (carga_nodo*) list_find(lista_carga_de_N,tomarCargaDeNodo);
		pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

		if(carga_nodo_indice == NULL){
			i++;

		}else{
			condicion_de_corte = false;
		}

		}
	}



	list_clean(listaFiltrada);
	list_destroy(listaFiltrada);

return carga_nodo_indice;
}
bool todos_tienen_misma_carga(t_list* lista_historial_Filtrada,t_list* lista_carga_de_N){
	int i = 0;
	bool condicion_de_corte = true;
	int tamanio = list_size(lista_historial_Filtrada);
	historial_nodo* nodo = (historial_nodo*) list_get(lista_historial_Filtrada,i);
	bool tomarNodo (void* data){
		carga_nodo* carga = (carga_nodo*) data;
		return carga->nodo == nodo->nodo;
	}
	pthread_mutex_lock(&mutex_lista_carga_de_nodos);
	carga_nodo* nodoAprobar = (carga_nodo*) list_find(lista_carga_de_N,tomarNodo);
	pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
	i ++;
	while(tamanio > i && condicion_de_corte == true){
		historial_nodo* nodo1 = (historial_nodo*) list_get(lista_historial_Filtrada,i);
		bool tomarNodo1 (void* data){
				carga_nodo* carga = (carga_nodo*) data;
				return carga->nodo == nodo1->nodo;
			}
		pthread_mutex_lock(&mutex_lista_carga_de_nodos);
		carga_nodo* nodoAprobar1 = (carga_nodo*) list_find(lista_carga_de_N,tomarNodo1);
		pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
		if(nodoAprobar->cargaActual != nodoAprobar1->cargaActual){
			condicion_de_corte = false;
		}
		i++;
		//tamanio --;
	}


return condicion_de_corte;


}



static void borrarBloques(void*data){
	bloque* b1 = (bloque*) data;
	free(b1);

}


//eliminamos elemento de la tabla historial de nodos
static void eliminarListaHistorial (void*data){
historial_nodo* historial = (historial_nodo*) data;
free(historial->ip);



list_destroy_and_destroy_elements(historial->bloques,(void*)borrarBloques);

free(historial);

}


void registrarReduccionGlobalEnTabla(t_list* tabla_H_nodos,t_list* lista_carga_de_N,t_list* lista_J_nuevos,tratar_job* job,int* error){

	int index_i_tabla_historial = 0;
	int index_j_tabla_historial = 1;
	historial_nodo* nodo;
	carga_nodo * n1;
	carga_nodo * n2;
	carga_nodo * nodoelegido;// = malloc(sizeof(carga_nodo));
	t_list* lista_temporal;
	// aca puede venir tanto de la lista de jobs nuevos como de la lista de replanificacion de jobs
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	job = (tratar_job*) list_get(lista_J_nuevos,list_size(lista_J_nuevos)-1);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);
	t_list* listaFiltrada = list_create();
	bool filtrarPorMaster(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->master == job->master && nodo->nodo != job->nodo; // && nodo->enviar_a_master == 1;

	}

	//primer busco todos los nodo del master a filtrar y me fijo que el enviar a master este en 1 en la T.historial
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	lista_temporal = list_filter(tabla_H_nodos,filtrarPorMaster);
	list_add_all(listaFiltrada,lista_temporal);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	/*int tamanioLista = list_size(listaFiltrada);
	int i;
	for(i=0;i< tamanioLista;i++){
		historial_nodo* nodo = list_get(listaFiltrada,i);

		bool resultado;

			bool encontrar_nodo(void* data){
				carga_nodo * carga_de_nodo = (carga_nodo *) data;
				return carga_de_nodo->nodo == nodo->nodo && carga_de_nodo->esta_activo == 1;

			}
			pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			resultado = list_any_satisfy(lista_carga_de_nodos,encontrar_nodo);
			pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

			if(resultado == false){
			list_remove(listaFiltrada,i);
			}

	}*/
	int tamanioLista = list_size(listaFiltrada);
		historial_nodo* nodo_for;
		int i = 0;
		int indice;
		bool seBorroNodo= false;

		while(i< tamanioLista){
			if(seBorroNodo){
	//			 indice = i;
	//			indice = indice -1;
				 nodo_for = list_get(listaFiltrada,i);
				seBorroNodo = false;
				tamanioLista = list_size(listaFiltrada);
			}else{
				 nodo_for = list_get(listaFiltrada,i);
				 //indice = i;
			}


			bool resultado;

				bool encontrar_nodo(void* data){
					carga_nodo * carga_de_nodo = (carga_nodo *) data;
					return carga_de_nodo->nodo == nodo_for->nodo && carga_de_nodo->esta_activo == 1;

				}
				pthread_mutex_lock(&mutex_lista_carga_de_nodos);
				resultado = list_any_satisfy(lista_carga_de_nodos,encontrar_nodo);
				pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

				if(resultado == false){
				list_remove(listaFiltrada,i);
				tamanioLista = list_size(listaFiltrada);
				seBorroNodo = true;
				}else{
					i++;
				}

		}


		tamanioLista = list_size(listaFiltrada);




		if(list_size(listaFiltrada) != 0){
		//me fijo si todos tienen la carga actual igual para buscar por el historial
	if(!todos_tienen_misma_carga(listaFiltrada,lista_carga_de_N)){
	while(index_i_tabla_historial<tamanioLista && index_j_tabla_historial< tamanioLista){
		//envaluo por la carga actual
	n1 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_i_tabla_historial);
	n2 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_j_tabla_historial);


	if(	n1->cargaActual< n2->cargaActual){
		index_j_tabla_historial++;
		nodoelegido = n1;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_j_tabla_historial++;

		}

	}else{
		index_i_tabla_historial++;
		nodoelegido = n2;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_i_tabla_historial ++;

		}
	}
//	tamanioLista --;





	}
}else{
	//envaluo por el historial

	while(index_i_tabla_historial<tamanioLista && index_j_tabla_historial< tamanioLista){
		//envaluo por la carga actual
	n1 =tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_i_tabla_historial);
	n2 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_j_tabla_historial);

	if(	n1->cargaHistorica<= n2->cargaHistorica){
		index_j_tabla_historial++;

		nodoelegido = n1;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_j_tabla_historial++;

		}

	}else{
		index_i_tabla_historial++;
		nodoelegido = n2;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_i_tabla_historial ++;

		}
	}
	//tamanioLista --;





}

	if(tamanioLista ==1){
		nodoelegido = tomarcargaDeNodoSegunTablaHistorial(tabla_H_nodos,lista_carga_de_N,job,9999);

	}



		}


	if(nodoelegido != NULL){ // esta comparacion la pongo para ver si se encontro al nodo elegido y que este activo
	bool buscarNodo(void* data){
			historial_nodo* nod = (historial_nodo*) data;

			return nod->nodo == nodoelegido->nodo;

		}

		 nodo = (historial_nodo*) list_find(listaFiltrada,buscarNodo);
		 nodo->encargado = 1;
		 char* master_p_r =  string_itoa(job->master);
		 char* nodo_p_r = string_itoa(nodoelegido->nodo);
		    char* nombreNuevoArchivo= string_new();
		 	string_append(&nombreNuevoArchivo,"ReduccionGlobalMaster");
		 	string_append(&nombreNuevoArchivo,master_p_r);
		 	string_append(&nombreNuevoArchivo,"Nodo");
		 	string_append(&nombreNuevoArchivo,nodo_p_r);
		 	string_append(&nombreNuevoArchivo,".txt");


		 //buscamos si ya se habia registrado anteriormente la redu global
	 	bool buscarElQueTieneElReduGlobal(void* data){
			estado_de_un_job* j1 = (estado_de_un_job*) data;
			char** nodo1 =string_split(j1->nodo," ");
			if(strcmp(j1->etapa,"REDUCCION GLOBAL") == 0 && j1->id_master ==job->master && atoi(nodo1[1]) == nodo->nodo){
				free(nodo1[1]);
				free(nodo1[0]);
				free(nodo1);
			return true;
			}else{
			free(nodo1[1]);
			free(nodo1[0]);
			free(nodo1);
		    return	false;
		}


		 					}


		 pthread_mutex_lock(&mutex_tabla_de_estados);
		 estado_de_un_job* nodo_encargado=  list_find(tabla_de_estados,buscarElQueTieneElReduGlobal);
		 pthread_mutex_unlock(&mutex_tabla_de_estados);


		 //si no esta registrado como redu global que lo agregue sino no que no ponga
		 	if(nodo_encargado== NULL){
			actualizarTablaDeEstados("AGREGAR JOB","REDUCCION GLOBAL",job->master,job->sock_master,nodoelegido->nodo,"N",nodo->ip,nodo->puerto,NULL,NULL,nombreNuevoArchivo,0,NULL);
			actualizarTablaDeEstados("AGREGAR JOB","ALMACENAMIENTO FINAL",job->master,job->sock_master,nodoelegido->nodo,"N",nodo->ip,nodo->puerto,NULL,NULL,nombreNuevoArchivo,0,NULL);

			bool obtenerNodo(void*data){
			carga_nodo * nodo = (carga_nodo *) data;
			return nodo->nodo ==  nodoelegido->nodo;

			}
			pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			carga_nodo *  carga_de_nodo_actual = (carga_nodo * )list_find(lista_carga_de_N,obtenerNodo);
			pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
			carga_de_nodo_actual->cargaActual++;

			}

		free(master_p_r);
		free(nodo_p_r);
		free(nombreNuevoArchivo);









	log_trace(yama_log,"el nodo encargado para la Reduccion global es el: NODO %d",nodo->nodo);
	}else{
		* error = 1;
				    t_mensaje_HEADER headermaster;
					headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
					estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",job->master,-1,-1,"N");
					if(nodo_elegido == NULL){
						   		if(!enviar_mensaje_header(&headermaster,job->sock_master)){
						   			log_error(yama_log,"ERROR AL QUERES ENVIAR MENSAJE A MASTER:%d",job->master);
						   		}
					log_error(yama_log,"ERROR NO SE ENCUENTRA UN NODO PARA LA REDUCCION GLOBAL EN MASTER: %d SE ABORTA EL JOB",
							job->master);

		actualizarTablaDeEstados("AGREGAR JOB","JOB ABORTADO",job->master,job->sock_master,"-1","N",NULL,NULL,NULL,NULL,"NO EXISTE",0,NULL);
					}

	}
		}else{
			* error = 1;
		    t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
			estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",job->master,-1,-1,"N");
								if(nodo_elegido == NULL){
				   		if(!enviar_mensaje_header(&headermaster,job->sock_master)){
				   			log_error(yama_log,"ERROR AL QUERES ENVIAR MENSAJE A MASTER: %d",job->master);
				   		}
			log_error(yama_log,"ERROR NO SE ENCUENTRA EL NODO PARA REDUCCION GLOBAL EN MASTER: %d SE ABORTA EL JOB",
					job->master);
			actualizarTablaDeEstados("AGREGAR JOB","JOB ABORTADO",job->master,job->sock_master,"-1","N",NULL,NULL,NULL,NULL,"NO EXISTE",0,NULL);
								}

		}

	//list_destroy(listaFiltrada);
	//list_destroy_and_destroy_elements(listaFiltrada,(void*)eliminarListaHistorial);
	//free(nodoelegido);
		list_clean(listaFiltrada);
		list_destroy(listaFiltrada);
		list_clean(lista_temporal);
		list_destroy(lista_temporal);
}





void registrarReduccionGlobalEnTabla_replanificacion(t_list* tabla_H_nodos,t_list* lista_carga_de_N,t_list* lista_J_nuevos,tratar_job* job,int* error){

	int index_i_tabla_historial = 0;
	int index_j_tabla_historial = 1;
	historial_nodo* nodo;
	carga_nodo * n1;
	carga_nodo * n2;
	carga_nodo * nodoelegido;// = malloc(sizeof(carga_nodo));
	t_list* lista_temporal;
	// aca puede venir tanto de la lista de jobs nuevos como de la lista de replanificacion de jobs
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	job = (tratar_job*) list_get(lista_J_nuevos,list_size(lista_J_nuevos)-1);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);
	t_list* listaFiltrada = list_create();
	bool filtrarPorMaster(void* data){
		historial_nodo* nodo = (historial_nodo*) data;

		return nodo->master == job->master && nodo->nodo != job->nodo; // && nodo->enviar_a_master == 1;

	}

	//primer busco todos los nodo del master a filtrar y me fijo que el enviar a master este en 1 en la T.historial
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	lista_temporal = list_filter(tabla_H_nodos,filtrarPorMaster);
	list_add_all(listaFiltrada,lista_temporal);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	int tamanioLista = list_size(listaFiltrada);
	historial_nodo* nodo_for;
	int i = 0;
	int indice;
	bool seBorroNodo= false;

	while(i< tamanioLista){
		if(seBorroNodo){
//			 indice = i;
//			indice = indice -1;
			 nodo_for = list_get(listaFiltrada,i);
			seBorroNodo = false;
			tamanioLista = list_size(listaFiltrada);
		}else{
			 nodo_for = list_get(listaFiltrada,i);
			 //indice = i;
		}


		bool resultado;

			bool encontrar_nodo(void* data){
				carga_nodo * carga_de_nodo = (carga_nodo *) data;
				return carga_de_nodo->nodo == nodo_for->nodo && carga_de_nodo->esta_activo == 1;

			}
			pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			resultado = list_any_satisfy(lista_carga_de_nodos,encontrar_nodo);
			pthread_mutex_unlock(&mutex_lista_carga_de_nodos);

			if(resultado == false){
			list_remove(listaFiltrada,i);
			tamanioLista = list_size(listaFiltrada);
			seBorroNodo = true;
			}else{
				i++;
			}

	}


	tamanioLista = list_size(listaFiltrada);

		if(list_size(listaFiltrada) != 0){
		//me fijo si todos tienen la carga actual igual para buscar por el historial
	if(!todos_tienen_misma_carga(listaFiltrada,lista_carga_de_N)){
	while(index_i_tabla_historial<tamanioLista && index_j_tabla_historial< tamanioLista){
		//envaluo por la carga actual
	n1 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_i_tabla_historial);
	n2 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_j_tabla_historial);


	if(	n1->cargaActual< n2->cargaActual){
		index_j_tabla_historial++;
		nodoelegido = n1;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_j_tabla_historial++;

		}

	}else{
		index_i_tabla_historial++;
		nodoelegido = n2;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_i_tabla_historial ++;

		}
	}
//	tamanioLista --;





	}
}else{
	//envaluo por el historial

	while(index_i_tabla_historial<tamanioLista && index_j_tabla_historial< tamanioLista){
		//envaluo por la carga actual
	n1 =tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_i_tabla_historial);
	n2 = tomarcargaDeNodoSegunTablaHistorial(listaFiltrada,lista_carga_de_N,job,index_j_tabla_historial);

	if(	n1->cargaHistorica<= n2->cargaHistorica){
		index_j_tabla_historial++;

		nodoelegido = n1;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_j_tabla_historial++;

		}

	}else{
		index_i_tabla_historial++;
		nodoelegido = n2;
		if(index_i_tabla_historial == index_j_tabla_historial){
			index_i_tabla_historial ++;

		}
	}
	//tamanioLista --;





}

	if(tamanioLista ==1){
		nodoelegido = tomarcargaDeNodoSegunTablaHistorial(tabla_H_nodos,lista_carga_de_N,job,9999);

	}



		}


	if(nodoelegido != NULL){ // esta comparacion la pongo para ver si se encontro al nodo elegido y que este activo
	bool buscarNodo(void* data){
			historial_nodo* nod = (historial_nodo*) data;

			return nod->nodo == nodoelegido->nodo;

		}

		 nodo = (historial_nodo*) list_find(listaFiltrada,buscarNodo);
		 nodo->encargado = 1;
		 char* master_p_r =  string_itoa(job->master);
		 char* nodo_p_r = string_itoa(nodoelegido->nodo);
		    char* nombreNuevoArchivo= string_new();
		 	string_append(&nombreNuevoArchivo,"ReduccionGlobalMaster");
		 	string_append(&nombreNuevoArchivo,master_p_r);
		 	string_append(&nombreNuevoArchivo,"Nodo");
		 	string_append(&nombreNuevoArchivo,nodo_p_r);
		 	string_append(&nombreNuevoArchivo,".txt");


		 //buscamos si ya se habia registrado anteriormente la redu global
	 	bool buscarElQueTieneElReduGlobal(void* data){
			estado_de_un_job* j1 = (estado_de_un_job*) data;
			char** nodo1 =string_split(j1->nodo," ");
			if(strcmp(j1->etapa,"REDUCCION GLOBAL") == 0 && j1->id_master ==job->master && strcmp(j1->estado,"ABORTIVO") != 0){//atoi(nodo1[1]) == nodo->nodo){
				free(nodo1[1]);
				free(nodo1[0]);
				free(nodo1);
			return true;
			}else{
			free(nodo1[1]);
			free(nodo1[0]);
			free(nodo1);
		    return	false;
		}


		 					}


		 pthread_mutex_lock(&mutex_tabla_de_estados);
		 estado_de_un_job* nodo_encargado=  list_find(tabla_de_estados,buscarElQueTieneElReduGlobal);
		 pthread_mutex_unlock(&mutex_tabla_de_estados);


		 //si no esta registrado como redu global que lo agregue sino no que no ponga
		 	if(nodo_encargado== NULL){
			actualizarTablaDeEstados("AGREGAR JOB","REDUCCION GLOBAL",job->master,job->sock_master,nodoelegido->nodo,"N",nodo->ip,nodo->puerto,NULL,NULL,nombreNuevoArchivo,0,NULL);
			actualizarTablaDeEstados("AGREGAR JOB","ALMACENAMIENTO FINAL",job->master,job->sock_master,nodoelegido->nodo,"N",nodo->ip,nodo->puerto,NULL,NULL,nombreNuevoArchivo,0,NULL);

			bool obtenerNodo(void*data){
			carga_nodo * nodo = (carga_nodo *) data;
			return nodo->nodo ==  nodoelegido->nodo;

			}
			pthread_mutex_lock(&mutex_lista_carga_de_nodos);
			carga_nodo *  carga_de_nodo_actual = (carga_nodo * )list_find(lista_carga_de_N,obtenerNodo);
			pthread_mutex_unlock(&mutex_lista_carga_de_nodos);
			carga_de_nodo_actual->cargaActual=carga_de_nodo_actual->cargaActual+1;

			log_trace(yama_log,"el nodo encargado para la Reduccion global es el: NODO %d",nodo->nodo);
			}

		free(master_p_r);
		free(nodo_p_r);
		free(nombreNuevoArchivo);










	}else{
		* error = 1;
				    t_mensaje_HEADER headermaster;
					headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
					estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",job->master,-1,-1,"N");
					if(nodo_elegido == NULL){
						   		if(!enviar_mensaje_header(&headermaster,job->sock_master)){
						   			log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");
						   		}
					log_trace(yama_log,"ERROR no se encuentra un nodo para la REDUCCION GLOBAL para master: %d SE ABORTA EL JOB",
							job->master);

		actualizarTablaDeEstados("AGREGAR JOB","JOB ABORTADO",job->master,job->sock_master,"-1","N",NULL,NULL,NULL,NULL,"NO EXISTE",0,NULL);
					}

	}
		}else{
			* error = 1;
		    t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
			estado_de_un_job* nodo_elegido = tomarElemento("JOB ABORTADO",job->master,-1,-1,"N");
								if(nodo_elegido == NULL){
				   		if(!enviar_mensaje_header(&headermaster,job->sock_master)){
				   			log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");
				   		}
			log_trace(yama_log,"ERROR no se encuentra un nodo para la REDUCCION GLOBAL para master: %d SE ABORTA EL JOB",
					job->master);
			actualizarTablaDeEstados("AGREGAR JOB","JOB ABORTADO",job->master,job->sock_master,"-1","N",NULL,NULL,NULL,NULL,"NO EXISTE",0,NULL);
								}

		}

	//list_destroy(listaFiltrada);
	//list_destroy_and_destroy_elements(listaFiltrada,(void*)eliminarListaHistorial);
	//free(nodoelegido);
		list_clean(listaFiltrada);
		list_destroy(listaFiltrada);
		list_clean(lista_temporal);
		list_destroy(lista_temporal);
}


void enviarIdalMaster(t_list* lista_H_nodos){


	historial_nodo * nodo_a_enviar = nodoListoParaEjecutar(lista_H_nodos);

	//envio header
	t_mensaje_HEADER headermaster;
	 headermaster.codigoMensaje = YAMA_ID_MASTER;
	 headermaster.tamanio = nodo_a_enviar->master;
			if(!enviar_mensaje_header(&headermaster,nodo_a_enviar->sock_master)){
				log_trace(yama_log,"Error al querer enviar la TRANSFORMACION al nodo");
			}
			log_trace(yama_log,"El ID que se le asigna al Job es el: %d",nodo_a_enviar->master);

//	//envio id
//
//	resultadoOperacion->id_master = nodo_a_enviar->master;
//	resultadoOperacion->nombreArchivoLargo = 0;
//	buffer = serializarResultado(resultadoOperacion,&largo);
//	sendall(nodo_a_enviar->master,buffer,largo);


}

void posicionarPunteroWclock(t_list* tabla_historial_nodos,tratar_job* job_creado){
	//tratar_job* job_creado;
	t_list* lista_resultante_del_job;
	historial_nodo * nodoConMayorDispo;
	//obtenemos el job nuevo del otro hilo, siempre nos fijamos en el ultimo de la lista
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	int tamanio_Lista_jobs_nuevos = list_size(lista_jobs_nuevos);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);
//
//	pthread_mutex_lock(&mutex_lista_jobs_nuevos);
//	job_creado = (tratar_job*) list_get(lista_j_nuevos,tamanio_Lista_jobs_nuevos-1);
//	pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

	bool obtenerPorJob(void* data){
		historial_nodo* h1 = (historial_nodo*) data;
		return h1->master == job_creado->master;

	}

	//obtener lista de solo ese job
	pthread_mutex_lock(&mutex_tabla_historial_nodos);
	lista_resultante_del_job = list_filter(tabla_historial_nodos,obtenerPorJob);
	pthread_mutex_unlock(&mutex_tabla_historial_nodos);
	//ordenamos y obtener el nodo de ese job que tenga mayor disponibilidad y le ponemos el puntero


	bool ordenarSegunDispo(historial_nodo *n1, historial_nodo *n2) {
		return n1->disponibilidad >= n2->disponibilidad;
		}

	list_sort(lista_resultante_del_job,(void*)ordenarSegunDispo);

	nodoConMayorDispo = (historial_nodo * ) list_get(lista_resultante_del_job,0);

	nodoConMayorDispo->punteroClock = 1;

list_clean(lista_resultante_del_job);
list_destroy(lista_resultante_del_job);


}


int hacerPedidoAlFS(char *nombre_archivo,t_list* lista_de_n_con_bloques){
	t_mensaje_HEADER headerFylesystem;




	t_list* listaAux;
	char*buffer;
	headerFylesystem.codigoMensaje = YAMA_SOLICITUD_ARCHIVO;
	headerFylesystem.tamanio = string_length(nombre_archivo);
	if(!enviar_mensaje_header(&headerFylesystem,socket_FS)){
	log_trace(yama_log,"Error al querer enviar la el archivo al Fyle System");
	return EXIT_FAILURE;
	}else{
		//mando el nombre del archivo
		sendall(socket_FS,nombre_archivo,headerFylesystem.tamanio);
		//recibo la lista completa del fs
		if(!recibir_mensaje_header(&headerFylesystem,socket_FS)){
			log_trace(yama_log,"Error al recibir la el archivo al Fyle System");
			return EXIT_FAILURE;
		}

		if(headerFylesystem.tamanio != -1){
			buffer= malloc(headerFylesystem.tamanio);
			recvall(socket_FS,buffer,headerFylesystem.tamanio);

		//deserializo todocompleto
		listaAux = deserializarMsjYamaFs( buffer);
		//paso a la lista que manejo
		list_add_all(lista_de_n_con_bloques,listaAux);
		list_clean(listaAux);
		list_destroy(listaAux);
		free(buffer);
		return EXIT_SUCCESS;

		}else{
			return EXIT_FAILURE;
		}
	}



}

bool hayNodosActivosEnElSistema(){
	bool hayActivos (void* data){
		carga_nodo* n1 = (carga_nodo*) data;
		return n1->esta_activo == 1;
	}

	return list_any_satisfy(lista_carga_de_nodos,hayActivos);
}


void* ejecutar_algoritmos(){
	while(1){
		//poner sem_wait
		//comunicarme con FS para saber los nodos y bloques del mismo

		sem_wait(&sem_job_nuevo);
		int * error = malloc(sizeof(int));
		*error = 0; // error que sirve para la redu global en caso de que no haya nodo para asignar la misma
		//pthread_mutex_lock(&mutex_yama_cfg);
		tratar_job* job_creado;// = malloc(sizeof(tratar_job));
		pthread_mutex_lock(&mutex_lista_jobs_nuevos);
		job_creado = (tratar_job*) list_get(lista_jobs_nuevos,0);
		pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

		 //lista_de_nodos_con_bloques= list_create();

		if(!hacerPedidoAlFS(job_creado->nombre_archivo,lista_de_nodos_con_bloques)){

			log_trace(yama_log,"el archivo:%s es valido y se procede a analizalo",job_creado->nombre_archivo);




/*
			bloques_en_archivo* nodo_en_bloque = malloc(sizeof(bloques_en_archivo));
			nodo_en_bloque->bloques= list_create();
			bloques_en_archivo* nodo_en_bloque2 = malloc(sizeof(bloques_en_archivo));
			nodo_en_bloque2->bloques= list_create();

			bloque*unbloque = malloc(sizeof(bloque));
			unbloque->num_bloque_ficticio= 0;
			unbloque->num_bloque_real = 1;
			unbloque->bytes_ocupados = 11;

			bloque*bloque1 = malloc(sizeof(bloque));
			bloque1->num_bloque_ficticio= 1;
			bloque1->num_bloque_real = 2;
			bloque1->bytes_ocupados = 12;

			bloque*bloque2 = malloc(sizeof(bloque));
			bloque2->num_bloque_ficticio= 2;
			bloque2->num_bloque_real = 3;
			bloque2->bytes_ocupados = 13;

			bloque*bloque3 = malloc(sizeof(bloque));
			bloque3->num_bloque_ficticio= 3;
			bloque3->num_bloque_real = 4;
			bloque3->bytes_ocupados = 14;

			//nodo 2
			list_add(nodo_en_bloque->bloques,(void*)unbloque);
			//list_add(nodo_en_bloque->bloques,(void*)bloque1);
			list_add(nodo_en_bloque->bloques,(void*)bloque2);

			nodo_en_bloque->nombre_archivo = string_new();
			string_append(&nodo_en_bloque->nombre_archivo,"/archivoPrueba.txt");
			nodo_en_bloque->largo_nombre_Archivo = string_length(nodo_en_bloque->nombre_archivo);
			nodo_en_bloque->ip= string_new();
			string_append(&nodo_en_bloque->ip,"127.0.0.1");
			nodo_en_bloque->largo_ip = string_length(nodo_en_bloque->ip);
			nodo_en_bloque->puerto = 8888;
			nodo_en_bloque->nodo = 1;
			list_add(lista_de_nodos_con_bloques,(void*)nodo_en_bloque);
			//nodo 1
			list_add(nodo_en_bloque2->bloques,(void*)bloque2);
			//list_add(nodo_en_bloque2->bloques,(void*)bloque3);
			list_add(nodo_en_bloque2->bloques,(void*)unbloque);


			nodo_en_bloque2->nombre_archivo = string_new();
			string_append(&nodo_en_bloque2->nombre_archivo,"/archivoPrueba.txt");
			nodo_en_bloque2->largo_nombre_Archivo = string_length(nodo_en_bloque2->nombre_archivo);
			nodo_en_bloque2->ip= string_new();
			string_append(&nodo_en_bloque2->ip,"127.0.0.1");
			nodo_en_bloque2->largo_ip = string_length(nodo_en_bloque2->ip);
			nodo_en_bloque2->puerto = 1234;
			nodo_en_bloque2->nodo = 2;


			list_add(lista_de_nodos_con_bloques,(void*)nodo_en_bloque2);*/

//
//			 bloques_en_archivo* nodo_en_bloque = malloc(sizeof(bloques_en_archivo));
//			nodo_en_bloque->bloques= list_create();
//			bloques_en_archivo* nodo_en_bloque2 = malloc(sizeof(bloques_en_archivo));
//			nodo_en_bloque2->bloques= list_create();
//
//						bloques_en_archivo* nodo_en_bloque3 = malloc(sizeof(bloques_en_archivo));
//						nodo_en_bloque3->bloques= list_create();
//
//						bloque*unbloque1 = malloc(sizeof(bloque));
//						unbloque1->num_bloque_ficticio= 0;
//						unbloque1->num_bloque_real = 1;
//						unbloque1->bytes_ocupados = 11;
//
//						bloque*bloque2 = malloc(sizeof(bloque));
//						bloque2->num_bloque_ficticio= 1;
//						bloque2->num_bloque_real = 2;
//						bloque2->bytes_ocupados = 12;
//
//						bloque* bloque3 = malloc(sizeof(bloque));
//						bloque3->num_bloque_ficticio= 2;
//						bloque3->num_bloque_real = 3;
//						bloque3->bytes_ocupados = 13;
//
//						bloque*bloque4 = malloc(sizeof(bloque));
//						bloque4->num_bloque_ficticio= 3;
//						bloque4->num_bloque_real = 4;
//						bloque4->bytes_ocupados = 14;
//
//						bloque*bloque5 = malloc(sizeof(bloque));
//						bloque5->num_bloque_ficticio= 4;
//						bloque5->num_bloque_real = 5;
//						bloque5->bytes_ocupados = 14;
//
//						bloque*bloque6 = malloc(sizeof(bloque));
//						bloque6->num_bloque_ficticio= 5;
//						bloque6->num_bloque_real = 6;
//						bloque6->bytes_ocupados = 14;
//						//nodo 2
//						list_add(nodo_en_bloque->bloques,(void*)unbloque1);
//						list_add(nodo_en_bloque->bloques,(void*)bloque2);
//						list_add(nodo_en_bloque->bloques,(void*)bloque3);
//						list_add(nodo_en_bloque->bloques,(void*)bloque4);
//						list_add(nodo_en_bloque->bloques,(void*)bloque5);
//						list_add(nodo_en_bloque->bloques,(void*)bloque6);
//
//						nodo_en_bloque->nombre_archivo = string_new();
//						string_append(&nodo_en_bloque->nombre_archivo,"/archivoPrueba.txt");
//						nodo_en_bloque->largo_nombre_Archivo = string_length(nodo_en_bloque->nombre_archivo);
//						nodo_en_bloque->ip= string_new();
//						string_append(&nodo_en_bloque->ip,"192.168.0.9");
//						nodo_en_bloque->largo_ip = string_length(nodo_en_bloque->ip);
//						nodo_en_bloque->puerto = 8888;
//						nodo_en_bloque->nodo = 1;
//						list_add(lista_de_nodos_con_bloques,(void*)nodo_en_bloque);
//						//nodo 1
//						list_add(nodo_en_bloque2->bloques,(void*)bloque4);
//						list_add(nodo_en_bloque2->bloques,(void*)bloque5);
//						list_add(nodo_en_bloque2->bloques,(void*)bloque6);
//						list_add(nodo_en_bloque2->bloques,(void*)bloque3);
//						list_add(nodo_en_bloque2->bloques,(void*)bloque2);
//						list_add(nodo_en_bloque2->bloques,(void*)unbloque1);
//					//	list_add(nodo_en_bloque2->bloques,(void*)bloque3);
//
//
//						nodo_en_bloque2->nombre_archivo = string_new();
//						string_append(&nodo_en_bloque2->nombre_archivo,"/archivoPrueba.txt");
//						nodo_en_bloque2->largo_nombre_Archivo = string_length(nodo_en_bloque2->nombre_archivo);
//						nodo_en_bloque2->ip= string_new();
//						string_append(&nodo_en_bloque2->ip,"192.168.0.11");
//						nodo_en_bloque2->largo_ip = string_length(nodo_en_bloque2->ip);
//						nodo_en_bloque2->puerto = 8888;
//						nodo_en_bloque2->nodo = 2;
//
//
//						list_add(lista_de_nodos_con_bloques,(void*)nodo_en_bloque2);
//
//						//nodo 3
//						list_add(nodo_en_bloque3->bloques,(void*)bloque4);
//						list_add(nodo_en_bloque3->bloques,(void*)bloque2);
//						list_add(nodo_en_bloque3->bloques,(void*)unbloque1);
//
//						nodo_en_bloque3->nombre_archivo = string_new();
//						string_append(&nodo_en_bloque3->nombre_archivo,"/archivoPrueba.txt");
//						nodo_en_bloque3->largo_nombre_Archivo = string_length(nodo_en_bloque3->nombre_archivo);
//						nodo_en_bloque3->ip= string_new();
//						string_append(&nodo_en_bloque3->ip,"192.168.0.17");
//						nodo_en_bloque3->largo_ip = string_length(nodo_en_bloque3->ip);
//						nodo_en_bloque3->puerto = 8888;
//						nodo_en_bloque3->nodo = 3;
//
//
//						list_add(lista_de_nodos_con_bloques,(void*)nodo_en_bloque3);


	if(strcmp(yama_cfg->algoritmo,"Clock") == 0){
		pthread_mutex_unlock(&mutex_yama_cfg);
		//hacemos un carga de prueba para probar yama





		log_trace(yama_log,"COMIENZO DE LA PRE PRANIFICACON");
		log_trace(yama_log,"se ejecuta el algoritmo CLOCK");

		obtenerDisponibilidadworkerClock( lista_de_nodos_con_bloques,tabla_historial_nodos,lista_carga_de_nodos,lista_jobs_nuevos,job_creado);
		if(hayNodosActivosEnElSistema()){
		posicionarPuntero(tabla_historial_nodos,job_creado);

		ejecutarAlgoritmo(lista_de_nodos_con_bloques,tabla_historial_nodos,lista_carga_de_nodos,job_creado);

		registrarReduccionGlobalEnTabla(tabla_historial_nodos,lista_carga_de_nodos,lista_jobs_nuevos,job_creado,error);

		agregarATablaBloquesPorArchivo(lista_de_nodos_con_bloques,bloques_x_archivo,lista_jobs_nuevos);

		agregarATablaDeEstados(tabla_historial_nodos);

		enviarIdalMaster(tabla_historial_nodos);

		enviarTransformaciones(tabla_historial_nodos);
		}else{
			  t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;


			if(!enviar_mensaje_header(&headermaster,job_creado->sock_master)){
			log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");
			}
			log_error(yama_log,"NO SE COMIENZA LA PRE-PLANIFICACION,NO SE ENCUENTRAN NODOS ACTIVOS EN EL SISTEMA PARA ARCHIVO:%s EN MASTER: %d SE ABORTA EL JOB",
					job_creado->nombre_archivo,job_creado->master);
		}


	}else{
		pthread_mutex_unlock(&mutex_yama_cfg);
		log_trace(yama_log,"COMIENZO DE LA PRE PRANIFICACON");
		log_trace(yama_log,"se ejecuta el algoritmo W-CLOCK");

		obtenerDisponibilidadworkerWClock( lista_de_nodos_con_bloques,tabla_historial_nodos,lista_carga_de_nodos,lista_jobs_nuevos,job_creado);

		if(hayNodosActivosEnElSistema()){
		posicionarPunteroWclock(tabla_historial_nodos,job_creado);

		ejecutarAlgoritmo(lista_de_nodos_con_bloques,tabla_historial_nodos,lista_carga_de_nodos,job_creado);

		registrarReduccionGlobalEnTabla(tabla_historial_nodos,lista_carga_de_nodos,lista_jobs_nuevos,job_creado,error);

		agregarATablaBloquesPorArchivo(lista_de_nodos_con_bloques,bloques_x_archivo,lista_jobs_nuevos);

		agregarATablaDeEstados(tabla_historial_nodos);

		enviarIdalMaster(tabla_historial_nodos);

		enviarTransformaciones(tabla_historial_nodos);
		}else{
			  t_mensaje_HEADER headermaster;
			headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;


			if(!enviar_mensaje_header(&headermaster,job_creado->sock_master)){
			log_error(yama_log,"ERROR AL QUERER ENVIAR MENSAJE A MASTER:%d",job_creado->master);
			}
			log_error(yama_log," NO SE COMIENZA LA PRE-PLANIFICACION,NO SE ENCUENTRAN NODOS ACTIVOS EN EL SISTEMA PARA ARCHIVO:%s EN MASTER: %d SE ABORTA EL JOB",
					job_creado->nombre_archivo,job_creado->master);





	}


	}

	}else{

				t_mensaje_HEADER headermaster;
				headermaster.codigoMensaje = YAMA_FINALIZAR_JOB;
				if(!enviar_mensaje_header(&headermaster,job_creado->sock_master)){
				log_trace(yama_log,"Error al querer enviar que no se puede ejecutar la reduccion local");

				}

				log_error(yama_log,"el archivo: %s solicitado no es valido",job_creado->nombre_archivo);


	}



		free(error);

		borrarListaPreplanificacion(lista_de_nodos_con_bloques);

	}

return NULL;
}
void borrarListaREplanificacion(){

	void destruir_job_nuevo (void*data){
		tratar_job* j1 = (tratar_job*) j1;
		free(j1->nombre_archivo);
		free(j1);
	}


		pthread_mutex_lock(&mutex_lista_jobs_a_replanificar);
		list_destroy_and_destroy_elements(lista_jobs_a_replanificar,destruir_job_nuevo);
		pthread_mutex_unlock(&mutex_lista_jobs_a_replanificar);

}
static	void destruir_job_nuevo (tratar_job* j1 ){
		free(j1->nombre_archivo);
		free(j1);
	}


static void borrarBloques1(void*data){
	bloque* b1 = (bloque*) data;
	free(b1);

}

static void eliminarListaBloquePorArchivo (void*data){
bloques_en_archivo* bloque_en_archivo = (bloques_en_archivo*) data;
free(bloque_en_archivo->nombre_archivo);
free(bloque_en_archivo->ip);
list_destroy_and_destroy_elements(bloque_en_archivo->bloques,(void*)borrarBloques1);
free(bloque_en_archivo);

}



void borrarListaPreplanificacion(t_list*lista_de_n_con_bloques){




		pthread_mutex_lock(&mutex_lista_jobs_nuevos);
		//list_destroy_and_destroy_elements(lista_jobs_nuevos,(void*)destruir_job_nuevo);
		list_remove_and_destroy_element(lista_jobs_nuevos,0,(void*)free);
		pthread_mutex_unlock(&mutex_lista_jobs_nuevos);

		list_clean(lista_de_nodos_con_bloques);
		//list_destroy_and_destroy_elements(lista_de_n_con_bloques,(void*)eliminarListaBloquePorArchivo);


}
int crear_hilo_replanificacion(t_log* logger){
	pthread_t thread_multiplexing;
	pthread_attr_t attr;
	void* res;
//	pthread_attr_init(&attr);
//	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

	if (pthread_create(&thread_multiplexing, NULL, &ejecutar_replanificacion, NULL) < 0) {
			log_error(logger,
				"funciones_replanificacion_yama->crear_hilo_replanificador -> error al crear el hilo para replanificar");

		return 1;
	}
	pthread_join(thread_multiplexing, NULL);
//	if(!pthread_attr_destroy(&attr)){
//
//		log_trace(logger,
//				"funciones_replanificacion_yama->crear_hilo_replanificador -> hilo para replanificar creado");
//
//	}else{
//
//		log_error(logger,
//				"funciones_replanificacion_yama->crear_hilo_replanificador -> fallo el pthread destroy");
//
//		return 1;
//	}

//	if(!pthread_join(thread_multiplexing, &res)){
//			log_trace(logger,
//					"funciones_replanificacion_yama->crear_hilo_replanificador -> hilo joineado");
//		}else{
//			log_error(logger,
//					"funciones_replanificacion_yama->crear_hilo_replanificador -> fallo el pthread join");
//			return 1;
//		}
//		free(res);
return 0;

}

int crear_hilo_planificador(t_log *logger){
	pthread_t thread_multiplexing;
	pthread_attr_t attr;
	void* res;
//	pthread_attr_init(&attr);
//	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_create(&thread_multiplexing, NULL, &ejecutar_algoritmos, NULL) < 0) {

			log_error(logger,
					"funciones_planificacion_yama->crear_hilo_planificador -> error al crear el hilo para planificar");

			return 1;
		}
//	if(!pthread_attr_destroy(&attr)){
//
//		log_trace(logger,
//				"funciones_planificacion_yama->crear_hilo_planificador -> hilo para planificar creado");
//
//	}else{
//
//		log_error(logger,
//				"funciones_planificacion_yama->crear_hilo_planificador -> fallo el pthread destroy");
//
//		return 1;
//	}
	//pthread_join(thread_multiplexing, NULL);
//		if(!pthread_join(thread_multiplexing, &res)){
//			log_trace(logger,
//					"funciones_planificacion_yama->crear_hilo_planificador -> hilo joineado");
//		}else{
//			log_error(logger,
//					"funciones_planificacion_yama->crear_hilo_planificador -> fallo el pthread join");
//			return 1;
//		}
//		free(res);
return 0;
}






//void actualizarTablaDeHistorialDeNodos(int idMaster, int nodo,int cargaActual,int historial){
//		historial_nodo * unNodo;
//
//	bool busqueda_cambio_historial(historial_nodo *nodo){
//
//			if( nodo->master == idMaster  && nodo->nodo == nodo )return true;
//			return false;
//		}
//
//		unNodo= list_find(tabla_historial_nodos,(void*)busqueda_cambio_historial);
//		//if(cargaActual!= NULL && historial!= NULL){
//		unNodo->cargaActual += cargaActual;
//		unNodo->cargaHistorica += historial;
//		//} else{
//			//unNodo->cargaActual = 0;
//			//unNodo->cargaHistorica = 0;
//		//}
//
//
//}

