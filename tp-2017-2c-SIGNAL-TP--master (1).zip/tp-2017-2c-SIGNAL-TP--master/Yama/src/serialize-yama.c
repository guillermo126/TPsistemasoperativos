/*
 * serialize-yama.c
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */
#include <commons/collections/list.h>
#include "src/serialize-adm.h"
#include "serialize-yama.h"
#include "funcYamaMaster.h"

//

//DESSERIALIZACION YAMA/FS
t_list* deserializarMsjYamaFs(char* buffer){
	 int cantidad_de_nodos;
	 int payload = 0;

	 t_list* lista_de_n_en_archivo = list_create();

	 memcpy(&cantidad_de_nodos,buffer+payload,sizeof(typeof(cantidad_de_nodos)));
	 payload +=sizeof(typeof(cantidad_de_nodos));
	 t_list* cantidad_de_bloques_en_nodos;
	 int i;
	 if(cantidad_de_nodos > 0){

	 cantidad_de_bloques_en_nodos = list_create();

	 for (i = 0; i < cantidad_de_nodos; i++) {
	 int auxiliar;
	 memcpy(&auxiliar, buffer + payload, sizeof(int));
	 payload += sizeof(int);
	 list_add(cantidad_de_bloques_en_nodos, (void*) auxiliar);

	}

	 int w;
	 int j = 0;
	 for (w = 0; w < cantidad_de_nodos ; w++) {
		 int BloquesEnNodo = (int) list_get(cantidad_de_bloques_en_nodos, j);
		 bloques_en_archivo* nodoAagregar = malloc(sizeof(bloques_en_archivo));
		 //LARGO IP CON IP
		 memcpy(&(nodoAagregar->largo_ip),buffer+payload,sizeof(typeof(nodoAagregar->largo_ip)));
		 payload +=sizeof(typeof(nodoAagregar->largo_ip));
		 if(nodoAagregar->largo_ip > 0){
			 nodoAagregar->ip = malloc(nodoAagregar->largo_ip + 1);
			 memcpy(nodoAagregar->ip,buffer +payload,nodoAagregar->largo_ip);
			 nodoAagregar->ip[nodoAagregar->largo_ip] = '\0';
			 payload +=nodoAagregar->largo_ip;


		 }
		 //LARGO NOMBRE ARCHIVO CON NOMBRE ARHIVO
		 memcpy(&(nodoAagregar->largo_nombre_Archivo),buffer+payload,sizeof(typeof(nodoAagregar->largo_nombre_Archivo)));
		 payload += sizeof(typeof(nodoAagregar->largo_nombre_Archivo));
		 if(nodoAagregar->largo_nombre_Archivo > 0){
			 nodoAagregar->nombre_archivo = malloc(nodoAagregar->largo_nombre_Archivo +1);
			 memcpy(nodoAagregar->nombre_archivo,buffer+payload,nodoAagregar->largo_nombre_Archivo);
			 nodoAagregar->nombre_archivo[nodoAagregar->largo_nombre_Archivo] = '\0';
			 payload += nodoAagregar->largo_nombre_Archivo;

		 }
		 //NUMERO NODO
		 memcpy(&(nodoAagregar->nodo),buffer+payload,sizeof(typeof(nodoAagregar->nodo)));
		 payload +=sizeof(typeof(nodoAagregar->nodo));
		 //PUERTO NODO
		 memcpy(&(nodoAagregar->puerto),buffer+payload,sizeof(typeof(nodoAagregar->puerto)));
		 payload +=sizeof(typeof(nodoAagregar->puerto));



		 nodoAagregar->bloques = list_create();
		 for(i = 0;i< BloquesEnNodo;i++){
			 bloque* bloqueNuevo = malloc(sizeof(bloque));
			 memcpy(&(bloqueNuevo->num_bloque_ficticio),buffer+payload,sizeof(typeof(bloqueNuevo->num_bloque_ficticio)));
			 payload += sizeof(typeof(bloqueNuevo->num_bloque_ficticio));
			 memcpy(&(bloqueNuevo->num_bloque_real),buffer+payload,sizeof(typeof(bloqueNuevo->num_bloque_real)));
			 payload += sizeof(typeof(bloqueNuevo->num_bloque_real));
			 memcpy(&(bloqueNuevo->bytes_ocupados),buffer+payload,sizeof(typeof(bloqueNuevo->bytes_ocupados)));
			 			 payload += sizeof(typeof(bloqueNuevo->bytes_ocupados));

			 list_add(nodoAagregar->bloques,(void*)bloqueNuevo);

		 }



		 list_add(lista_de_n_en_archivo,(void*)nodoAagregar);
		 j++;
	 }



	 }






	 return lista_de_n_en_archivo;



 }



 ///SERIALIZACION YAMA/FS
 t_list* generar_listaConCantidadDeBloquesPorNodo(t_list* lista_nodos_del_archivo) {
  	t_list* listaACrear = list_create();

  	void sacarCantidadDeBloquesDelNodo(void *data) {
  		bloques_en_archivo * nuevoNivel;
  		nuevoNivel = (bloques_en_archivo *) data;
  		int cantidadDEBoques;
  		cantidadDEBoques = list_size(nuevoNivel->bloques);
  		list_add(listaACrear, (void*) cantidadDEBoques);

  	}
  	list_iterate(lista_nodos_del_archivo, sacarCantidadDeBloquesDelNodo);

  	return listaACrear;
  }

 int obtenerTamanioLista( t_list* lista_de_nodo_del_archivo){

 	int tamanio = 0;
 	t_list* listaConCantidadDeBloquesPorNodo = generar_listaConCantidadDeBloquesPorNodo(lista_de_nodo_del_archivo);
 	tamanio += sizeof(int)+sizeof(int)*list_size(listaConCantidadDeBloquesPorNodo);
 	void TamanioNodosDeArchivo(void* data){
 		bloques_en_archivo* nodo = (bloques_en_archivo*) data;
 		tamanio += sizeof(typeof(nodo->largo_ip)) + nodo->largo_ip;
 		tamanio += sizeof(typeof(nodo->largo_nombre_Archivo)) + nodo->largo_nombre_Archivo;
 		tamanio += sizeof(typeof(nodo->nodo));
 		tamanio += sizeof(typeof(nodo->puerto));
 	void TamanioBoques(void* data){
 		bloque* unBloque = (bloque*) data;
 		tamanio += sizeof(typeof(unBloque->num_bloque_ficticio));
 		tamanio += sizeof(typeof(unBloque->num_bloque_real));
 		tamanio += sizeof(typeof(unBloque->bytes_ocupados));
 	}

 	list_iterate(nodo->bloques,TamanioBoques);
 	}

 	list_iterate(lista_de_nodo_del_archivo,TamanioNodosDeArchivo);
 	list_clean(listaConCantidadDeBloquesPorNodo);
 	list_destroy(listaConCantidadDeBloquesPorNodo);
 	return tamanio;

 }




 char* serializarMsjYamaFs(t_list* lista_de_nodo_del_archivo,int* largo){
 	int payload = 0;
 	*largo = 0;
 	int cant_nodo = list_size(lista_de_nodo_del_archivo);
 	// primero obtengo la cantidad de bloques que tiene cada nodo
 	t_list* listaConCantidadDeBloquesPorNodo = generar_listaConCantidadDeBloquesPorNodo(lista_de_nodo_del_archivo);
 	//aca obtengo la cantidad de nodos que tengo por archivo
 	int tamanio =  obtenerTamanioLista(lista_de_nodo_del_archivo);

 	char*buffer = malloc(tamanio);

 	memcpy(buffer+payload,&(cant_nodo),sizeof(typeof(cant_nodo)));
 	payload +=sizeof(typeof(cant_nodo));

 	void serializarListaCantBloqPorNodo(void *data) {
 				int auxiliar = (int) data;
 				memcpy(buffer + payload, &auxiliar, sizeof(int));
 				payload += sizeof(int);
 			}
 	list_iterate(listaConCantidadDeBloquesPorNodo, serializarListaCantBloqPorNodo);

 	void serializarNodosDeArchivo(void* data){
 		bloques_en_archivo * nodo = (bloques_en_archivo *) data;
 		//LARGO IP CON IP
 		memcpy(buffer + payload,&(nodo->largo_ip), sizeof(typeof(nodo->largo_ip)));
 		payload += sizeof(typeof(nodo->largo_ip));
 		if(nodo->largo_ip){
 			memcpy(buffer+payload,nodo->ip,nodo->largo_ip);
 			payload += nodo->largo_ip;

 		}
 		//LARGO NOMBRE ARCHIVO CON NOMBRE ARHIVO
 		memcpy(buffer +payload,&(nodo->largo_nombre_Archivo),sizeof(typeof(nodo->largo_nombre_Archivo)));
 		payload += sizeof(typeof(nodo->largo_nombre_Archivo));
 		if(nodo->largo_nombre_Archivo){
 			memcpy(buffer +payload,nodo->nombre_archivo,nodo->largo_nombre_Archivo);
 			payload += nodo->largo_nombre_Archivo;

 		}
 		//NUMERO NODO
 		memcpy(buffer +payload,&(nodo->nodo),sizeof(typeof(nodo->nodo)));
 		payload += sizeof(typeof(nodo->nodo));
 		//PUERTO NODO
 		memcpy(buffer +payload,&(nodo->puerto),sizeof(typeof(nodo->puerto)));
 		payload += sizeof(typeof(nodo->puerto));

 		void serializarBloques(void*data){
 			bloque* unBloque = (bloque*) data;
 			memcpy(buffer +payload, &(unBloque->num_bloque_ficticio),sizeof(typeof(unBloque->num_bloque_ficticio)));
 			payload += sizeof(typeof(unBloque->num_bloque_ficticio));
 			memcpy(buffer + payload, &(unBloque->num_bloque_real),sizeof(typeof(unBloque->num_bloque_real)));
 			payload += sizeof(typeof(unBloque->num_bloque_real));
 			memcpy(buffer + payload, &(unBloque->bytes_ocupados),sizeof(typeof(unBloque->bytes_ocupados)));
 			payload += sizeof(typeof(unBloque->bytes_ocupados));

 		}



 		list_iterate(nodo->bloques,serializarBloques);
 	}



 	list_iterate(lista_de_nodo_del_archivo,serializarNodosDeArchivo);
 	*largo = payload;
 	return buffer;

 }



 int tamanioListaArchivosRlocal(t_list* lista){

	 int tam = 0;

	 void tamanioElementos(void* data){
		 t_archivo_reducir_local* tamArchivo = (t_archivo_reducir_local*) data;
		 tam += sizeof(typeof(tamArchivo->nombreArchivoLargo))+
				 tamArchivo->nombreArchivoLargo;
	 }



	 list_iterate(lista,tamanioElementos);

	 return tam;

 }

 int tamanioPaqueteReduLocal(t_pNodo_reduccion_local* paquete){

	 int size = 0;
	 size += sizeof(typeof(paquete->nodo_id)) +sizeof(typeof(paquete->archivos_reduccion_cantidad))
			 +sizeof(typeof(paquete->destino_reduccion_largo)) +sizeof(typeof(paquete->nodo_ip_largo))
			 +sizeof(typeof(paquete->nodo_puerto_largo))+paquete->destino_reduccion_largo+paquete->nodo_ip_largo+
			 paquete->nodo_puerto_largo+tamanioListaArchivosRlocal(paquete->archivos_reduccion);
	 return size;

 }

 char* serializarMsjAlmacenamientoFinal(t_pNodo_almacenamiento_final* almacenamientoFinal,int *largo){
	 char*buffer;
	 int tamanio = 0;
	 int payload = 0;

	 tamanio += sizeof(typeof(almacenamientoFinal->nodo_id))+sizeof(typeof(almacenamientoFinal->archivo_final_largo))
			 + sizeof(typeof(almacenamientoFinal->nodo_ip_largo))+ sizeof(typeof(almacenamientoFinal->nodo_puerto_largo))
			 +almacenamientoFinal->archivo_final_largo+almacenamientoFinal->nodo_ip_largo+almacenamientoFinal->nodo_puerto_largo;

	 buffer = malloc(tamanio);
	 //SERIALIZO NODO_ID
	 memcpy(buffer+payload, &(almacenamientoFinal->nodo_id), sizeof(typeof(almacenamientoFinal->nodo_id)));
	 		payload += almacenamientoFinal->nodo_id;
	 		//SERIALIZO E NODO_IP_LARGO
	 memcpy(buffer+payload,&(almacenamientoFinal->nodo_ip_largo),sizeof(typeof(almacenamientoFinal->nodo_ip_largo)));
	 payload += sizeof(typeof(almacenamientoFinal->nodo_ip_largo));
	 if(almacenamientoFinal->nodo_ip_largo > 0){
		 memcpy(buffer+payload,almacenamientoFinal->nodo_ip,almacenamientoFinal->nodo_ip_largo);
		 payload+= almacenamientoFinal->nodo_ip_largo;

	 }
		//SERIALIZO EL NODO_PUERTO_LARGO
	 memcpy(buffer+payload,&(almacenamientoFinal->nodo_puerto_largo),sizeof(typeof(almacenamientoFinal->nodo_puerto_largo)));
	 payload+= sizeof(typeof(almacenamientoFinal->nodo_puerto_largo));
	 if(almacenamientoFinal->nodo_puerto_largo > 0){
		 //SERIALIZO EL NODO_PUERTO
		 memcpy(buffer+payload,almacenamientoFinal->nodo_puerto,almacenamientoFinal->nodo_puerto_largo);
		 payload += almacenamientoFinal->nodo_puerto_largo;
	 }


		//SERIALIZO ARCHIVO_FINAL_LARGO
	 memcpy(buffer+payload,&(almacenamientoFinal->archivo_final_largo),sizeof(typeof(almacenamientoFinal->archivo_final_largo)));
	 payload += sizeof(typeof(almacenamientoFinal->archivo_final_largo));
	 if(almacenamientoFinal->archivo_final_largo > 0){
			//SERIALIZO EL ARCHIVO_FINAL

		 memcpy(buffer+payload,almacenamientoFinal->archivo_final,almacenamientoFinal->archivo_final_largo);
		 payload += almacenamientoFinal->archivo_final_largo;

	 }

	 *largo = payload;
	 return buffer;

 }



int tamanioListaArchivosRglobal(t_list* lista){
	 int tam = 0;

		 void tamanioElementos(void* data){
			 t_archivo_reducir_global* tamArchivo = (t_archivo_reducir_global*) data;
			 tam += sizeof(typeof(tamArchivo->nombreArchivoLargo))+
					 tamArchivo->nombreArchivoLargo + sizeof(typeof(tamArchivo->nodo_ip_largo))+
					 tamArchivo->nodo_ip_largo+sizeof(typeof(tamArchivo->nodo_puerto_largo))+
					 tamArchivo->nodo_puerto_largo;
		 }



		 list_iterate(lista,tamanioElementos);

		 return tam;

 }

int tamanioPaqueteReduGlobal(t_pNodo_reduccion_global* paquete){

	 int size = 0;
	 size += sizeof(typeof(paquete->nodo_id)) +sizeof(typeof(paquete->archivos_reduccion_cantidad))
			 +sizeof(typeof(paquete->destino_reduccion_largo)) +sizeof(typeof(paquete->nodo_ip_largo))
			 +sizeof(typeof(paquete->nodo_puerto_largo))+paquete->destino_reduccion_largo+paquete->nodo_ip_largo+
			 paquete->nodo_puerto_largo+tamanioListaArchivosRglobal(paquete->archivos_reduccion);
	 return size;

}

 char* serializarMsjReduccionGlobal(t_pNodo_reduccion_global* nodo_para_master,int *largo){
		int payload = 0;
		char*buffer;

		int tamanio = tamanioPaqueteReduGlobal(nodo_para_master);
		buffer = malloc(tamanio);


		//SERIALIZO NODO_ID
		memcpy(buffer+payload,&(nodo_para_master->nodo_id),sizeof(typeof(nodo_para_master->nodo_id)));
		payload += sizeof(typeof(nodo_para_master->nodo_id));
		//SERIALIZO ARCHIVO_RESULTADO_LARGO
		memcpy(buffer+payload,&(nodo_para_master->destino_reduccion_largo),sizeof(typeof(nodo_para_master->destino_reduccion_largo)));
		payload += sizeof(typeof(nodo_para_master->destino_reduccion_largo));
		if(nodo_para_master->destino_reduccion_largo > 0){
			//SERIALIZO EL ARCHIVO_RESULTADO
			memcpy(buffer+payload,nodo_para_master->destino_reduccion,nodo_para_master->destino_reduccion_largo);
			payload+= nodo_para_master->destino_reduccion_largo;

		}
		//SERIALIZO EL NODO_IP_LARGO
		memcpy(buffer+payload,&(nodo_para_master->nodo_ip_largo),sizeof(typeof(nodo_para_master->nodo_ip_largo)));
		payload += sizeof(typeof(nodo_para_master->nodo_ip_largo));
		if(nodo_para_master->nodo_ip_largo > 0){
			//SERIALIZO EL nodo_IP
			memcpy(buffer+payload,nodo_para_master->nodo_ip,nodo_para_master->nodo_ip_largo);
			payload += nodo_para_master->nodo_ip_largo;


		}
		//SERIALIZO EL NODO_PUERTO_LARGO
		memcpy(buffer+payload,&(nodo_para_master->nodo_puerto_largo),sizeof(typeof(nodo_para_master->nodo_puerto_largo)));
		payload += sizeof(typeof(nodo_para_master->nodo_puerto_largo));
		//SERIALIZO EL NODO_PUERTO
		if(nodo_para_master->nodo_puerto_largo > 0){
			memcpy(buffer+payload,nodo_para_master->nodo_puerto,nodo_para_master->nodo_puerto_largo);
			payload += nodo_para_master->nodo_puerto_largo;

		}

		memcpy(buffer+payload,&(nodo_para_master->archivos_reduccion_cantidad),sizeof(typeof(nodo_para_master->archivos_reduccion_cantidad)));
		payload += sizeof(typeof(nodo_para_master->archivos_reduccion_cantidad));
		if(nodo_para_master->archivos_reduccion_cantidad > 0){

			void serializeElement(void*data){
				t_archivo_reducir_global* elemntArchivo = (t_archivo_reducir_global*) data;
				////SERIALIZO IP LARGO
				memcpy(buffer+payload,&(elemntArchivo->nodo_ip_largo),sizeof(typeof(elemntArchivo->nodo_ip_largo)));
				payload += sizeof(typeof(elemntArchivo->nodo_ip_largo));

				//SERIALIZO IP
				if(elemntArchivo->nodo_ip_largo > 0){

				memcpy(buffer+payload,elemntArchivo->nodo_ip,elemntArchivo->nodo_ip_largo);
				payload+=elemntArchivo->nodo_ip_largo;
				}


				////SERIALIZO PUERTO LARGO
				memcpy(buffer+payload,&(elemntArchivo->nodo_puerto_largo),sizeof(typeof(elemntArchivo->nodo_puerto_largo)));
				payload += sizeof(typeof(elemntArchivo->nodo_puerto_largo));
					//SERIALIZO PUERTO

				if(elemntArchivo->nodo_puerto_largo > 0){

				memcpy(buffer+payload,elemntArchivo->nodo_puerto,elemntArchivo->nodo_puerto_largo);
				payload+=elemntArchivo->nodo_puerto_largo;
				}

				////SERIALIZO NOMBRE DE ARCHIVO LARGO

				memcpy(buffer+payload,&(elemntArchivo->nombreArchivoLargo),sizeof(typeof(elemntArchivo->nombreArchivoLargo)));
				payload += sizeof(typeof(elemntArchivo->nombreArchivoLargo));
				if(elemntArchivo->nombreArchivoLargo > 0){
					//SERIALIZO NOMBRE DE ARCHIVO
					memcpy(buffer+payload,elemntArchivo->nombreArchivo,elemntArchivo->nombreArchivoLargo);
					payload+=elemntArchivo->nombreArchivoLargo;
				}

			}



			list_iterate(nodo_para_master->archivos_reduccion,serializeElement);

		}

		*largo = payload;





		return buffer;

  }

char *serializarMsjReduccionLocal(t_pNodo_reduccion_local*nodo_para_master,int* largo){

	int payload = 0;
	char*buffer;

	int tamanio = tamanioPaqueteReduLocal(nodo_para_master);
	buffer = malloc(tamanio);

	//SERIALIZO NODO_ID
	memcpy(buffer+payload,&(nodo_para_master->nodo_id),sizeof(typeof(nodo_para_master->nodo_id)));
	payload += sizeof(typeof(nodo_para_master->nodo_id));
	//SERIALIZO ARCHIVO_RESULTADO_LARGO
	memcpy(buffer+payload,&(nodo_para_master->destino_reduccion_largo),sizeof(typeof(nodo_para_master->destino_reduccion_largo)));
	payload += sizeof(typeof(nodo_para_master->destino_reduccion_largo));
	if(nodo_para_master->destino_reduccion_largo > 0){
		//SERIALIZO EL ARCHIVO_RESULTADO
		memcpy(buffer+payload,nodo_para_master->destino_reduccion,nodo_para_master->destino_reduccion_largo);
		payload+= nodo_para_master->destino_reduccion_largo;

	}
	//SERIALIZO EL NODO_IP_LARGO
	memcpy(buffer+payload,&(nodo_para_master->nodo_ip_largo),sizeof(typeof(nodo_para_master->nodo_ip_largo)));
	payload += sizeof(typeof(nodo_para_master->nodo_ip_largo));
	if(nodo_para_master->nodo_ip_largo > 0){
		//SERIALIZO EL nodo_IP
		memcpy(buffer+payload,nodo_para_master->nodo_ip,nodo_para_master->nodo_ip_largo);
		payload += nodo_para_master->nodo_ip_largo;


	}
	//SERIALIZO EL NODO_PUERTO_LARGO
	memcpy(buffer+payload,&(nodo_para_master->nodo_puerto_largo),sizeof(typeof(nodo_para_master->nodo_puerto_largo)));
	payload += sizeof(typeof(nodo_para_master->nodo_puerto_largo));
	//SERIALIZO EL NODO_PUERTO
	if(nodo_para_master->nodo_puerto_largo > 0){
		memcpy(buffer+payload,nodo_para_master->nodo_puerto,nodo_para_master->nodo_puerto_largo);
		payload += nodo_para_master->nodo_puerto_largo;

	}

	memcpy(buffer+payload,&(nodo_para_master->archivos_reduccion_cantidad),sizeof(typeof(nodo_para_master->archivos_reduccion_cantidad)));
	payload += sizeof(typeof(nodo_para_master->archivos_reduccion_cantidad));
	if(nodo_para_master->archivos_reduccion_cantidad > 0){

		void serializeElement(void*data){
			////SERIALIZO NOMBRE DE ARCHIVO LARGO
			t_archivo_reducir_local* elemntArchivo = (t_archivo_reducir_local*) data;
			memcpy(buffer+payload,&(elemntArchivo->nombreArchivoLargo),sizeof(typeof(elemntArchivo->nombreArchivoLargo)));
			payload += sizeof(typeof(elemntArchivo->nombreArchivoLargo));
			if(elemntArchivo->nombreArchivoLargo > 0){
				//SERIALIZO NOMBRE DE ARCHIVO
				memcpy(buffer+payload,elemntArchivo->nombreArchivo,elemntArchivo->nombreArchivoLargo);
				payload+=elemntArchivo->nombreArchivoLargo;
			}

		}



		list_iterate(nodo_para_master->archivos_reduccion,serializeElement);

	}

	*largo = payload;


	return buffer;
}

int tamanioPaqueteAlmacenamientoFinal(t_pNodo_almacenamiento_final * nodo_para_master){
	int tam = 0;

	tam += sizeof(int32_t)*4 + nodo_para_master->nodo_ip_largo +
	nodo_para_master->nodo_puerto_largo + nodo_para_master->archivo_final_largo;

	return tam;

}

char* serializeMsjAlmacenamientoFinal(t_pNodo_almacenamiento_final * nodo_para_master, int *largo){


	int payload = 0;
	char*buffer;

	int tamanio = tamanioPaqueteAlmacenamientoFinal(nodo_para_master);
	buffer = malloc(tamanio);

	//SERIALIZO NODO_ID
	memcpy(buffer+payload,&(nodo_para_master->nodo_id),sizeof(typeof(nodo_para_master->nodo_id)));
	payload += sizeof(typeof(nodo_para_master->nodo_id));
	//SERIALIZO E NODO_IP_LARGO
	memcpy(buffer+payload, &(nodo_para_master->nodo_ip_largo), sizeof(typeof(nodo_para_master->nodo_ip_largo)));
	payload += sizeof(typeof(nodo_para_master->nodo_ip_largo));
	//SERIALIZO EL nodo_IP
	if(nodo_para_master->nodo_ip_largo > 0){
		memcpy(buffer+payload,nodo_para_master->nodo_ip, nodo_para_master->nodo_ip_largo);
		payload += nodo_para_master->nodo_ip_largo;

	}

	//SERIALIZO EL NODO_PUERTO_LARGO
	memcpy(buffer+payload,&(nodo_para_master->nodo_puerto_largo),sizeof(typeof(nodo_para_master->nodo_puerto_largo)));
	payload += sizeof(typeof(nodo_para_master->nodo_puerto_largo));

	//SERIALIZO EL NODO_PUERTO
	if(nodo_para_master->nodo_puerto_largo > 0){
		memcpy(buffer+payload,nodo_para_master->nodo_puerto,nodo_para_master->nodo_puerto_largo);
		payload += nodo_para_master->nodo_puerto_largo;

	}

	//SERIALIZO ARCHIVO_FINAL_LARGO
	memcpy(buffer+payload ,&(nodo_para_master->archivo_final_largo),sizeof(typeof( nodo_para_master->archivo_final_largo)));
	payload +=  sizeof(typeof( nodo_para_master->archivo_final_largo));

	//SERIALIZO EL ARCHIVO_FINAL
	if(nodo_para_master->archivo_final_largo > 0){
	memcpy(buffer +payload , nodo_para_master->archivo_final,nodo_para_master->archivo_final_largo);
	payload += nodo_para_master->archivo_final_largo;
	}
	*largo = payload;
	return buffer;

}

// este largo es el que sirve para el sendall
char* serializeMsjTransformacion(t_pNodo_transformacion*  nodo_para_master , int* largo){

	char*buffer =malloc(sizeof(int32_t)*6 + nodo_para_master->archivo_resultado_largo + nodo_para_master->nodo_ip_largo + nodo_para_master->nodo_puerto_largo);
	int offset = 0;
	*largo = 0;



		//SERIALIZO NODO_ID
		memcpy(buffer+ offset,&nodo_para_master->nodo_id,sizeof(typeof(nodo_para_master->nodo_id)));
		offset += sizeof(typeof(nodo_para_master->nodo_id));
		*largo += sizeof(typeof(nodo_para_master->nodo_id));
		if (nodo_para_master->archivo_resultado_largo > 0) {
			// SERIALIZO ARCHIVO_RESULTADO_LARGO
			memcpy(buffer+offset,&nodo_para_master->archivo_resultado_largo,sizeof(typeof(nodo_para_master->archivo_resultado_largo)));
			offset += sizeof(typeof(nodo_para_master->archivo_resultado_largo));
		    *largo += sizeof(typeof(nodo_para_master->archivo_resultado_largo));

		    //SERIALIZO EL ARCHIVO_RESULTADO
			memcpy(buffer + offset, nodo_para_master->archivo_resultado,
		    nodo_para_master->archivo_resultado_largo);
			offset += nodo_para_master->archivo_resultado_largo;
			*largo += nodo_para_master->archivo_resultado_largo;
			}
		if(nodo_para_master->nodo_ip_largo>0){
			//SERIALIZO E NODO_IP_LARGO
			memcpy(buffer+offset,&nodo_para_master->nodo_ip_largo,sizeof(typeof(nodo_para_master->nodo_ip_largo)));
			offset += sizeof(typeof(nodo_para_master->nodo_ip_largo));
			*largo += sizeof(typeof(nodo_para_master->nodo_ip_largo));

			//SERIALIZO EL nodo_IP
			memcpy(buffer + offset, nodo_para_master->nodo_ip,
					nodo_para_master->nodo_ip_largo);
			offset += nodo_para_master->nodo_ip_largo;
			*largo += nodo_para_master->nodo_ip_largo;
		}
		if(nodo_para_master->nodo_puerto_largo>0){
			//SERIALIZO EL NODO_PUERTO_LARGO
			memcpy(buffer+offset,&nodo_para_master->nodo_puerto_largo,sizeof(typeof(nodo_para_master->nodo_puerto_largo)));
			offset += sizeof(typeof(nodo_para_master->nodo_puerto_largo));
			*largo += sizeof(typeof(nodo_para_master->nodo_puerto_largo));

			//SERIALIZO EL NODO_PUERTO
			memcpy(buffer + offset, nodo_para_master->nodo_puerto,
					nodo_para_master->nodo_puerto_largo);
		    offset += nodo_para_master->nodo_puerto_largo;
		    *largo += nodo_para_master->nodo_puerto_largo;

		}
		//SERIALIZO EL BLOQUE
		    memcpy(buffer+ offset,&nodo_para_master->bloque,sizeof(typeof(nodo_para_master->bloque)));
			offset += sizeof(typeof(nodo_para_master->bloque));
			*largo += sizeof(typeof(nodo_para_master->bloque));
			//SERIALIZO LOS BYTES OCUPADOS
		    memcpy(buffer+ offset,&nodo_para_master->bytesOcupados,sizeof(typeof(nodo_para_master->bytesOcupados)));
			offset += sizeof(typeof(nodo_para_master->bytesOcupados));
			*largo += sizeof(typeof(nodo_para_master->bytesOcupados));





	return buffer;

}


 static void eliminarListaCargaNodo(void*data){
		carga_nodo* carga = (carga_nodo*) data;
		free(carga);
	}

	static void borrarBloques1(void*data){
		bloque* b1 = (bloque*) data;
		free(b1);

	}


static	void eliminarListaBloquePorArchivo (void*data){
	bloques_en_archivo* bloque_en_archivo = (bloques_en_archivo*) data;
	free(bloque_en_archivo->nombre_archivo);
	free(bloque_en_archivo->ip);



	list_destroy_and_destroy_elements(bloque_en_archivo->bloques,(void*)borrarBloques1);
	free(bloque_en_archivo);

	}

static void borrarBloques(void*data){
	bloque* b1 = (bloque*) data;
	free(b1);

}

//eliminamos elemento de la tabla historial de nodos
static void eliminarListaHistorial (void*data){
historial_nodo* historial = (historial_nodo*) data;
free(historial->ip);



list_destroy_and_destroy_elements(historial->bloques,(void*)borrarBloques);

free(historial);

}


//libero lo que seria  lista de tabla de estado
static	void eliminarTablaEstados(void*data){
		estado_de_un_job* j1 = (estado_de_un_job*) data;
		free(j1->archivoTemporal);

		free(j1->estado);
		free(j1->etapa);
		free(j1->ip);
		free(j1->nodo);
		free(j1);
	}

static void eliminarMaster(void*data){
	master_aceptado *master = (master_aceptado *) data;
	free(master);

}

static void eliminarBloque(void*data){
	bloque* un_bloque = (bloque*) data;
	free(un_bloque);
}

static void eliminarDeNodosBloques(void*data){
	bloques_en_archivo* b_x_a = (bloques_en_archivo*) data;
	free(b_x_a->ip);
	free(b_x_a->nombre_archivo);
	list_destroy_and_destroy_elements(b_x_a->bloques,eliminarBloque);
	free(b_x_a);


}

void liberarMemoria(){
	//liberamos la carga de nodos

	//free();

	list_destroy_and_destroy_elements(lista_carga_de_nodos,(void*)eliminarListaCargaNodo);
	//liberamos la lista de bloque por archivo



	list_destroy_and_destroy_elements(bloques_x_archivo,(void*)eliminarListaBloquePorArchivo);




	list_destroy_and_destroy_elements(tabla_historial_nodos,(void*)eliminarListaHistorial);



	list_destroy_and_destroy_elements(tabla_de_estados,(void*)eliminarTablaEstados);


	list_destroy_and_destroy_elements(yama_masters_aceptados,(void*)eliminarMaster);


	list_destroy_and_destroy_elements(lista_de_nodos_con_bloques,(void*)eliminarDeNodosBloques);

	list_destroy_and_destroy_elements(lista_transformacion_enviadas,(void*)free);




		yama_config_destroy(yama_cfg);
		log_destroy(yama_log);
		close(socket_FS);

}
