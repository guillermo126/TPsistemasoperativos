/*
 * planificacionYama.h
 *
 *  Created on: 3/10/2017
 *      Author: utnso
 */

#ifndef SRC_PLANIFICACIONYAMA_H_
#define SRC_PLANIFICACIONYAMA_H_
#include <commons/collections/list.h>
#include "src/serialize-adm.h"
#include "serialize-yama.h"
#include "yama.h"
#include "funcYamaMaster.h"

//
//estructura que pasa FS a yama
//typedef struct{
//	int nodo;
//	char* ip;
//	int puerto;
//	int bytesOcupados;
//	t_list* bloques;
//
//}nodo_bloques;

//estructura que armamos para registrar el historial de un nodo
typedef struct{
	int master;
	int sock_master;
	int disponibilidad;
	int nodo;
	t_list *bloques;
	int punteroClock;
	int enviar_a_master; // este nos determina si es que hay que mandarlo a master o no 1 es SI y 0 es NO
	char* ip;
	int puerto;
	int bytesOcupados;
	int encargado;

}historial_nodo;
typedef struct{
	int nodo;
	int cargaActual;
	int cargaHistorica;
	int esta_activo;

}carga_nodo;

typedef struct{
	int master;
	int sock_master;
	char* nombre_archivo;
	int bloque;//este se usa para replanificar
	int nodo; // este se usa para replanificar

}tratar_job;
t_list* lista_de_nodos_con_bloques;


typedef struct{
	int master;
	int nodo;

}transfomaciones_enviadas;

t_list* lista_transformacion_enviadas;


// funciones para ejecutar el algoritmo clock
void actualizarTablaDeHistorialDeNodos(int idMaster, int nodo,int cargaActual,int historial);
void obtenerDisponibilidadworkerClock(t_list* lista_de_nodos_con_bloques,t_list* Thistorial_nodos,t_list * lista_carga_de_nod,t_list* lista_j_nuevos,tratar_job* job_creado);
t_list* obtenerListaDeBloquesOrdenadosSinRepetir(t_list *lista_Nodos_Bloques);
int obtenerElqueTengaPuntero(t_list* tabla_historial_nodos);
bool el_nodo_tiene_el_bloque(historial_nodo* nodo_elegido,t_list *listaNodosBloques,bloque* bloque_num);
void ejecutarAlgoritmo(t_list *listaNodosBloques,t_list* listaHistorialNodos,t_list* tabla_carga_nod,tratar_job* job_creado);
void asignarAtodosDispo( t_list* LHistorialNodos);
void registrarReduccionGlobalEnTabla_replanificacion(t_list* tabla_H_nodos,t_list* lista_carga_de_N,t_list* lista_J_nuevos,tratar_job* job,int* error);
int obtenerElqueTengaPuntero(t_list* tabla_historial_nodos);
historial_nodo * nodoConPuntero(t_list* lista_H_nodos);
void borrarListaPreplanificacion(t_list*lista_de_n_con_bloques);
bool el_nodo_tiene_el_bloque(historial_nodo* nodo_elegido,t_list *listaNodosBloques,bloque* bloque_num);
bool establoqueEnLista(bloque* Bloque, t_list *listaOrdSinRepe);
void posicionarPuntero(t_list* tabla_historial,tratar_job* job_creado);
carga_nodo*  buscarNodoEnListaCargaNodos(int numero_nodo);
int crear_hilo_planificador(t_log *logger);
void replanificarTarea(t_list* bloques_por_archivo,t_list* lista_j_a_replanificar,t_list* lista_carga_de_n,t_list* tabla_h_nodos);
void registrarReduccionGlobalEnTabla(t_list* tabla_H_nodos,t_list* lista_carga_de_N,t_list* lista_J_nuevos,tratar_job* job,int* error);
int crear_hilo_replanificacion(t_log* logger);
void borrarListaREplanificacion();

#endif /* SRC_PLANIFICACIONYAMA_H_ */
