/*
 * yama.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */
//
#ifndef SRC_YAMA_H_
#define SRC_YAMA_H_
#include <commons/log.h>
#include <commons/collections/list.h>
#include <pthread.h>
#include <commons/config.h>
#include <commons/string.h>
#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include "src/serialize-adm.h"
#include "src/monitors-adm.h"
#include "src/socket-adm.h"
#include "config.h"
#include "serialize-yama.h"
#include "funcYamaMaster.h"
#include "planificacionYama.h"

int socket_FS;

void recargar_configuracion(int signal);
void crear_hilos_para_signals(void* th_signal);
void* thread_signal_usr1(void* th_signal);

#endif /* SRC_YAMA_H_ */
