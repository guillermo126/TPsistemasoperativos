/*
 * config.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */
//
#include "config.h"
t_config* tConfig;

int yama_config_create(yama_config *config,char* config_path){
	t_config *cfg_config;
	cfg_config = config_create(config_path);
	if(cfg_config == NULL){
		pthread_mutex_lock(&mutex_yama_log);
		log_error(yama_log, "yama_config_create->No se pudo acceder al archivo de config");
		pthread_mutex_unlock(&mutex_yama_log);
		return 0;
	}

	if (config_keys_amount(cfg_config) == CANTIDAD_PARAMETROS_CONFIG) {
		if (config_has_property(cfg_config, "FS_IP")) {
			pthread_mutex_lock(&mutex_yama_cfg);
			config->ip_fs = string_new();
			string_append(&config->ip_fs,config_get_string_value(cfg_config, "FS_IP"));
			pthread_mutex_unlock(&mutex_yama_cfg);
		} else {
			pthread_mutex_lock(&mutex_yama_log);
			log_error(yama_log, "yama_config_create->Falta el parametro: FS_IP");
			pthread_mutex_unlock(&mutex_yama_log);
			return 0;
		}
		if (config_has_property(cfg_config, "FS_PUERTO")) {
			pthread_mutex_lock(&mutex_yama_cfg);
			config->puerto_fs = config_get_int_value(cfg_config, "FS_PUERTO");
			pthread_mutex_unlock(&mutex_yama_cfg);
		} else {
			pthread_mutex_lock(&mutex_yama_log);
			log_error(yama_log, "yama_config_create->Falta el parametro: FS_PUERTO");
			pthread_mutex_unlock(&mutex_yama_log);
			return 0;
		}
		if (config_has_property(cfg_config, "RETARDO_PLANIFICACION")) {
			pthread_mutex_lock(&mutex_yama_cfg);
			config->retardo = config_get_int_value(cfg_config, "RETARDO_PLANIFICACION");
			pthread_mutex_unlock(&mutex_yama_cfg);
		} else {
			pthread_mutex_lock(&mutex_yama_log);
			log_error(yama_log, "yama_config_create->Falta el parametro: RETARDO_PLANIFICACION");
			pthread_mutex_unlock(&mutex_yama_log);
			return 0;
		}
		if (config_has_property(cfg_config, "ALGORITMO_BALANCEO")) {
			pthread_mutex_lock(&mutex_yama_cfg);
			config->algoritmo = string_new();
			string_append(&config->algoritmo,config_get_string_value(cfg_config, "ALGORITMO_BALANCEO"));
			pthread_mutex_unlock(&mutex_yama_cfg);
		} else {
			pthread_mutex_lock(&mutex_yama_log);
			log_error(yama_log, "yama_config_create->Falta el parametro: ALGORITMO_BALANCEO");
			pthread_mutex_unlock(&mutex_yama_log);
			return 0;
		}
		if(config_has_property(cfg_config,"DISP_BASE")){
			pthread_mutex_lock(&mutex_yama_cfg);
			config->disponibilidad = config_get_int_value(cfg_config,"DISP_BASE");
			pthread_mutex_unlock(&mutex_yama_cfg);

		}else{
			pthread_mutex_lock(&mutex_yama_log);
			log_error(yama_log, "yama_config_create->Falta el parametro: DISP_BASE");
			pthread_mutex_unlock(&mutex_yama_log);
			return 0;
		}
	}else{
		pthread_mutex_lock(&mutex_yama_log);
		log_error(yama_log, "yama_config_create->El archivo de configuracion no tiene todos los parametros necesarios");
		pthread_mutex_unlock(&mutex_yama_log);
		return 0;
	}
	pthread_mutex_lock(&mutex_yama_log);
	log_trace(yama_log, "yama_config_create->Se ha cargado el archivo de configuracion del yama exitosamente");
	pthread_mutex_unlock(&mutex_yama_log);
	config_destroy(cfg_config);
	return 1;
}

void yama_config_destroy(yama_config *config){
	free(config);
	pthread_mutex_lock(&mutex_yama_log);
	log_trace(yama_log, "yama_config_destroy->Estructura yama liberada exitosamente");
	pthread_mutex_unlock(&mutex_yama_log);
}

void log_config(yama_config *config){
	pthread_mutex_lock(&mutex_yama_log);
	log_trace(yama_log,"-----Archivo de configuracion del proceso yama -----\n");
	log_trace(yama_log,"FS_IP: %s\n",config->ip_fs);
	log_trace(yama_log,"FS_PUERTO: %d\n",config->puerto_fs);
	log_trace(yama_log,"RETARDO_PLANIFICACION: %d\n",config->retardo);
	log_trace(yama_log,"ALGORITMO_BALANCEO: %s\n",config->algoritmo);
	log_trace(yama_log,"DISP_BASE: %d\n",config->disponibilidad);
	log_trace(yama_log,"-----Fin archivo de configuracion del proceso yama-----\n");
	pthread_mutex_unlock(&mutex_yama_log);
}

int configYlogDeYama(){
	//inicializacion estruvturas y variables globales
	yama_cfg = malloc(sizeof(yama_config));
	yama_log =  log_create(PATH_LOG_YAMA, PROGRAM_NAME, true, LOG_LEVEL_TRACE);
	//se carga la estructura de config del yama
	if(!yama_config_create(yama_cfg,PATH_CONFIG_YAMA)){
		log_error(yama_log, "main-> Error al cargar el archivo de configuracion");
		return EXIT_FAILURE;
	}
	log_config(yama_cfg);
	return EXIT_SUCCESS;

}


