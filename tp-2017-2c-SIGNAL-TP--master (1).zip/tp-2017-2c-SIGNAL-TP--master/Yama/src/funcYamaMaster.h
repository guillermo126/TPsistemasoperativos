/*
 * funcYamaMaster.h
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */

#ifndef SRC_FUNCYAMAMASTER_H_
#define SRC_FUNCYAMAMASTER_H_
#include <commons/collections/list.h>
#include "src/serialize-adm.h"
#include "serialize-yama.h"
#include  "planificacionYama.h"

//
//Lista global que contiene los masters que están conectadas a yama
t_list* yama_masters_aceptados;

//lista que contiene los estados de todos los nodos
t_list* tabla_de_estados;
//mutex tabla de establa
pthread_mutex_t mutex_tabla_de_estados;

//lista que llevara registro del hitorial de los nodos
t_list* tabla_historial_nodos;
//mutex tabla_historial_nodos
pthread_mutex_t mutex_tabla_historial_nodos;

//lista que nos va a enviar el FS al pedir ejecucion sobre un archivo
//t_list* lista_de_nodos_con_bloques;

//lista para actualizar el hitorias de carga de los nodos
t_list * lista_carga_de_nodos;
//mutex para la lista carga de nodos
pthread_mutex_t mutex_lista_carga_de_nodos;

//lista para comunicacion entre hilos unicamente
t_list* lista_jobs_nuevos;
//mutex para lista de jobs nuevos
pthread_mutex_t mutex_lista_jobs_nuevos;

//lista de los que se tiene que replanificar(comunicacions entr hilos)
t_list* lista_jobs_a_replanificar;
//mutex para lista_jobs_a_replanificar;
pthread_mutex_t mutex_lista_jobs_a_replanificar;


//lista con los bloques en los nodos por archivo que obtengo ahciendo copia de la que viene en fs (lista_de_nodos_con_bloques)
t_list* bloques_x_archivo;
//mutex para lista de bloques x archivo
pthread_mutex_t mutex_bloques_x_archivo;

//mutex para el config
pthread_mutex_t mutex_yama_cfg;


//semaforo contador para comunicacion entre los dos hilos del sistema

sem_t sem_job_nuevo;

//semaforo contador para los jobs a replanificar

sem_t sem_job_replanificar;



//numero de master ---> id que identifica a un master
int idMaster;


//id del socket master actual de lectura
int socket_lectura_master;

//condicion de corte para solo enviar transformaciones
//bool condicion_de_corte;

/*master_aceptado:
 *estructura que representa los masters en el sistema
 */

typedef struct{
	//int job; // id del master o job ( es lo mismo)
	int master; // el socket
	int id_master; // id del master
	char* nodo;
	int bloque;
	char* etapa;
	char* archivoTemporal;
	char* estado;
	char* ip;
	int puerto;
	int bytesOcupados;
	int encargado;
	int bloqueFicticio;



} estado_de_un_job;

typedef struct{

	int id_master; // id del master
	int nodo;


} reduccion_local_nueva;


//flag ustilizando en el caso de que se replanifique y el nodo tenga que hacer denuevo la redu local
t_list* new_reducciones_locales;



typedef struct {
	int32_t sock_fd;
} master_aceptado;
/*
 * st_escuchar_conexion:
 * estructura que se utiliza
 * para pasar argumentos a la función escuchar_conexiones_master
 */

typedef struct {
    char *puerto;
    int32_t cola;
    t_log *logger;
} st_escuchar_conexion;


int recibir_mensajesDeMaster(int socket);
void conexion_nuevo_ProcesoMaster();
void dummy_func_escribir(int sock_fd);
int crearServerMultiplexor();
int conectarseAProcesoFyleSystem();
int sock_fs;
void conexion_nuevo_ProcesoMaster();
void crearEstructurasGlobales();
estado_de_un_job* tomarElemento(char* etapa,int master_id,int nodo_num,int num_bloque, char* estado);
void *escuchar_conexiones_master(void* arg_escuchar_conexion);
int crear_hilo_escuchar_conexiones_master(t_log *logger);
void actualizarTablaDeEstados(char* TipoOperacion,char* etapa, int id_master,int master, int nodo, char* nuevoEstado
		,char*ip,int puerto, int bloque,int bytesOcupados,char* ArchivoTemporal,int es_encargado,int bloque_ficticio);



#endif /* SRC_FUNCYAMAMASTER_H_ */
