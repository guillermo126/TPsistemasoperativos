/*
 * filesystem.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */
#include "filesystem.h"

int main(int argc, char *argv[]) {

	//inicializacion estruvturas y variables globales
	filesystem_cfg = malloc(sizeof(filesystem_config));
	filesystem_log =  log_create(PATH_LOG_FILESYSTEM, PROGRAM_NAME, false, LOG_LEVEL_TRACE);
	//se carga la estructura de config del filesystem
	if(!filesystem_config_create(filesystem_cfg,PATH_CONFIG_FILESYSTEM)){
		log_error(filesystem_log, "main-> Error al cargar el archivo de configuracion");
		return EXIT_FAILURE;
	}

	//loguear el archivo config de file system
	log_config(filesystem_cfg);

	//inicializar estructuras
	initialize_fs();

	//validar invocacion fs
	if(!validar_invocacion_fs(argc,argv)){
		return EXIT_FAILURE;
	}

	pthread_mutex_lock(&mutex_estado_anterior);
	if(estado_anterior == 1){
		estado_anterior = cargar_archivos_metadata();
	}
	pthread_mutex_unlock(&mutex_estado_anterior);



	//creo hilo para escuchar conexiones de filesystem
	if(crear_hilo_escuchar_conexiones_filesystem(filesystem_log)){
		log_error(filesystem_log, "main-> Error al crear hilo para escuchar conexines de procesos");
		return EXIT_FAILURE;
	}
	//consola del proceso filesystem
	ejecutar_consola_con_historial("fsyama>");
	//liberacion de estructuras variables globalesf
	filesystem_config_destroy(filesystem_cfg);
	list_destroy_and_destroy_elements(filesystem_procesos_aceptados, (void*)free);
	list_destroy_and_destroy_elements(filesystem_datanodes_conectados, (void*)datanode_destroy);
	list_destroy_and_destroy_elements(filesystem_datanodes_desconectados, (void*)datanode_destroy);
	liberar_directorios_y_archivos();
	log_destroy(filesystem_log);
	free(nombre_archivo_aux);
	return EXIT_SUCCESS;

}
