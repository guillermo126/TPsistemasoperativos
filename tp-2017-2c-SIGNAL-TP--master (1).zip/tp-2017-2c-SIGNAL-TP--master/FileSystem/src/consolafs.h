/*
 * console.h
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */

#ifndef SRC_CONSOLAFS_H_
#define SRC_CONSOLAFS_H_
#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/errno.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "coreFS.h"

typedef int Function ();
Function *func;
typedef void VFunction ();
typedef char *CPFunction ();
typedef char **CPPFunction ();

typedef struct {
  char *name;
  Function *func;
  char *doc;
} COMMAND;

int quiere_salir_consola;

extern char *getwd ();
extern char *xmalloc ();
int comando_format(),comando_rm(),comando_help(),comando_rename(),
comando_mv(),comando_cat(),comando_mkdir(),comando_cpfrom(),comando_cpto(),
comando_cpblock(),comando_md5(),comando_ls(),comando_info(),comando_df(),comando_exit();

char *stripwhite ();
COMMAND *find_command ();
void ejecutar_consola_con_historial(char* prompt);
void initialize_readline (void);

#endif /* SRC_CONSOLAFS_H_ */
