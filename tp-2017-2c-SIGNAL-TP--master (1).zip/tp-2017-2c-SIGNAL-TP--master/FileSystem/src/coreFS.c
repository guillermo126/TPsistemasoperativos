/*
 * coreFS.c
 *
 *  Created on: 16/9/2017
 *      Author: utnso
 */
#include "coreFS.h"

/*
 * Imprime la tabla de directorios. Sin retorno/respuesta
 * */
void print_table_directory(){
	int i;
	pthread_mutex_lock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"------TABLA DE DIRECTORIOS INI------");
	for(i=0;i<100;i++){
		if(tabla_directorios[i].estado==VALIDO){
			log_trace(filesystem_log,"----------------------------");
			log_trace(filesystem_log,"INDEX: %d",tabla_directorios[i].index);
			log_trace(filesystem_log,"NOMBRE: %s",tabla_directorios[i].nombre);
			log_trace(filesystem_log,"PADRE: %d",tabla_directorios[i].padre);
			log_trace(filesystem_log,"----------------------------");
		}
	}
	log_trace(filesystem_log,"------TABLA DE DIRECTORIOS FIN------");
	pthread_mutex_unlock(&mutex_tabla_directorios);
}

void liberar_directorios_y_archivos(void){
	int i;
	pthread_mutex_lock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"liberar_directorios_y_archivos->init");
	for(i=0;i<100;i++){
		list_destroy_and_destroy_elements(tabla_directorios[i].archivos, (void*)destroy_file);
	}
	log_trace(filesystem_log,"liberar_directorios_y_archivos->end");
	pthread_mutex_unlock(&mutex_tabla_directorios);
}

/*
 * Agrega un directorio a la tabla de directorios. Sin retorno/respuesta
 * */
void add_directory(int32_t index,char* nombre,int32_t padre,t_directory_state estado){
	log_trace(filesystem_log,"add_directory->init");
	pthread_mutex_lock(&mutex_tabla_directorios);
	tabla_directorios[index].index=index;
	strcpy(tabla_directorios[index].nombre, nombre);
	tabla_directorios[index].padre=padre;
	tabla_directorios[index].estado=estado;
	pthread_mutex_init(&tabla_directorios[index].mutex_archivos,NULL);
	pthread_mutex_unlock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"add_directory->end");
	return;
}

/*
 * Inicializa la tabla de directorios. Sin retorno/respuesta
 * */

void initialize_table_directory(){
	log_trace(filesystem_log,"initialize_table_directory->init");
	int i;

	for(i=0;i<100;i++){
		if(i==0){
			tabla_directorios[i].archivos = list_create();
			add_directory(i,"root",-1,VALIDO);
		}else{
			tabla_directorios[i].archivos = list_create();
			add_directory(i,"Inicializado",-1,INICIALIZADO);
		}

	}

	log_trace(filesystem_log,"initialize_table_directory->end");
}

void initialize_others_directory(){
	log_trace(filesystem_log,"initialize_table_directory->init");
	int i;

	for(i=0;i<100;i++){
		if(tabla_directorios[i].estado!=VALIDO){
			tabla_directorios[i].archivos = list_create();
			add_directory(i,"Inicializado",-1,INICIALIZADO);
		}
	}

	log_trace(filesystem_log,"initialize_table_directory->end");
}


/*
 * Obtiene el indice del primer directorio disponible
 * en la tabla de directorio empezando desde el principio.
 * Una entrada directorio esta disponible si esta inicializada o borrada.
 * Si encontro un directorio disponible retorna el valor del indice.
 * Si no devuelve -1
 * */

int obtener_index_directorio_disponible(){
	log_trace(filesystem_log,"obtener_index_directorio_disponible->init");
	int i,index=-1;
	pthread_mutex_lock(&mutex_tabla_directorios);
	for(i=0;i<100;i++){
		if(tabla_directorios[i].estado==INICIALIZADO || tabla_directorios[i].estado==BORRADO){
			index = i;
			break;
		}
	}
	pthread_mutex_unlock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"obtener_index_directorio_disponible->end");
	return index;
}

/*
 * busca un directorio con un determinado nombre y
 * un determinado id_directorio_padre(indice).
 * Si lo encuentra devuelve el indice del directorio buscado.
 * Si no lo encuentra devuelve -1.
 * */
int buscar_directorio(char *nombre,int32_t padre){
	int i,index=-1;
	log_trace(filesystem_log,"buscar_directorio->init");
	pthread_mutex_lock(&mutex_tabla_directorios);
	for(i=0;i<100;i++){
		if(string_equals_ignore_case(tabla_directorios[i].nombre, nombre) && tabla_directorios[i].padre == padre && tabla_directorios[i].estado == VALIDO){
			index = i;
			break;
		}
	}
	pthread_mutex_unlock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"buscar_directorio->end");
	return index;
}

/*
 * Guarda la tabla de directorios en el archivo
 * metadata especificado.
 * */

void save_table_directory_to_file(void){
	int i;
	FILE *pFileMetadata = NULL;
	char* buffer;
	char* aux;
	pthread_mutex_lock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"save_table_directory_to_file->init");
	pFileMetadata = fopen(PATH_METADATA_DIRECTORY, "w");
	if(pFileMetadata == NULL)
	{
		log_error(filesystem_log,"Error al abrir el archivo %s donde se guarda la tabla de dorectorios",PATH_METADATA_DIRECTORY);
	}else{
		buffer = string_new();
		string_append(&buffer, "Index Directorio Padre\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		for(i=0;i<100;i++){
			if(tabla_directorios[i].estado==VALIDO){
				buffer = string_new();
				aux = string_itoa(tabla_directorios[i].index);
				string_append(&buffer, aux);
				free(aux);
				string_append(&buffer, " ");
				string_append(&buffer, tabla_directorios[i].nombre);
				string_append(&buffer, " ");
				aux = string_itoa(tabla_directorios[i].padre);
				string_append(&buffer, aux);
				free(aux);
				string_append(&buffer, " ");
				string_append(&buffer, "\n");
				fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
				free(buffer);
			}
		}
	}
	pthread_mutex_unlock(&mutex_tabla_directorios);
	fclose(pFileMetadata);
	log_trace(filesystem_log,"save_table_directory_to_file->end");

}

/*
 * crea un directorio con el nombre y id padre
 * pasados por parametro.
 * Si el nombre del directorio supera el limite, retorna -2
 * Si no hay entradas disponibles en la tabla de directorios, retorna -1
 * Si pudo crearlo devuelve el indice del directorio creado
 * */
int create_directory(char *nombre,int32_t padre){
	int index;
	log_trace(filesystem_log,"create_directory->init");
	//respeta la longitud
	if(string_length(nombre)>MAX_SIZE_NAME_DIRECTORY){
		//no respeta la longitud
		index=-2;
		log_error(filesystem_log,"create_directory->el nombre del directorio supera el limite de 255 caracteres");
	}else{
		//respeta la longitu , veo si puedo crearlo
		index=obtener_index_directorio_disponible();
		if(index!=-1){
			add_directory(index,nombre,padre,VALIDO);
			//logueo la tabla de directorios
			print_table_directory();
			//grabo la tabla de directorios en el archivo
			save_table_directory_to_file();
		}else{
			log_error(filesystem_log,"create_directory->no quedan entradas en la tabla de directorios");
		}

	}
	log_trace(filesystem_log,"create_directory->end");
	return index;
}

/*remueve el caracter \n*/
void remove_new_line(char* string){
	char *pos;
	if ((pos=strchr(string, '\n')) != NULL)
		*pos = '\0';
}

/*Recibe una linea del archivo de metadata de las tablas de directorios,
 * , lo convierte en un directorio y lo agrega a la tabla.
 * Es para el proceso de inicializacion.
 * Si no pudo hacer la conversion devuelve 0,
 * caso contrario devuelve 1*/
int map_string_to_directory(char* directory_string){
	log_trace(filesystem_log,"string_to_directory->init");
	int cantidad_params=0;
	int respuesta=0;
	char** directorio_spliteado;
	//remuevo nueva linea
	remove_new_line(directory_string);
	//remuevo espacios a derecha
	string_trim_right(&directory_string);
	//spliteo
	directorio_spliteado = string_split(directory_string, " ");
	while(directorio_spliteado[cantidad_params]!=NULL){
		cantidad_params++;
	}
	//respeta la estructura del archivo (tengo 3 argumentos)?
	if(cantidad_params!=3){
		log_error(filesystem_log,"string_to_directory->el directorio leido no cumple con el formato <index> <nombre> <id_padre>");
	}else{
		if(atoi(directorio_spliteado[0])<100){
			respuesta = 1;
			//tengo todos los parametros para agregar el directorio a la tabla y el indice es valido
			add_directory(atoi(directorio_spliteado[0]),directorio_spliteado[1],atoi(directorio_spliteado[2]),VALIDO);
			tabla_directorios[atoi(directorio_spliteado[0])].archivos=list_create();
			//libero lo que ya no voy a usar
			cantidad_params = 0;
			while(directorio_spliteado[cantidad_params]!=NULL){
				free(directorio_spliteado[cantidad_params]);
				cantidad_params++;
			}
			log_trace(filesystem_log,"string_to_directory->nuevo_directorio creado");
		}else{
			//puso un index correcto
			log_error(filesystem_log,"string_to_directory->el indice de directorio leido no se encuentra en el rango 0-99");
		}
	}
	log_trace(filesystem_log,"string_to_directory->end");
	free(directory_string);
	return respuesta;
}
/*
 * Lee la tabla de directorios desde el archivo de metadata
 * Para el proceso de inicializacion
 */
void read_directory_table_from_metadata(){
	FILE *pFileMetadata = NULL;
	char* buffer=malloc(sizeof(char)*265);
	log_trace(filesystem_log,"read_directory_table_from_metadata->init");
	pFileMetadata = fopen(PATH_METADATA_DIRECTORY, "r");
	if(pFileMetadata == NULL)
	{
		log_error(filesystem_log,"Error al abrir el archivo %s donde se guarda la tabla de dorectorios",PATH_METADATA_DIRECTORY);
	}else{
		//el archivo que escribo yo tiene un encabezado, lo leo y descarto
		fgets(buffer,265,pFileMetadata);
		free(buffer);
		buffer=malloc(sizeof(char)*265);
		//ahora si leo todos los directorios
		while(fgets(buffer,265,pFileMetadata)!=NULL){
			if(!map_string_to_directory(buffer)){
				log_error(filesystem_log,"Error al intentar agregar el directorio de la linea %s a la tabla de directorios",buffer);
			}
			buffer=malloc(sizeof(char)*265);
		}
	}
	free(buffer);
	fclose(pFileMetadata);
	log_trace(filesystem_log,"read_directory_table_from_metadata->se termino de cargar los directorios");
	log_trace(filesystem_log,"read_directory_table_from_metadata->end");
}

/*
 * validar_path:
 * verifica si un path existe (retorno el indice del directorio)
 * o no (retorno 0 )
 * */
int validar_path(char* path){
	int index,rta = 0;
	int i = 0;
	int existe = 1;
	int padre = 0;
	char** nombres_dir;
	log_trace(filesystem_log,"validar_path->init");
	nombres_dir=string_split(path, "/");
	//Me fijo si ya existe ese path
	while(existe && nombres_dir[i]!=NULL){
		index=buscar_directorio(nombres_dir[i],padre);
		if(index==-1){
			existe = 0;
		}else{
			padre = index;
			i++;
		}
	}
	if(existe && nombres_dir[i]==NULL){
		rta = index;
	}
	i=0;
	while(nombres_dir[i]!=NULL){
		free(nombres_dir[i]);
		i++;
	}
	free(nombres_dir);
	log_trace(filesystem_log,"validar_path->end");
	return rta;
}
/*
 * borrar_directorio:
 * cambia el estado de un directorio (index_dir) a borrado
 * si es que el mismo no tiene archivos, retorna 1(ok).
 * caso contrario retorna 0(error).
 * */
int validar_borrar_directorio (int index_dir){
	int rta=0;
	log_trace(filesystem_log,"validar_path->end");
	pthread_mutex_lock(&mutex_tabla_directorios);
	pthread_mutex_lock(&tabla_directorios[index_dir].mutex_archivos);
	if(list_is_empty(tabla_directorios[index_dir].archivos)){
		rta = 1;
		tabla_directorios[index_dir].estado = BORRADO;
	}
	pthread_mutex_unlock(&tabla_directorios[index_dir].mutex_archivos);
	pthread_mutex_unlock(&mutex_tabla_directorios);
	save_table_directory_to_file();
	return rta;
	log_trace(filesystem_log,"validar_path->end");
}
/*
 * borra un directorio con el nombre pasado por parametro
 * si no existe el directorio, devuelve -1
 * si no se pudo borrar (tenia archivos), devuelve 0
 * si se borro correctamente, devuelve 1
 * */
int rmdir_fs_yama(char* nombre){
	int rta = -1;
	int i=0;
	log_trace(filesystem_log,"rmdir_fs_yama->end");
	char** split = string_split(nombre, " ");
	int index = validar_path(split[1]);
	if(index > 0){
		rta = validar_borrar_directorio (index);
	}
	while(split[i]!=NULL){
		free(split[i]);
		i++;
	}
	log_trace(filesystem_log,"rmdir_fs_yama->end");
	return rta;
}


void leer_bloque_archivo(t_block* bl,t_nodobloque* n_bloque){
	t_list* nodobloques_para_leer;
	t_list* bloques_aux;
	//existe archivo, tengo la lista de bloques
	pthread_mutex_lock(&mutex_cant_bloques_leer);
	cant_bloques_leer = 1;
	pthread_mutex_unlock(&mutex_cant_bloques_leer);
	pthread_mutex_lock(&mutex_buffer_lectura);
	buffer_lectura = malloc(bl->fin_bloque);
	pthread_mutex_unlock(&mutex_buffer_lectura);
	pthread_mutex_lock(&mutex_size_leer);
	size_leer = bl->fin_bloque;
	pthread_mutex_unlock(&mutex_size_leer);
	nodobloques_para_leer = list_create();
	list_add(nodobloques_para_leer,n_bloque);
	bloques_aux = list_create();
	list_add(bloques_aux,bl);
	//mando la solicitud para leer
	if(!enviar_mensaje_lectura_datanodes(nodobloques_para_leer,bloques_aux)){
		log_error(filesystem_log,"leer_bloque_archivo->Error al enviar mensaje a los datanodes");
	}
	sem_wait(&b_lectura);
	log_trace(filesystem_log,"leer_bloque_archivo->ya se leyeron todos los bloques, el contenido del archiv esta disponible");
	list_destroy(nodobloques_para_leer);
	list_destroy(bloques_aux);
}

/* -3 error mensaje
 * -2 no existe el nodo
 * -1 bloque no encontrado
 *  0 no hay espacio en bloque destino
 *  1 ok
 * */
int copiar_bloque_de_arch(t_file* arch,int n_bloque,int nodo){
	int rta;
	t_block *bl;
	t_nodobloque* nb_lectura;
	t_nodobloque* nb_escritura;
	int encontrado = 0;
	int i=0;
	int n_bloque_nodo;
	t_list *nb_escrib;
	log_trace(filesystem_log,"copiar_bloque_de_arch->init");
	pthread_mutex_lock(&arch->mutex_bloques);
	while(i<list_size(arch->bloques) && !encontrado){
		bl = list_get(arch->bloques,i);
		if(bl->num_bloque==n_bloque){
			encontrado = 1;
		}
		i++;
	}
	if(!encontrado){
		rta = -1;
		log_error(filesystem_log,"copiar_bloque_de_arch->bloque %d no encontrado",n_bloque);
	}else{
		//hay espacio en el bloque destino?
		pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
		pthread_mutex_lock(&mutex_id_nodo_busqueda);
		id_nodo_busqueda = nodo;
		t_datanode* dnode =list_find(filesystem_datanodes_conectados, (void*)es_nodo_con_id);
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		if(dnode==NULL){
			rta = -2;
			log_error(filesystem_log,"copiar_bloque_de_arch->nodo %d no encontrado",nodo);
		}else{
			n_bloque_nodo = obtener_bloque_libre_nodo(dnode);
			if(n_bloque_nodo == -1){
				rta = 0;
				log_error(filesystem_log,"copiar_bloque_de_arch->no hay espacio en el nodo %d",nodo);
			}else{
				//lo escribo en el bitmap
				escribir_bloque_bitmap(dnode,n_bloque_nodo);
				//actualizo info nodo
				actualizar_bloques_libres_nodo(dnode->datanode_id,dnode->bloques_libres-1);
				//actualizo bloques sistema
				actualizar_bloques_sistema();
				//creo nodo bloque para lectura, agarro el primero del bloque
				pthread_mutex_lock(&bl->mutex_nodobloques);
				nb_lectura = list_get(bl->nodobloques,0);
				pthread_mutex_unlock(&bl->mutex_nodobloques);
				leer_bloque_archivo(bl,nb_lectura);
				//ya se pudo leer el bloque ahora tengo que escribir
				pthread_mutex_lock(&mutex_buffer_lectura);
				pthread_mutex_lock(&mutex_size_leer);
				nb_escritura = nodobloque_create(dnode->datanode_id,n_bloque_nodo);
				nb_escrib = list_create();
				list_add(nb_escrib,nb_escritura);
				if(!enviar_mensaje_escritura_datanodes(nb_escrib, size_leer,buffer_lectura)){
					log_error(filesystem_log,"copiar_bloque_de_arch->error al enviar msje de escritura");
					rta = -3;
				}else{
					rta = 1;
				}
				//agrego el nodobloque al bloque del archivo
				pthread_mutex_lock(&bl->mutex_nodobloques);
				list_add(bl->nodobloques,nb_escritura);
				free(buffer_lectura);
				size_leer = 0;
				offset_leer = 0;
				pthread_mutex_unlock(&bl->mutex_nodobloques);
				pthread_mutex_unlock(&mutex_size_leer);
				pthread_mutex_unlock(&mutex_buffer_lectura);
				pthread_mutex_lock(&mutex_cant_bloques_leer);
				cant_bloques_leer = 0;
				pthread_mutex_unlock(&mutex_cant_bloques_leer);
				list_destroy(nb_escrib);
			}
		}
	}
	pthread_mutex_unlock(&arch->mutex_bloques);
	log_trace(filesystem_log,"copiar_bloque_de_arch->end");
	return rta;
}
/*
 * cpblock:
 *
 * copia el bloque de un archivo a un nodo deterinado
 */

void cpblock_fs_yama(char* patharg){

	log_trace(filesystem_log,"cpblock_fs_yama->init");
	int i=0;
	char** split = string_split(patharg, " ");
	//path archivo arg 0
	//nro bloque arg 1
	//idnodo arg 2
	int longitud_nombre = 0;
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	char* aux;
	t_file* archivo;
	int dir_padre;
	int resultado;

	aux = obtener_nombre_archivo_path(split[0]);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	// directorio local
	aux = string_substring(split[0], 0, string_length(split[0])-longitud_nombre);
	string_append(&path_yama,aux);
	free(aux);

	dir_padre = validar_path(path_yama);
	if(!dir_padre){
		//no existe directorio
		log_error(filesystem_log,"cp_block_file->El directorio %s no existe",path_yama);
		printf("Error. El directorio %s no existe.\n",path_yama);
	}else{
		pthread_mutex_lock(&mutex_tabla_directorios);
		archivo = buscar_nombre_arch_en_dir(nombre_archivo,dir_padre);
		pthread_mutex_unlock(&mutex_tabla_directorios);
		if(archivo==NULL){
			//no existe archivo
			log_error(filesystem_log,"cp_block_file->El archivo %s no existe en el directorio %s.\n",nombre_archivo,path_yama);
			printf("Error. El archivo %s no existe en el directorio %s.\n",nombre_archivo,path_yama);
		}else{
			//existe archivo, tengo que validar si existe el bloque
			//si existe copiarlo
			resultado = copiar_bloque_de_arch(archivo,atoi(split[1]),atoi(split[2]));
			if(resultado == -3){
				log_error(filesystem_log,"cp_block_file->Error interno al enviar mensaje de escritura.");
				printf("Error interno al enviar mensaje de escritura.\n");
			}else if(resultado == -2){
				log_error(filesystem_log,"cp_block_file->No existe el nodo %d.",atoi(split[2]));
				printf("No existe el nodo %d.\n",atoi(split[2]));
			}else if(resultado == -1){
				log_error(filesystem_log,"cp_block_file->No existe el bloque %d para el archivo.",atoi(split[1]));
				printf("No existe el bloque %d para el archivo.\n",atoi(split[1]));
			}else if(resultado == 0){
				log_error(filesystem_log,"cp_block_file->No hay espacio en el nodo %d",atoi(split[2]));
				printf("No hay espacio en el nodo %d\n",atoi(split[2]));
			}else{
				actualizar_bloques_sistema();
				log_trace(filesystem_log,"cp_block_file->Se hizo una copia del bloque %d del archivo %s en el nodo %d correctamente.\n",atoi(split[1]),nombre_archivo,atoi(split[2]));
				printf("Se hizo una copia del bloque %d del archivo %s en el nodo %d correctamente.\n",atoi(split[1]),nombre_archivo,atoi(split[2]));
			}
		}
	}

	while(split[i]!=NULL){
		free(split[i]);
		i++;
	}
	free(split);
	free(nombre_archivo);
	free(path_yama);
	log_trace(filesystem_log,"cpblock_fs_yama->end");

}
/*
 * mv:
 *
 * mueve un archivo o directorio a otro del mismo tipo
 * Devuelve 0 si las rutas no son validas.
 * Devuelve -1 si el path origen en caso de ser archivo no existe.
 * Devuelve -2 el archivo no se encuentra en el path origen
 * */

int mv_fs_yama(char* paths){
	int rta = 1;
	log_trace(filesystem_log,"mv_fs_yama->init");
	int index_path_origen;
	t_file* archivo;
	int index_path_destino;
	int longitud_nombre;
	char* path_origen_aux;
	char *aux;
	int index_path_origen_aux;
	int i=0;
	char** paths_split = string_split(paths," ");
	index_path_origen = validar_path(paths_split[0]);
	index_path_destino = validar_path(paths_split[1]);
	//primero me fijo si las rutas son validas
	if((index_path_origen !=0 && index_path_destino !=0) || (index_path_origen ==0 && index_path_destino !=0 )){
		//evaluamos si son de tipo archivo o directorio y operamos
		if(index_path_origen !=0 && index_path_destino !=0){
			//ambos son directorios => cambio el padre
			pthread_mutex_lock(&mutex_tabla_directorios);
			tabla_directorios[index_path_origen].padre = tabla_directorios[index_path_destino].padre;
			pthread_mutex_unlock(&mutex_tabla_directorios);
			log_trace(filesystem_log,"mv_fs_yama->El nuevo padre del directorio %s es el directorio %s.",paths_split[0],paths_split[1]);
		}else{
			//el origen es archivo y el destino es directorio => cambio el archivo
			path_origen_aux = string_new();
			aux = obtener_nombre_archivo_path(paths_split[0]);
			longitud_nombre = string_length(aux);
			string_append(&path_origen_aux,string_substring(paths_split[0], 0, string_length(paths_split[0])-longitud_nombre));
			index_path_origen_aux = validar_path(path_origen_aux);
			if(!index_path_origen_aux){
				//no existe el path previo al archivo
				log_error(filesystem_log,"mv_fs_yama->El directorio %s no existe",path_origen_aux);
				rta = -1;
			}else{
				//busco el archivo en el path de origen
				pthread_mutex_lock(&tabla_directorios[index_path_origen].mutex_archivos);
				archivo = buscar_en_lista_de_archivos(aux,tabla_directorios[index_path_origen_aux].archivos);
				pthread_mutex_unlock(&tabla_directorios[index_path_origen].mutex_archivos);
				if(archivo != NULL){
					//lo agrego al path destino y lo borro del path original
					//borro la metadata del directorio anterior
					borrar_metadata_file(archivo->directorio_padre,archivo);
					pthread_mutex_lock(&mutex_tabla_directorios);
					pthread_mutex_lock(&mutex_nombre_archivo_aux);
					string_append(&nombre_archivo_aux,archivo->nombre);
					list_remove_by_condition(tabla_directorios[index_path_origen_aux].archivos, (void*)es_archivo_con_nombre);
					free(nombre_archivo_aux);
					nombre_archivo_aux = string_new();
					archivo->directorio_padre = index_path_origen_aux;
					pthread_mutex_unlock(&mutex_nombre_archivo_aux);
					pthread_mutex_unlock(&mutex_tabla_directorios);
					//agrego el archivo al directorio destino
					pthread_mutex_lock(&tabla_directorios[index_path_destino].mutex_archivos);
					list_add(tabla_directorios[index_path_destino].archivos,archivo);
					pthread_mutex_unlock(&tabla_directorios[index_path_destino].mutex_archivos);
					save_file_info_to_file(archivo);
					log_trace(filesystem_log,"mv_fs_yama->El archivo: %s se movio al directorio %s",aux,paths_split[1]);
				}else{
					log_error(filesystem_log,"mv_fs_yama->El archivo: %s no esta en el directorio %s",aux,path_origen_aux);
					rta = -2;
				}
			}
			free(aux);
			free(path_origen_aux);
		}

	}else{
		rta = 0;

	}

	while(paths_split[i]!=NULL){
		free(paths_split[i]);
		i++;
	}
	log_trace(filesystem_log,"mv_fs_yama->end");
	return rta;
}
/*
 * mkdir:
 * Crea un directorio en la tabla de directorios, si es posible.
 * Devuelve 0 si el dir ya existe.
 * Devuelve -2 si el nombrees muy largo.
 * Devuelve -1 si no se puede crear el directorio en la tabla de directorios.
 * Devuelve 1 en OK
 * */
int mkdir_fs_yama(char* nombre){
	char** nombres_dir;
	int index,i=0;
	int padre = 0;
	int existe=1;
	int error_dir=0;
	int rta;
	log_trace(filesystem_log,"mkdir_fs_yama->init");
	//string_trim(&nombre);
	nombres_dir=string_split(nombre, "/");
	//Me fijo si ya existe ese path
	while(existe && nombres_dir[i]!=NULL){
		index=buscar_directorio(nombres_dir[i],padre);
		if(index==-1){
			existe = 0;
		}else{
			padre = index;
			i++;
		}
	}
	if(existe){
		//existe
		log_error(filesystem_log,"mkdir_fs_yama->el directorio %s ya existe",nombre);
		rta = 0;
	}else{
		//no existe, intento crear el/los directorios
		while(!error_dir && nombres_dir[i]!=NULL){
			index=create_directory(nombres_dir[i],padre);
			if(index==-1 || index==-2){
				error_dir = 1;
			}else{
				padre = index;
				i++;
			}
		}
		if(error_dir){
			log_error(filesystem_log,"mkdir_fs_yama->error al querer crear el directorio %s",nombre);
			rta = index;
		}else{
			rta = index;
			log_trace(filesystem_log,"mkdir_fs_yama->directorio creado exitosamente");
		}
	}
	i=0;
	while(nombres_dir[i]!=NULL){
		free(nombres_dir[i]);
		i++;
	}
	free(nombres_dir);
	log_trace(filesystem_log,"mkdir_fs_yama->end");
	return rta;
}


/*
 * Inicializa las estructuras necesarias
 * para el proceso filesystem
 * */

void initialize_fs(void){
	log_trace(filesystem_log,"initialize_fs->init");
	filesystem_estable = 0;
	estado_anterior = 0;
	offset_leer = 0;
	se_pide_md5 = 0;
	nombre_archivo_aux = string_new();
	//buffer_lectura = string_new();
	filesystem_procesos_aceptados=list_create();
	filesystem_datanodes_conectados=list_create();
	filesystem_datanodes_desconectados=list_create();
	pthread_mutex_init(&mutex_filesystem_estable, NULL);
	pthread_mutex_init(&mutex_filesystem_procesos_aceptados, NULL);
	pthread_mutex_init(&mutex_socket_lectura_proceso, NULL);
	pthread_mutex_init(&mutex_filesystem_datanodes_conectados, NULL);
	pthread_mutex_init(&mutex_filesystem_datanodes_desconectados, NULL);
	pthread_mutex_init(&mutex_id_nodo_busqueda, NULL);
	pthread_mutex_init(&mutex_tabla_directorios, NULL);
	pthread_mutex_init(&mutex_bloques_libres_sistema,NULL);
	pthread_mutex_init(&mutex_bloques_totales_sistema,NULL);
	pthread_mutex_init(&mutex_crear_nodo_bloque,NULL);
	//pthread_mutex_init(&mutex_recibir_mensajes,NULL);
	//pthread_mutex_init(&mutex_enviar_mensajes,NULL);
	pthread_mutex_init(&mutex_id_nb_busqueda,NULL);
	sem_init(&b_lectura, 0, 0);
	sem_init(&b_orden_lectura, 0, 0);
	MD5_Init (&mdContext);
	//pthread_mutex_lock(&mutex_enviar_mensajes);
	log_trace(filesystem_log,"initialize_fs->end");
}

/*Imprime una estructura datanode*/

void imprimir_datanode_sistema(t_datanode* dnode){
	log_trace(filesystem_log, "------------------------",dnode->datanode_id);
	log_trace(filesystem_log, "DATANODE_ID: %d",dnode->datanode_id);
	log_trace(filesystem_log, "DATANODE_IP_WORKER: %s",dnode->ip_worker);
	log_trace(filesystem_log, "DATANODE_PUERTO_WORKER: %d",dnode->puerto_worker);
	log_trace(filesystem_log, "DATANODE_BLOQUES_LIBRES: %d",dnode->bloques_libres);
	log_trace(filesystem_log, "DATANODE_BLOQUES_TOTALES: %d",dnode->bloques_totales);
	log_trace(filesystem_log, "------------------------",dnode->datanode_id);
}

/*Imprime todos los datanodes activos en el sistema*/
void imprimir_datanodes_sistema(){
	log_trace(filesystem_log, "--------DATANODES EN EL SISTEMA INI--------");

	if(list_is_empty(filesystem_datanodes_conectados)){
		log_trace(filesystem_log, "Lista vacia.");
	}else{
		pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
		list_iterate(filesystem_datanodes_conectados,(void*)imprimir_datanode_sistema);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	}
	log_trace(filesystem_log, "--------DATANODES EN EL SISTEMA FIN--------");
}

/*agrega un datanode a la lista de datanode validos*/
void agregar_a_datanodes_validos(t_datanode* dnode){
	log_trace(filesystem_log,"agregar_a_datanodes_validos->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	list_add(filesystem_datanodes_conectados,dnode);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"agregar_a_datanodes_validos->end");
}

void agregar_a_datanodes_validos_desconexion(t_datanode* dnode){
	log_trace(filesystem_log,"agregar_a_datanodes_validos->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_desconectados);
	list_add(filesystem_datanodes_desconectados,dnode);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_desconectados);
	log_trace(filesystem_log,"agregar_a_datanodes_validos->end");
}

/*agrega un proceso a la lista de procesos validos*/
void agregar_a_procesos_validos(t_proceso_conectado *proc){
	log_trace(filesystem_log,"agregar_a_procesos_validos->init");
	pthread_mutex_lock(&mutex_filesystem_procesos_aceptados);
	list_add(filesystem_procesos_aceptados,proc);
	pthread_mutex_unlock(&mutex_filesystem_procesos_aceptados);
	log_trace(filesystem_log,"agregar_a_procesos_validos->end");
}
/*crea una estructura del tipo proceso conectado*/
t_proceso_conectado *proceso_conectado_create(int sock_fd){
	t_proceso_conectado *nuevo_proceso = malloc(sizeof(t_proceso_conectado));
	nuevo_proceso->sock_fd = sock_fd;
	return nuevo_proceso;
}

/*
 * Crea una estructura del tipo datanode.
 * */
t_datanode *datanode_create(int32_t id_datanode,int32_t sock_fd,char* ip_worker,int32_t puerto_worker,int32_t bloques_totales){
	log_trace(filesystem_log,"datanode_create->init");
	t_datanode * nuevo_datanode = malloc(sizeof(t_datanode));
	nuevo_datanode->datanode_id = id_datanode;
	nuevo_datanode->sock_fd = sock_fd;
	nuevo_datanode->ip_worker = string_new();
	string_append(&(nuevo_datanode->ip_worker),ip_worker);
	nuevo_datanode->puerto_worker = puerto_worker;
	nuevo_datanode->bloques_libres = bloques_totales;
	nuevo_datanode->bloques_totales = bloques_totales;
	pthread_mutex_init(&nuevo_datanode->mutex_bitmap, NULL);
	log_trace(filesystem_log,"datanode_create->end");
	return nuevo_datanode;
}
/*
 * Crea una estructura del tipo nodobloque.
 * */
t_nodobloque *nodobloque_create(int32_t id_datanode,int32_t num_bloque_nodo){
	log_trace(filesystem_log,"nodobloque_create->init");
	t_nodobloque * nuevo_nodo = malloc(sizeof(t_nodobloque));
	nuevo_nodo->id_nodo = id_datanode;
	nuevo_nodo->num_bloque_nodo = num_bloque_nodo;
	log_trace(filesystem_log,"nodobloque_create->end");
	return nuevo_nodo;
}

/*
 * Crea una estructura del tipo block.
 * */
t_block *bloque_create(int32_t num_bloque,int32_t fin_bloque){
	log_trace(filesystem_log,"bloque_create->init");
	t_block * nuevo_bloque = malloc(sizeof(t_block));
	nuevo_bloque->num_bloque = num_bloque;
	nuevo_bloque->fin_bloque = fin_bloque;
	nuevo_bloque->nodobloques = list_create();
	nuevo_bloque->cant_copias = 0;
	pthread_mutex_init(&nuevo_bloque->mutex_nodobloques,NULL);
	log_trace(filesystem_log,"bloque_create->end");
	return nuevo_bloque;
}
/*agrega un nodo bloque a un bloque*/
void add_nodobloque_a_bloque(t_block* bloque,t_nodobloque *nodob){
	log_trace(filesystem_log,"add_nodobloque_a_bloque->init");
	pthread_mutex_lock(&bloque->mutex_nodobloques);
	list_add(bloque->nodobloques,nodob);
	pthread_mutex_unlock(&bloque->mutex_nodobloques);
	log_trace(filesystem_log,"add_nodobloque_a_bloque->end");
}
/*Crea una estructura del tipo file*/
t_file *file_create(char* nombre_arch,long int size,t_file_type tipo,int32_t dir_padre){
	log_trace(filesystem_log,"file_create->init");
	t_file * nuevo_file = malloc(sizeof(t_file));
	nuevo_file->nombre = string_new();
	string_append(&nuevo_file->nombre,nombre_arch);
	nuevo_file->size = size;
	nuevo_file->directorio_padre = dir_padre;
	nuevo_file->tipo= tipo;
	nuevo_file->estado = DISPONIBLE;
	nuevo_file->bloques = list_create();
	pthread_mutex_init(&nuevo_file->mutex_bloques,NULL);
	log_trace(filesystem_log,"file_create->end");
	return nuevo_file;
}

void imprimir_nombre_archivo(t_file* arch){
	log_trace(filesystem_log,"imprimir_nombre_archivo->init");
	printf("%s\n",arch->nombre);
	log_trace(filesystem_log,"imprimir_nombre_archivo->end");
}

void imprimir_nombres_archivos(t_list* archivos){
	log_trace(filesystem_log,"imprimir_nombres_archivos->init");
	if(!list_is_empty(archivos)){
		list_iterate(archivos,(void*)imprimir_nombre_archivo);
	}
	log_trace(filesystem_log,"imprimir_nombres_archivos->end");
}

void listar_archivos_directorio(int index_dir){
	log_trace(filesystem_log,"listar_archivos_directorio->init");
	pthread_mutex_lock(&mutex_tabla_directorios);
	pthread_mutex_lock(&tabla_directorios[index_dir].mutex_archivos);
	imprimir_nombres_archivos(tabla_directorios[index_dir].archivos);
	pthread_mutex_unlock(&tabla_directorios[index_dir].mutex_archivos);
	pthread_mutex_unlock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"listar_archivos_directorio->end");
}

/*lista los nombres de los archivos de un directorios
 * 0->no existe el directorio
 * 1->ok
 * */
int ls_yama(char* path){
	int rta=0;
	int index_dir;
	log_trace(filesystem_log,"ls_yama->init");
	index_dir = validar_path(path);
	if(index_dir==0){
		log_error(filesystem_log,"ls_yama->el directorio no existe");
	}else{
		rta=1;
		listar_archivos_directorio(index_dir);
	}
	log_trace(filesystem_log,"ls_yama->end");
	return rta;
}


/*agrega un bloque a un file*/
void add_bloque_a_file(t_file *arch,t_block* bloque){
	log_trace(filesystem_log,"add_bloque_a_file->init");
	pthread_mutex_lock(&arch->mutex_bloques);
	list_add(arch->bloques,bloque);
	pthread_mutex_unlock(&arch->mutex_bloques);
	log_trace(filesystem_log,"add_bloque_a_file->end");
}

/*agrega un archivo a un directorio*/
void add_file_to_directory(int index_directory,t_file* arch){
	log_trace(filesystem_log,"add_file_to_directory->init");
	pthread_mutex_lock(&mutex_tabla_directorios);
	pthread_mutex_lock(&tabla_directorios[index_directory].mutex_archivos);
	list_add(tabla_directorios[index_directory].archivos,arch);
	pthread_mutex_unlock(&tabla_directorios[index_directory].mutex_archivos);
	pthread_mutex_unlock(&mutex_tabla_directorios);
	log_trace(filesystem_log,"add_file_to_directory->end");
}

/*destruye una estructura datanode*/
void datanode_destroy(t_datanode* dnode){
	log_trace(filesystem_log,"datanode_destroy->init");
	free(dnode->ip_worker);
	//bitarray_destroy();
	if(es_filesystem_estable()){
		bitarray_destroy(dnode->bitmap_array);
		if(munmap(dnode->bitmap_file, round_closest(dnode->bloques_totales, 8)) == -1) {
			log_error(filesystem_log,"datanode_destroy->error munmap");
		}
		//free(dnode->bitmap_file);
	}
	free(dnode);
	log_trace(filesystem_log,"datanode_destroy->end");
}

bool es_nodo_con_id(t_datanode* dnode){
	return (dnode->datanode_id==id_nodo_busqueda);
}

bool es_nodo_con_sock(t_datanode* dnode){
	return (dnode->sock_fd==socket_lectura_proceso);
}

bool es_nodobloque_con_id(t_nodobloque* dnode){
	return (dnode->id_nodo==id_nb_busqueda);
}

bool es_archivo_con_nombre(t_file* arch){
	if(!strcmp(arch->nombre, nombre_archivo_aux)){
		return true;
	}else{
		return false;
	}
}
/*suma a los bloques libres del sistema los bloques libre de un nodo*/
void sumar_a_bloques_libres(t_datanode* dnode){
	bloques_libres_sistema = bloques_libres_sistema + dnode->bloques_libres;
}
/*suma a los bloques totales del sistema los bloques libre de un nodo*/
void sumar_a_bloques_totales(t_datanode* dnode){
	bloques_totales_sistema = bloques_totales_sistema + dnode->bloques_totales;
}
/*actualiza los bloques libres del sistema*/
void actualizar_bloques_libres_sistema(){
	log_trace(filesystem_log,"actualizar_bloques_libres_sistema->init");
	pthread_mutex_lock(&mutex_bloques_libres_sistema);
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	bloques_libres_sistema=0;
	list_iterate(filesystem_datanodes_conectados,(void*)sumar_a_bloques_libres);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_unlock(&mutex_bloques_libres_sistema);
	log_trace(filesystem_log,"actualizar_bloques_libres_sistema->end");
}
/*actualiza los bloques totales del sistema*/
void actualizar_bloques_totales_sistema(){
	log_trace(filesystem_log,"actualizar_bloques_totales_sistema->init");
	pthread_mutex_lock(&mutex_bloques_libres_sistema);
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	bloques_totales_sistema=0;
	list_iterate(filesystem_datanodes_conectados,(void*)sumar_a_bloques_totales);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_unlock(&mutex_bloques_libres_sistema);
	log_trace(filesystem_log,"actualizar_bloques_totales_sistema->end");
}
/*escribe un nodo al archivo metadata correspondiente*/
void escribir_nodo(t_datanode* dnode){
	char* buffer = string_new();
	char* aux;
	string_append(&buffer, "Nodo");
	aux = string_itoa(dnode->datanode_id);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "Total=");
	aux =string_itoa(dnode->bloques_totales);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "\n");
	fwrite(buffer , sizeof(char) , string_length(buffer) , pSharedFile );
	free(buffer);
	buffer = string_new();
	string_append(&buffer, "Nodo");
	aux = string_itoa(dnode->datanode_id);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "Libre=");
	aux =string_itoa(dnode->bloques_libres);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "\n");
	fwrite(buffer , sizeof(char) , string_length(buffer) , pSharedFile );
	free(buffer);
}

/*Salva la informacion de todos los nodos al archivo metadata*/
void save_nodes_info_to_file(void){
	int i=0;
	FILE *pFileMetadata = NULL;
	t_datanode* dataNode;
	char* buffer;
	char *aux;
	log_trace(filesystem_log,"save_nodes_info_to_file->init");
	pFileMetadata = fopen(PATH_METADATA_NODES, "w");
	if(pFileMetadata == NULL)
	{
		log_error(filesystem_log,"save_nodes_info_to_file->Error al abrir el archivo %s donde se guarda la info de los nodos del sistema",PATH_METADATA_NODES);
	}else{
		pthread_mutex_lock(&mutex_pSharedFile);
		pSharedFile = pFileMetadata;
		buffer = string_new();
		string_append(&buffer, "TAMANIO=");
		aux =string_itoa(bloques_totales_sistema);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		buffer = string_new();
		string_append(&buffer, "LIBRE=");
		aux =string_itoa(bloques_libres_sistema);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
		buffer = string_new();
		string_append(&buffer, "NODOS=[");
		while(i<list_size(filesystem_datanodes_conectados)){
			dataNode = list_get(filesystem_datanodes_conectados,i);
			string_append(&buffer, "Nodo");
			aux = string_itoa(dataNode->datanode_id);
			string_append(&buffer, aux);
			free(aux);
			string_append(&buffer, ",");
			i++;
		}
		aux = string_substring(buffer, 0, string_length(buffer)-1);
		free(buffer);
		buffer = string_new();
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "]\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		list_iterate(filesystem_datanodes_conectados,(void*)escribir_nodo);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		free(buffer);
		pthread_mutex_unlock(&mutex_pSharedFile);
	}
	fclose(pFileMetadata);
	log_trace(filesystem_log,"save_nodes_info_to_file->end");
}

/*
 * actualizar_bloques_sistema:
 * Actualiza la cantidad de bloques libres y totales del sistema.
 * Tambien escribe esa informacion actualizada en el archivos
 * de nodos.
 * Esta funcion se debe llamar luego de que se escribe
 * o libera un bloque en algun nodo o llega un nodo.
 * */
void actualizar_bloques_sistema(void){
	log_trace(filesystem_log,"actualizar_bloques_sistema->init");
	actualizar_bloques_libres_sistema();
	actualizar_bloques_totales_sistema();
	save_nodes_info_to_file();
	log_trace(filesystem_log,"actualizar_bloques_sistema->end");
}

/*
 * actualiza los bloques libres de un nodo.
 * si no lo encuentra retorna 0
 * si pudo actualizar devuelve 1
 * */
int actualizar_bloques_libres_nodo(int32_t datanode_id,int valor){
	log_trace(filesystem_log,"actualizar_bloques_libres_nodo->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_lock(&mutex_id_nodo_busqueda);
	id_nodo_busqueda = datanode_id;
	t_datanode* dnode =list_find(filesystem_datanodes_conectados, (void*)es_nodo_con_id);
	if(dnode==NULL){
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		log_trace(filesystem_log,"actualizar_bloques_libres_nodo->no se encontro el nodo %d",datanode_id);
		return 0;
	}else{
		dnode->bloques_libres = valor;
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	}
	log_trace(filesystem_log,"actualizar_bloques_libres_nodo->se encontro el nodo %d y se seteo el valor %d como bloques libres", datanode_id,valor);
	log_trace(filesystem_log,"actualizar_bloques_libres_nodo->end");
	return 1;
}


bool es_proceso_aceptado(t_proceso_conectado *proceso_conectado){
	if(proceso_conectado->sock_fd == socket_lectura_proceso)return true;
	return false;
}

int buscar_en_procesos_aceptados(int sock_fd){
	log_trace(filesystem_log,"buscar_en_procesos_aceptados->init");
	pthread_mutex_lock(&mutex_filesystem_procesos_aceptados);
	pthread_mutex_lock(&mutex_socket_lectura_proceso);
	socket_lectura_proceso = sock_fd;
	t_list* procesos_encontrados=list_filter(filesystem_procesos_aceptados, (void*)es_proceso_aceptado);
	pthread_mutex_unlock(&mutex_socket_lectura_proceso);
	pthread_mutex_unlock(&mutex_filesystem_procesos_aceptados);
	if(list_is_empty(procesos_encontrados)){
		log_trace(filesystem_log,"buscar_en_procesos_aceptados->no se encontro el proceso %d",sock_fd);
		return 0;
	}
	log_trace(filesystem_log,"buscar_en_procesos_aceptados->se encontro el proceso %d",sock_fd);
	free(procesos_encontrados);
	log_trace(filesystem_log,"buscar_en_procesos_aceptados->end");
	return 1;
}
/*busca un nombre de archivo en la lista pasada por parametro*/
t_file* buscar_en_lista_de_archivos(char* nombre_arch,t_list* archivos){
	log_trace(filesystem_log,"buscar_en_lista_de_archivos->init");
	pthread_mutex_lock(&mutex_nombre_archivo_aux);
	string_append(&nombre_archivo_aux,nombre_arch);
	t_file* archivo=list_find(archivos, (void*)es_archivo_con_nombre);
	free(nombre_archivo_aux);
	nombre_archivo_aux = string_new();
	pthread_mutex_unlock(&mutex_nombre_archivo_aux);
	log_trace(filesystem_log,"buscar_en_lista_de_archivos->end");
	return archivo;
}
/*
 * busca un nombre de archivo en un directorio
 * 0->no existe
 * 1->existe
 * */
t_file* buscar_nombre_arch_en_dir(char* nombre_arch,int index_dir){
	t_file* archivo;
	log_trace(filesystem_log,"buscar_nombre_arch_en_dir->init");
	if(index_dir > 0){
		pthread_mutex_lock(&tabla_directorios[index_dir].mutex_archivos);
		archivo = buscar_en_lista_de_archivos(nombre_arch,tabla_directorios[index_dir].archivos);
		pthread_mutex_unlock(&tabla_directorios[index_dir].mutex_archivos);
	}else{
		archivo = NULL;
	}
	log_trace(filesystem_log,"buscar_nombre_arch_en_dir->end");
	return archivo;
}

//int validar_conexion_procesos(int sock_fd){
void validar_conexion_procesos(int sock_fd){
	log_trace(filesystem_log,"validar_conexion_procesos->init");
	t_mensaje_HANDSHAKE *msjeHandshake= malloc(sizeof(t_mensaje_HANDSHAKE));
	if(!recibir_handshake(msjeHandshake,sock_fd)){
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(filesystem_log,"validar_conexion_procesos->Error al recibir el mensaje de Handshake");
		pthread_mutex_unlock(&mutex_filesystem_log);
	}else{
		pthread_mutex_lock(&mutex_filesystem_estable);
		pthread_mutex_lock(&mutex_filesystem_log);
		log_trace(filesystem_log,"validar_conexion_procesos->Se recibio el mensaje de handshake");
		pthread_mutex_unlock(&mutex_filesystem_log);
		if(msjeHandshake->codigoHandshake == HANDSHAKE_DATANODE){
			pthread_mutex_lock(&mutex_filesystem_log);
			log_trace(filesystem_log,"validar_conexion_procesos->Proceso Datanode autenticado");
			pthread_mutex_unlock(&mutex_filesystem_log);
			if(!enviar_handshake(msjeHandshake,sock_fd)){
				pthread_mutex_lock(&mutex_filesystem_log);
				log_error(filesystem_log,"validar_conexion_procesos->Error al enviar la respuesta de Handshake al Dataode");
				pthread_mutex_unlock(&mutex_filesystem_log);
			}else{
				pthread_mutex_lock(&mutex_filesystem_log);
				log_trace(filesystem_log,"validar_conexion_procesos->Se envio la respuesta OK de handshake al Datanode");
				pthread_mutex_unlock(&mutex_filesystem_log);
				//que hago con los validos
				t_proceso_conectado* proc = proceso_conectado_create(sock_fd);
				agregar_a_procesos_validos(proc);
			}
			//para WORKER tambien es necesario verificar si el filesystem es estable
		}else if((msjeHandshake->codigoHandshake == HANDSHAKE_WORKER) && filesystem_estable){
			pthread_mutex_lock(&mutex_filesystem_log);
			log_trace(filesystem_log,"validar_conexion_procesos->Proceso Worker autenticado");
			pthread_mutex_unlock(&mutex_filesystem_log);
			msjeHandshake->codigoHandshake = HANDSHAKE_FS;
			if(!enviar_handshake(msjeHandshake,sock_fd)){
				pthread_mutex_lock(&mutex_filesystem_log);
				log_error(filesystem_log,"validar_conexion_procesos->Error al enviar la respuesta de Handshake al Worker");
				pthread_mutex_unlock(&mutex_filesystem_log);
			}else{
				pthread_mutex_lock(&mutex_filesystem_log);
				log_trace(filesystem_log,"validar_conexion_procesos->Se envio la respuesta OK de handshake al Worker");
				pthread_mutex_unlock(&mutex_filesystem_log);
				//que hago con los validos
				t_proceso_conectado* proc = proceso_conectado_create(sock_fd);
				agregar_a_procesos_validos(proc);
			}
			// para YAMA tambien es necesario verificar si el filesystem es estable
		}else if((msjeHandshake->codigoHandshake == HANDSHAKE_YAMA) && filesystem_estable){
			pthread_mutex_lock(&mutex_filesystem_log);
			log_trace(filesystem_log,"validar_conexion_procesos->Proceso Yama autenticado");
			pthread_mutex_unlock(&mutex_filesystem_log);
			if(!enviar_handshake(msjeHandshake,sock_fd)){
				pthread_mutex_lock(&mutex_filesystem_log);
				log_error(filesystem_log,"validar_conexion_procesos->Error al enviar la respuesta de Handshake a Yama");
				pthread_mutex_unlock(&mutex_filesystem_log);
			}else{
				pthread_mutex_lock(&mutex_filesystem_log);
				log_trace(filesystem_log,"validar_conexion_procesos->Se envio la respuesta OK de handshake al Yama");
				pthread_mutex_unlock(&mutex_filesystem_log);
				//que hago con los validos
				t_proceso_conectado* proc = proceso_conectado_create(sock_fd);
				agregar_a_procesos_validos(proc);
			}
		}else{
			pthread_mutex_lock(&mutex_filesystem_log);
			log_trace(filesystem_log,"validar_conexion_procesos->Proceso no autenticado");
			pthread_mutex_unlock(&mutex_filesystem_log);
			msjeHandshake->codigoHandshake = ERROR_HANDSHAKE;
			if(!enviar_handshake(msjeHandshake,sock_fd)){
				pthread_mutex_lock(&mutex_filesystem_log);
				log_error(filesystem_log,"validar_conexion_procesos->Error al enviar la respuesta de Handshake");
				pthread_mutex_unlock(&mutex_filesystem_log);
			}else{
				pthread_mutex_lock(&mutex_filesystem_log);
				log_trace(filesystem_log,"validar_conexion_procesos->Se envio la respuesta NO_OK de handshake");
				pthread_mutex_unlock(&mutex_filesystem_log);
			}
		}
		pthread_mutex_unlock(&mutex_filesystem_estable);
	}
	free(msjeHandshake);
}

/*Funcion que se ejecuta con cada proceso valido que se conecta
 * al FS*/

int recibir_mensajes_procesos(int sock_fd){
	int rta=1;
	t_mensaje_HEADER* msjeHeader;
	t_mensaje_nuevo_nodo* msjeNuevoNodo;
	t_msj_almacenamiento_final_fs* datosAlmacenamiento;
	t_mensaje_leer_escribir_nodo* mensaje_leer_escribir;
	t_datanode* dnode;
	char *nombre_archivo;
	char *path_yama;
	char* aux;
	char*buffer;
	int largo;
	t_list*lista_para_yama;

	//while(1){
	msjeHeader=malloc(sizeof(t_mensaje_HEADER));
	if(!recibir_mensaje_header(msjeHeader,sock_fd)){
		free(msjeHeader);
		eliminar_de_procesos_conectados(sock_fd);
		eliminar_de_datanodes_activos(sock_fd);
		actualizar_bloques_sistema();
		return 0;
	}
	switch(msjeHeader->codigoMensaje){
	case DATANODE_NUEVO_NODO:
		pthread_mutex_lock(&mutex_filesystem_log);
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion DATANODE_NUEVO_NODO init");
		pthread_mutex_unlock(&mutex_filesystem_log);
		msjeNuevoNodo = malloc(sizeof(t_mensaje_nuevo_nodo));
		//recibo la metadata para crear el nodo
		if(!recibirNuevoNodo(msjeNuevoNodo,sock_fd, msjeHeader->tamanio))return 0;
		log_trace(filesystem_log,"recibir_mensajes_procesos->se recibio la info del nuevo nodo");
		pthread_mutex_lock(&mutex_estado_anterior);
		if(estado_anterior == 1){
			//se recupera de un estado anterior
			//debo validar que el nodo pertenezca a esa ejecucion anterior
			pthread_mutex_lock(&mutex_id_nodo_busqueda);
			id_nodo_busqueda = msjeNuevoNodo->datanode_id;
			pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
			if(list_any_satisfy(filesystem_datanodes_conectados, (void*)es_nodo_con_id)){
				//pertenece
				//acepto conexion
				//tengo que obtener el nodo y completar sock,ip,puerto
				dnode = list_find(filesystem_datanodes_conectados,(void*)es_nodo_con_id);
				dnode->sock_fd=sock_fd;
				free(dnode->ip_worker);
				dnode->ip_worker = string_new();
				string_append(&dnode->ip_worker,msjeNuevoNodo->ip_nodo);
				dnode->puerto_worker=msjeNuevoNodo->puerto_worker;
				msjeHeader->codigoMensaje=DATANODE_NUEVO_NODO_ACEPTADO;
				if(!enviar_mensaje_header(msjeHeader,sock_fd)){
					pthread_mutex_lock(&mutex_filesystem_log);
					log_error(filesystem_log,"recibir_mensajes_procesos->operacion FILESYSTEM_VALIDAR_ARCHIVO - Error al enviar la respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
					pthread_mutex_unlock(&mutex_filesystem_log);
				}
				pthread_mutex_lock(&mutex_filesystem_estable);
				if(filesystem_estable==0){
					pthread_mutex_unlock(&mutex_filesystem_estable);
					//funcion que suma el nodo a copias
					sumar_nodo_cant_copias(id_nodo_busqueda);
					//funcion que valida si esta estable
					validar_y_setear_estable();
				}else{
					pthread_mutex_unlock(&mutex_filesystem_estable);
					//nada ya esta estable
				}

				log_trace(filesystem_log,"recibir_mensajes_procesos->se envio respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
			}else{
				//no pertenece
				//rechazo conexion
				msjeHeader->codigoMensaje=DATANODE_NUEVO_NODO_RECHAZADO;
				if(!enviar_mensaje_header(msjeHeader,sock_fd)){
					pthread_mutex_lock(&mutex_filesystem_log);
					log_error(filesystem_log,"recibir_mensajes_procesos->operacion FILESYSTEM_VALIDAR_ARCHIVO - Error al enviar la respuesta RECHAZADO al al datanode %d",msjeNuevoNodo->datanode_id);
					pthread_mutex_unlock(&mutex_filesystem_log);
				}
				log_trace(filesystem_log,"recibir_mensajes_procesos->se envio respuesta RECHAZADO al datanode %d",msjeNuevoNodo->datanode_id);
			}
			pthread_mutex_unlock(&mutex_id_nodo_busqueda);
			pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		}else{
			pthread_mutex_lock(&mutex_filesystem_estable);
			if(filesystem_estable == 1){
				//tengo que chequear si era uno de los que ya estaba conectado
				pthread_mutex_lock(&mutex_id_nodo_busqueda);
				id_nodo_busqueda = msjeNuevoNodo->datanode_id;
				pthread_mutex_lock(&mutex_filesystem_datanodes_desconectados);
				if(list_any_satisfy(filesystem_datanodes_desconectados, (void*)es_nodo_con_id)){
					//paso el nodo de la lista de desconectados a la lista de validos
					t_datanode *datanode_desconectado =list_find(filesystem_datanodes_desconectados, (void*)es_nodo_con_id);
					//lo remuevo de la lista de desconectados
					list_remove_by_condition(filesystem_datanodes_desconectados, (void*)es_nodo_con_id);
					pthread_mutex_unlock(&mutex_filesystem_datanodes_desconectados);
					pthread_mutex_unlock(&mutex_id_nodo_busqueda);
					log_trace(filesystem_log,"recibir_mensajes_procesos->nuevo nodo creado");
					//actualizo socket que cambio seguro
					datanode_desconectado->sock_fd = sock_fd;
					//lo agrego a los datanodes validos
					agregar_a_datanodes_validos(datanode_desconectado);
					//actualizo la info del sistema
					actualizar_bloques_sistema();
					log_trace(filesystem_log,"recibir_mensajes_procesos->se agrego el nuevo nodo a la lista de nodos activos");

					msjeHeader->codigoMensaje=DATANODE_NUEVO_NODO_ACEPTADO;
					if(!enviar_mensaje_header(msjeHeader,sock_fd)){
						pthread_mutex_lock(&mutex_filesystem_log);
						log_error(filesystem_log,"recibir_mensajes_procesos-> - Error al enviar la respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
						pthread_mutex_unlock(&mutex_filesystem_log);
					}
					log_trace(filesystem_log,"recibir_mensajes_procesos->se envio respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
					imprimir_datanodes_sistema();
				}else{
					pthread_mutex_unlock(&mutex_filesystem_datanodes_desconectados);
					pthread_mutex_unlock(&mutex_id_nodo_busqueda);
					//ya esta estable no acepto más nodos
					msjeHeader->codigoMensaje=DATANODE_NUEVO_NODO_RECHAZADO;
					if(!enviar_mensaje_header(msjeHeader,sock_fd)){
						pthread_mutex_lock(&mutex_filesystem_log);
						log_error(filesystem_log,"recibir_mensajes_procesos->operacion FILESYSTEM_VALIDAR_ARCHIVO - Error al enviar la respuesta RECHAZADO al al datanode %d",msjeNuevoNodo->datanode_id);
						pthread_mutex_unlock(&mutex_filesystem_log);
					}
					log_trace(filesystem_log,"recibir_mensajes_procesos->se envio respuesta RECHAZADO al datanode %d",msjeNuevoNodo->datanode_id);
				}
			}else{
				//creo el nodo
				t_datanode *datanode_nuevo =
						datanode_create(msjeNuevoNodo->datanode_id,sock_fd,msjeNuevoNodo->ip_nodo,msjeNuevoNodo->puerto_worker,msjeNuevoNodo->bloques_totales);
				log_trace(filesystem_log,"recibir_mensajes_procesos->nuevo nodo creado");
				//lo agrego a los datanodes validos
				agregar_a_datanodes_validos(datanode_nuevo);
				log_trace(filesystem_log,"recibir_mensajes_procesos->se agrego el nuevo nodo a la lista de nodos activos");

				msjeHeader->codigoMensaje=DATANODE_NUEVO_NODO_ACEPTADO;
				if(!enviar_mensaje_header(msjeHeader,sock_fd)){
					pthread_mutex_lock(&mutex_filesystem_log);
					log_error(filesystem_log,"recibir_mensajes_procesos->operacion FILESYSTEM_VALIDAR_ARCHIVO - Error al enviar la respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
					pthread_mutex_unlock(&mutex_filesystem_log);
				}
				log_trace(filesystem_log,"recibir_mensajes_procesos->se envio respuesta OK al datanode %d",msjeNuevoNodo->datanode_id);
				imprimir_datanodes_sistema();
			}
			pthread_mutex_unlock(&mutex_filesystem_estable);
		}
		pthread_mutex_unlock(&mutex_estado_anterior);

		//destruyo el mensaje, ya no lo necesito, tengo todos en la estructura datanode
		destroyMensajeNuevoNodo(msjeNuevoNodo);

		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion DATANODE_NUEVO_NODO end");
		break;
	case WORKER_FS_ENVIAR_ARCHIVO:
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion WORKER_FS_ENVIAR_ARCHIVO init");
		nombre_archivo=string_new();
		path_yama=string_new();
		datosAlmacenamiento = malloc(sizeof(t_msj_almacenamiento_final_fs));
		if(!recibirAlmacenamientoFinal(datosAlmacenamiento, sock_fd, msjeHeader->tamanio)) return 0;
		aux = obtener_nombre_archivo_path(datosAlmacenamiento->path_archivo);
		string_append(&nombre_archivo,aux);
		free(aux);
		string_append(&path_yama,string_substring(datosAlmacenamiento->path_archivo, 0, string_length(datosAlmacenamiento->path_archivo)-string_length(nombre_archivo)));
		if(almacenar_archivo(path_yama, nombre_archivo,datosAlmacenamiento->contenido_archivo,datosAlmacenamiento->contenido_archivo_largo)!=1){
			log_error(filesystem_log,"recibir_mensajes_procesos->error al escribir el archivo %s enviado por el worker",nombre_archivo);
			msjeHeader->codigoMensaje = FS_ALMACENAMIENTO_ERROR;
			msjeHeader->tamanio = 0;
		}else{
			log_trace(filesystem_log,"recibir_mensajes_procesos->se escribio el archivo %s correctamente",nombre_archivo);
			msjeHeader->codigoMensaje = FS_ALMACENAMIENTO_OK;
			msjeHeader->tamanio = 0;
		}
		if(!enviar_mensaje_header(msjeHeader, sock_fd)){
			pthread_mutex_lock(&mutex_filesystem_log);
			log_error(filesystem_log,"recibir_mensajes_procesos->operacion WORKER_FS_ENVIAR_ARCHIVO - Error al enviar la respuesta de la operacion");
			pthread_mutex_unlock(&mutex_filesystem_log);
		}
		//liberar el msje que llego
		free(datosAlmacenamiento->contenido_archivo);
		free(datosAlmacenamiento->path_archivo);
		free(nombre_archivo);
		free(path_yama);
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion WORKER_FS_ENVIAR_ARCHIVO end");
		break;
	case YAMA_SOLICITUD_ARCHIVO:
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion YAMA_SOLICITUD_ARCHIVO init");
		//recibimos el nombre del archivo
		buffer=malloc(msjeHeader->tamanio+1);
		recvall(sock_fd,buffer,msjeHeader->tamanio);

		nombre_archivo = string_new();
		//copiamos el nombre
		string_append(&nombre_archivo,buffer);
		nombre_archivo[msjeHeader->tamanio] = '\0';
		free(buffer);
		//realizamos el mapeo
		lista_para_yama = armarMapeoParaYama(nombre_archivo);

		if(list_size(lista_para_yama) >0){
			buffer =  serializarMsjYamaFs(lista_para_yama,&largo);
			msjeHeader->tamanio = largo;

		}else{
			msjeHeader->tamanio = -1;
			list_destroy(lista_para_yama);

		}

		if(enviar_mensaje_header(msjeHeader,sock_fd)){


			//envio el buffer con el contenido
			if(msjeHeader->tamanio!= -1){
				sendall(sock_fd,buffer,largo);
				log_trace(filesystem_log,"recibir_mensajes_procesos->operacion YAMA_SOLICITUD_ARCHIVO - Se envio exitosamente la solicitud de yama para archivo:s",nombre_archivo);
				list_destroy_and_destroy_elements(lista_para_yama,(void*)eliminarListaBloquePorArchivo);
				free(buffer);
			}


		}else{
			pthread_mutex_lock(&mutex_filesystem_log);
			log_error(filesystem_log,"recibir_mensajes_procesos->operacion YAMA_SOLICITUD_ARCHIVO - Error al enviar la respuesta de la operacion");
			pthread_mutex_unlock(&mutex_filesystem_log);

		}
		free(nombre_archivo);

		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion YAMA_SOLICITUD_ARCHIVO end");
		break;
	case DATANODE_LEER_BLOQUE:
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion DATANODE_LEER_BLOQUE init");
		//recibo el bloque
		buffer = malloc(msjeHeader->tamanio);
		log_trace(filesystem_log, "recibir_mensajes_procesos->operacion DATANODE_LEER_BLOQUE se recibe mensaje del nodo");
		if(recvall(sock_fd, buffer, msjeHeader->tamanio)){
			mensaje_leer_escribir = deserializarLeerEscribirNodo_COPIA(buffer);
			sem_post(&b_orden_lectura);
			//agrego el contenido al buffer;
			pthread_mutex_lock(&mutex_buffer_lectura);
			pthread_mutex_lock(&mutex_size_leer);
			pthread_mutex_lock(&mutex_cant_bloques_leer);
			log_trace(filesystem_log, "recibir_mensajes_procesos->operacion DATANODE_LEER_BLOQUE se recibe bloque %d",mensaje_leer_escribir->bloque_id);
			memcpy(buffer_lectura+offset_leer,mensaje_leer_escribir->buff_bloque,mensaje_leer_escribir->buff_bloque_size);
			//string_append(&buffer_lectura,mensaje_leer_escribir->buff_bloque);
			if(se_pide_md5){
				MD5_Update (&mdContext, mensaje_leer_escribir->buff_bloque, mensaje_leer_escribir->buff_bloque_size);
			}
			offset_leer = offset_leer+mensaje_leer_escribir->buff_bloque_size;
			if(cant_bloques_leer!=0){
				cant_bloques_leer = cant_bloques_leer -1;
				if(cant_bloques_leer==0){
					//se termino de leer, despierto al hilo de consola que
					//pidio leer
					sem_post(&b_lectura);
				}
			}
			pthread_mutex_unlock(&mutex_cant_bloques_leer);
			pthread_mutex_unlock(&mutex_size_leer);
			pthread_mutex_unlock(&mutex_buffer_lectura);
			free(mensaje_leer_escribir->buff_bloque);
		}
		free(mensaje_leer_escribir);
		free(buffer);
		log_trace(filesystem_log,"recibir_mensajes_procesos->operacion DATANODE_LEER_BLOQUE end");
		break;
	default:
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(filesystem_log,"recibir_mensajes_procesos->operacion desconocida");
		pthread_mutex_unlock(&mutex_filesystem_log);
		break;
	}
	free(msjeHeader);
	//}
	return rta;
}

bool esta_en_nodos_conectados(int nodo){
	t_datanode* nodo_resultado;

	bool buscarNodo(void* data){
		t_datanode* nodo_a_buscar = (t_datanode*)data;

		return nodo_a_buscar->datanode_id == nodo;

	}



	nodo_resultado = (t_datanode*)list_find(filesystem_datanodes_conectados,buscarNodo);

	if(nodo_resultado != NULL){
		return true;
	}else{
		return false;
	}



}

bool esta_nodo_en_lista(t_list* lista_retorno,int nodo){
	bloques_en_archivo* nodo_en_bloque_yama;

	bool esta_nodo(void* data){
		bloques_en_archivo* nodo1 = (bloques_en_archivo*) data;
		return nodo1->nodo == nodo;
	}

	nodo_en_bloque_yama = (bloques_en_archivo*)list_find(lista_retorno,esta_nodo);

	if(nodo_en_bloque_yama != NULL){
		return true;

	}else{
		return false;
	}


}

void borrarBloques(void*data){
	bloque* b1 = (bloque*) data;
	free(b1);

}



void eliminarListaBloquePorArchivo (void*data){
	bloques_en_archivo* bloque_en_archivo = (bloques_en_archivo*) data;
	free(bloque_en_archivo->nombre_archivo);
	free(bloque_en_archivo->ip);



	list_destroy_and_destroy_elements(bloque_en_archivo->bloques,(void*)borrarBloques);
	free(bloque_en_archivo);

}


t_list* armarMapeoParaYama( char* nombre_archivo_ruta_completa){
	int index_directorio;
	char* direcotorio_nombre_archivo;
	char *archivo_nombre;
	int index_tabla_bloques = 0;
	int tamanio_tabla_bloques;
	t_file* archivo;
	//nombre del directorio
	direcotorio_nombre_archivo= string_new();

	//lista que voy a retornar
	t_list* lista_retorno = list_create();

	//nombre del archivo
	archivo_nombre = string_new();
	//valido que exista el direcotrio y el archivo

	string_append(&archivo_nombre,obtener_nombre_archivo_path(nombre_archivo_ruta_completa));
	string_append(&direcotorio_nombre_archivo,string_substring(nombre_archivo_ruta_completa, 0, string_length(nombre_archivo_ruta_completa)-string_length(archivo_nombre)));
	index_directorio = validar_path(direcotorio_nombre_archivo);

	if(index_directorio == 0){
		log_error(filesystem_log,"la ruta:%s no existe",direcotorio_nombre_archivo);

	}else{
		archivo = buscar_nombre_arch_en_dir(archivo_nombre,index_directorio);
		if(archivo == NULL){
			log_error(filesystem_log,"el nombre del archivo:%s no existe",direcotorio_nombre_archivo);
		}else{
			//busco el archivo en el path de origen
			tamanio_tabla_bloques = list_size(archivo->bloques);
			t_block* bloque_fs;
			bloques_en_archivo* nodo_en_bloque_yama;
			t_nodobloque* nodoBlque_fs;
			int tamanio_nodoBloques;
			int index_nodoBloques = 0;
			//voy adentro de la lista de bloques
			while(tamanio_tabla_bloques > 0){

				bloque_fs =    (t_block*)list_get(archivo->bloques,index_tabla_bloques);

				tamanio_nodoBloques    = list_size(bloque_fs->nodobloques);
				index_nodoBloques = 0;
				//dentro de la lista blqoue ingreso a la lista de nodoBloques
				while(tamanio_nodoBloques > 0){
					nodo_en_bloque_yama = malloc(sizeof(bloques_en_archivo)); // ESTE ES EL DATO A AGREGAR

					nodoBlque_fs = (t_nodobloque*)list_get(bloque_fs->nodobloques,index_nodoBloques);

					//me fijo si esta en nodos conecatados
					if(esta_en_nodos_conectados(nodoBlque_fs->id_nodo)){
						//me fijo si esta en lista
						if(!esta_nodo_en_lista(lista_retorno,nodoBlque_fs->id_nodo)){
							//OBTENEMOS EL NODO
							t_datanode* nodo_resultado;

							bool buscarNodo(void* data){
								t_datanode* nodo_a_buscar = (t_datanode*)data;
								return nodo_a_buscar->datanode_id == nodoBlque_fs->id_nodo;

							}



							nodo_resultado = (t_datanode*)list_find(filesystem_datanodes_conectados,buscarNodo);
							//EMPIEZO A PEGAR LAS COSAS

							//MANDO NOMBRE DEL ARCHIVO
							nodo_en_bloque_yama->nombre_archivo = string_new();
							string_append(&nodo_en_bloque_yama->nombre_archivo,nombre_archivo_ruta_completa);
							//MANDO LARGO NOMBRE ARCHIVO
							nodo_en_bloque_yama->largo_nombre_Archivo = string_length(nodo_en_bloque_yama->nombre_archivo);

							//MANDO LA IP
							nodo_en_bloque_yama->ip = string_new();
							string_append(&nodo_en_bloque_yama->ip,nodo_resultado->ip_worker);

							// LARGO IP
							nodo_en_bloque_yama->largo_ip = string_length(nodo_en_bloque_yama->ip);

							//PUERTO
							nodo_en_bloque_yama->puerto = nodo_resultado->puerto_worker;

							//PONGO ID DEL NODO
							nodo_en_bloque_yama->nodo = nodo_resultado->datanode_id;

							//PONGO EL BLOQUE FICTICIO
							nodo_en_bloque_yama->bloques = list_create();
							bloque* bloque_yama = malloc(sizeof(bloque));
							bloque_yama->num_bloque_ficticio = bloque_fs->num_bloque;

							//PONGO LOS BYTES OCUPADOS
							bloque_yama->bytes_ocupados = bloque_fs->fin_bloque;

							//PONGO EL BLOQUE REAL

							bloque_yama->num_bloque_real = nodoBlque_fs->num_bloque_nodo;

							//agrego el bloque
							list_add(nodo_en_bloque_yama->bloques,(void*)bloque_yama);

							//agrego el nodo con los bloques
							list_add(lista_retorno,(void*)nodo_en_bloque_yama);

						}else{
							//obtengo el nodo que esta en la lista de retorno
							bool obtener_nodo_con_bloques(void*data){
								bloques_en_archivo* b1 = (bloques_en_archivo*) data;

								return b1->nodo == nodoBlque_fs->id_nodo;

							}

							bloques_en_archivo* nodo_con_bloques_encontrados =
									(bloques_en_archivo*) list_find(lista_retorno,obtener_nodo_con_bloques);

							//PONGO EL BLOQUE FICTICIO
							nodo_en_bloque_yama->bloques = list_create();
							bloque* bloque_yama = malloc(sizeof(bloque));
							bloque_yama->num_bloque_ficticio = bloque_fs->num_bloque;

							//PONGO LOS BYTES OCUPADOS
							bloque_yama->bytes_ocupados = bloque_fs->fin_bloque;


							//PONGO EL BLOQUE REAL
							bloque_yama->num_bloque_real = nodoBlque_fs->num_bloque_nodo;
							//agrego el bloque
							list_add(nodo_con_bloques_encontrados->bloques,(void*)bloque_yama);



						}

					}

					tamanio_nodoBloques--;
					index_nodoBloques++;
				}


				index_tabla_bloques++;
				tamanio_tabla_bloques--;

			}



		}

	}



	return lista_retorno;
}


void eliminar_de_procesos_conectados(int sock_fd){
	log_trace(filesystem_log,"eliminar_de_procesos_conectados-> init");
	pthread_mutex_lock(&mutex_filesystem_procesos_aceptados);
	pthread_mutex_lock(&mutex_socket_lectura_proceso);
	socket_lectura_proceso = sock_fd;
	list_remove_and_destroy_by_condition(filesystem_procesos_aceptados,(void*)es_proceso_aceptado,(void*)free);
	pthread_mutex_unlock(&mutex_socket_lectura_proceso);
	pthread_mutex_unlock(&mutex_filesystem_procesos_aceptados);
	log_trace(filesystem_log,"eliminar_de_procesos_conectados->Se elimino el proceso del socket %d",sock_fd);
	log_trace(filesystem_log,"eliminar_de_procesos_conectados-> end");
}

void eliminar_de_datanodes_activos(int sock_fd){
	log_trace(filesystem_log,"eliminar_de_datanodes_activos-> init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_lock(&mutex_socket_lectura_proceso);
	socket_lectura_proceso = sock_fd;
	t_datanode* dn = list_find(filesystem_datanodes_conectados,(void*)es_nodo_con_sock);
	if(dn!=NULL){
		log_trace(filesystem_log,"eliminar_de_datanodes_activos-> se agrega el datanode con sock_fd %d a la lista de desconectados",sock_fd);
		agregar_a_datanodes_validos_desconexion(dn);
	}
	list_remove_by_condition(filesystem_datanodes_conectados,(void*)es_nodo_con_sock);
	pthread_mutex_unlock(&mutex_socket_lectura_proceso);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"eliminar_de_datanodes_activos->Se elimino el datanode del socket %d",sock_fd);
	log_trace(filesystem_log,"eliminar_de_datanodes_activos-> end");
}

void handler_conexiones_a_filesystem(void *arg_sock){
	int *sock_fd=arg_sock;
	log_trace(filesystem_log,"handler_conexiones_a_filesystem->init");
	while(1){
		if(buscar_en_procesos_aceptados(*sock_fd)){
			log_trace(filesystem_log,"handler_conexiones_a_filesystem->proceso autenticado, se procede a escuchar mensajes");
			if(!recibir_mensajes_procesos(*sock_fd)){
				eliminar_de_procesos_conectados(*sock_fd);
				eliminar_de_datanodes_activos(*sock_fd);
				actualizar_bloques_sistema();
				break;
			}
		}else{
			log_trace(filesystem_log,"handler_conexiones_a_filesystem->proceso no autenticado, se procede a realizar el handshake");
			validar_conexion_procesos(*sock_fd);
		}
	}
	log_trace(filesystem_log,"handler_conexiones_a_filesystem->end");
}

void *escuchar_conexiones_filesystem(void* arg_escuchar_conexion){
	st_escuchar_conexion  *st_esc = arg_escuchar_conexion;
	log_trace(filesystem_log,"escuchar_conexiones_filesystem->init");
	if(!socket_multiplexing("127.0.0.1", st_esc->puerto, st_esc->cola, &validar_conexion_procesos, &recibir_mensajes_procesos,NULL,st_esc->logger)){
		//if (!socket_thread_per_connection( "127.0.0.1", st_esc->puerto , st_esc->cola, &handler_conexiones_a_filesystem,st_esc->logger)){
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(st_esc->logger,
				"escuchar_conexiones_filesystem -> la funcion socket_multiplexing devolvió error");
		pthread_mutex_unlock(&mutex_filesystem_log);
	}
	pthread_mutex_lock(&mutex_filesystem_log);
	log_trace(st_esc->logger,"Servidor Filesystem creado.");
	pthread_mutex_unlock(&mutex_filesystem_log);
	free(st_esc->puerto);
	free(st_esc);
	log_trace(filesystem_log,"escuchar_conexiones_filesystem->end");
	return NULL;
}

int crear_hilo_escuchar_conexiones_filesystem(t_log *logger){
	pthread_attr_t attr;
	pthread_t thread_per_connection;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	log_trace(filesystem_log,"crear_hilo_escuchar_conexiones_filesystem->init");
	//void *res;
	st_escuchar_conexion *arg_escuchar_conexion = malloc(sizeof(st_escuchar_conexion));
	arg_escuchar_conexion->cola = 50;
	pthread_mutex_lock(&mutex_filesystem_cfg);
	arg_escuchar_conexion->puerto = string_itoa(filesystem_cfg->puerto_filesystem);
	pthread_mutex_unlock(&mutex_filesystem_cfg);
	arg_escuchar_conexion->logger = filesystem_log;

	if (pthread_create(&thread_per_connection, &attr, &escuchar_conexiones_filesystem, (void*)arg_escuchar_conexion) < 0) {
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(logger,
				"crear_hilo_escuchar_conexiones_filesystem -> error al crear el hilo para atender conexiones");
		pthread_mutex_unlock(&mutex_filesystem_log);
		return 1;
	}
	if(!pthread_attr_destroy(&attr)){
		pthread_mutex_lock(&mutex_filesystem_log);
		log_trace(logger,
				"crear_hilo_escuchar_conexiones_filesystem-> hilo para atender conexiones creado");
		pthread_mutex_unlock(&mutex_filesystem_log);
	}else{
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(logger,
				"crear_hilo_escuchar_conexiones_filesystem -> fallo el pthread destroy");
		pthread_mutex_unlock(&mutex_filesystem_log);
		return 1;
	}
	log_trace(filesystem_log,"crear_hilo_escuchar_conexiones_filesystem->end");

	/*if(!pthread_join(thread_per_connection, &res)){
		log_trace(logger,
				"crear_hilo_escuchar_conexiones_filesystem -> hilo joineado");
	}else{
		log_error(logger,
				"crear_hilo_escuchar_conexiones_filesystem -> fallo el pthread join");
		return 1;
	}
	free(res);*/
	return 0;
}

/*funcion para el redondeo*/
unsigned int round_closest(unsigned int dividend, unsigned int divisor)
{
	//return (dividend + (divisor / 2)) / divisor;
	return ceil((dividend/divisor)+0.5);
}

/*crea el bitmap del datanode pasado por parametro
 * error retonar 0
 * ok retorna 1*/
int crear_bitmap_datanode(t_datanode* dnode){
	log_trace(filesystem_log,"crear_bitmap_datanode->init");
	char* nombre_bitmap = string_new();
	char* aux;
	int rta=0;
	FILE *fp;
	string_append(&nombre_bitmap,PATH_METADATA_BITMAP);
	string_append(&nombre_bitmap,"nodo");
	aux = string_itoa(dnode->datanode_id);
	string_append(&nombre_bitmap,aux);
	free(aux);
	string_append(&nombre_bitmap,".dat");
	fp = fopen(nombre_bitmap, "w");
	if(fp == NULL){
		log_error(filesystem_log,"Error al abrir el archivo %s donde se guarda el bitmap del nodo",nombre_bitmap);
	}else{
		if(ftruncate(fileno(fp), round_closest(dnode->bloques_totales, 8)) == -1){
			log_error(filesystem_log,"Error al truncar el archivo %s del nodo",nombre_bitmap);
		}else{
			rta = 1;
			log_trace(filesystem_log,"Archivo %s creado correctamente",nombre_bitmap);
		}
	}
	fclose(fp);
	free(nombre_bitmap);
	log_trace(filesystem_log,"crear_bitmap_datanode->end");
	return rta;
}

void crear_bitmap_datanode_v(t_datanode* dnode){
	log_trace(filesystem_log,"crear_bitmap_datanode->init");
	char* nombre_bitmap = string_new();
	char* aux;
	FILE *fp;
	string_append(&nombre_bitmap,PATH_METADATA_BITMAP);
	string_append(&nombre_bitmap,"nodo");
	aux = string_itoa(dnode->datanode_id);
	string_append(&nombre_bitmap,aux);
	free(aux);
	string_append(&nombre_bitmap,".dat");
	fp = fopen(nombre_bitmap, "w");
	if(fp == NULL){
		log_error(filesystem_log,"Error al abrir el archivo %s donde se guarda el bitmap del nodo",nombre_bitmap);
	}else{
		if(ftruncate(fileno(fp), round_closest(dnode->bloques_totales, 8)) == -1){
			log_error(filesystem_log,"Error al truncar el archivo %s del nodo",nombre_bitmap);
		}else{
			log_trace(filesystem_log,"Archivo %s creado correctamente",nombre_bitmap);
		}
	}
	fclose(fp);
	free(nombre_bitmap);
	log_trace(filesystem_log,"crear_bitmap_datanode->end");
}

/*mapea el bitmap al nodo pasado por parametro
 * y crea el bitarray
 * error -> retorna 0
 * ok-> retorna 1*/
int mapear_bitmap_a_nodo(t_datanode* dnode){
	int rta=1;
	char* nombre_bitmap = string_new();
	char *aux;
	log_trace(filesystem_log,"mapear_bitmap_a_nodo->init");
	string_append(&nombre_bitmap,PATH_METADATA_BITMAP);
	string_append(&nombre_bitmap,"nodo");
	aux =string_itoa(dnode->datanode_id);
	string_append(&nombre_bitmap,aux);
	free(aux);
	string_append(&nombre_bitmap,".dat");
	dnode->bitmap_file = map_file(nombre_bitmap,filesystem_log);
	if (dnode->bitmap_file == NULL) {
		log_error(filesystem_log, "mapearDisco->Error al mapear el archivo bitmap %s",nombre_bitmap);
		rta=0;
	}else{
		dnode->bitmap_array=bitarray_create_with_mode(dnode->bitmap_file,round_closest(dnode->bloques_totales, 8), LSB_FIRST);
		log_trace(filesystem_log,"cargar_bitarray->BITMAP creado exitosamente",nombre_bitmap);
	}
	log_trace(filesystem_log,"mapear_bitmap_a_nodo->end");
	free(nombre_bitmap);
	return rta;
}

void mapear_bitmap_a_nodo_v(t_datanode* dnode){
	char* nombre_bitmap = string_new();
	char *aux;
	log_trace(filesystem_log,"mapear_bitmap_a_nodo->init");
	string_append(&nombre_bitmap,PATH_METADATA_BITMAP);
	string_append(&nombre_bitmap,"nodo");
	aux =string_itoa(dnode->datanode_id);
	string_append(&nombre_bitmap,aux);
	free(aux);
	string_append(&nombre_bitmap,".dat");
	dnode->bitmap_file = map_file(nombre_bitmap,filesystem_log);
	if (dnode->bitmap_file == NULL) {
		log_error(filesystem_log, "mapearDisco->Error al mapear el archivo bitmap %s",nombre_bitmap);
	}else{
		dnode->bitmap_array=bitarray_create_with_mode(dnode->bitmap_file,round_closest(dnode->bloques_totales, 8), LSB_FIRST);
		log_trace(filesystem_log,"cargar_bitarray->BITMAP creado exitosamente",nombre_bitmap);
	}
	log_trace(filesystem_log,"mapear_bitmap_a_nodo->end");
	free(nombre_bitmap);
}

/*sincroniza el bitmap con el archivo de bitmap fisico*/
void actualizar_bitmap(t_datanode* dnode){
	log_trace(filesystem_log,"actualizar_bitmap->init");
	//sincronizo bitmap
	if (msync((void *)dnode->bitmap_file, round_closest(dnode->bloques_totales, 8), MS_SYNC) < 0) {
		log_error(filesystem_log,"actualizar_bitmap-> Error al sincronizar bitmap");
	}
	log_trace(filesystem_log,"actualizar_bitmap->end");
}

void liberar_bloque_bitmap(t_datanode* dnode,int numero_bloque){
	log_trace(filesystem_log,"liberar_bloque_bitmap->init");
	pthread_mutex_lock(&dnode->mutex_bitmap);
	bitarray_clean_bit(dnode->bitmap_array, numero_bloque);
	pthread_mutex_unlock(&dnode->mutex_bitmap);
	log_trace(filesystem_log,"liberar_bloque_bitmap->end");
}

void escribir_bloque_bitmap(t_datanode* dnode,int numero_bloque){
	log_trace(filesystem_log,"escribir_bloque_bitmap->init");
	pthread_mutex_lock(&dnode->mutex_bitmap);
	bitarray_set_bit(dnode->bitmap_array, numero_bloque);
	pthread_mutex_unlock(&dnode->mutex_bitmap);
	log_trace(filesystem_log,"escribir_bloque_bitmap->end");
}
/*obtiene un bloque libre del datanode pasado por parametro
 * si lo encuentra devuelve el número de bloque
 * caso contrario devuelve -1*/
int obtener_bloque_libre_nodo(t_datanode* dnode){
	int i=0;
	int numero_bloque=-1;
	int encontrado=0;
	log_trace(filesystem_log,"obtener_bloque_libre_nodo->init");
	pthread_mutex_lock(&dnode->mutex_bitmap);
	while((i<dnode->bloques_totales)&&(encontrado == 0)){
		if(bitarray_test_bit(dnode->bitmap_array, i)==0){
			encontrado = 1;
			numero_bloque = i;
		}
		i++;
	}
	pthread_mutex_unlock(&dnode->mutex_bitmap);
	log_trace(filesystem_log,"obtener_bloque_libre_nodo->end");
	return numero_bloque;
}

t_file_type determinar_tipo_archivo(char* nombre_arch){
	t_file_type tipo;
	int i=0;
	log_trace(filesystem_log,"determinar_tipo_archivo->init");
	char**nombre_spliteado = string_split(nombre_arch, ".");
	while(nombre_spliteado[i]!=NULL){
		i++;
	}
	if(i==2){
		if(string_equals_ignore_case(nombre_spliteado[1], "csv")||string_equals_ignore_case(nombre_spliteado[1], "txt")){
			tipo = DELIMITADO;
		}else{
			tipo = BINARIO;
		}
	}else{
		tipo = BINARIO;
	}
	i=0;
	while(nombre_spliteado[i]!=NULL){
		free(nombre_spliteado[i]);
		i++;
	}
	free(nombre_spliteado);
	log_trace(filesystem_log,"determinar_tipo_archivo->end");
	return tipo;
}
/*
 * si existe el directorio devuleve 1, caso contrario 0
 * */

int existe_directorio(char* path){
	int rta = 1;
	log_trace(filesystem_log,"existe_directorio->init");
	struct stat st = {0};
	if (stat(path, &st) == -1) {
		rta = 0;
	}
	log_trace(filesystem_log,"existe_directorio->end");
	return rta;
}

/*crea el directorio de metadata para los archivos*/
void crea_directorio_metadata(char*path){
	log_trace(filesystem_log,"crea_directorio_metadata->init");
	struct stat st = {0};
	if (stat(path, &st) == -1) {
		mkdir(path, 0700);
	}
	log_trace(filesystem_log,"crea_directorio_metadata->end");
}

char* file_type_to_string(t_file_type tipo){
	log_trace(filesystem_log,"file_type_to_string->init");
	char* retorno = string_new();
	if(tipo == DELIMITADO){
		string_append(&retorno,"DELIMITADO");
	}else{
		string_append(&retorno,"BINARIO");
	}
	log_trace(filesystem_log,"file_type_to_string->end");
	return retorno;
}

char* file_state_to_string(t_file_state tipo){
	log_trace(filesystem_log,"file_state_to_string->init");
	char* retorno = string_new();
	if(tipo == DISPONIBLE){
		string_append(&retorno,"DISPONIBLE");
	}else{
		string_append(&retorno,"NO DISPONIBLE");
	}
	log_trace(filesystem_log,"file_state_to_string->end");
	return retorno;
}

void escribir_nodobloque_metadata(t_nodobloque* nodob){
	log_trace(filesystem_log,"escribir_nodobloque_metadata->init");
	char* buffer = string_new();
	char* aux;
	string_append(&buffer, "[");
	string_append(&buffer, "Nodo");
	aux = string_itoa(nodob->id_nodo);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, ",");
	aux = string_itoa(nodob->num_bloque_nodo);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "]");
	string_append(&buffer, "\n");
	fwrite(buffer , sizeof(char) , string_length(buffer) , pSharedFile );
	free(buffer);
	log_trace(filesystem_log,"escribir_nodobloque_metadata->end");
}

void escribir_bloque_metadata(t_block* bl){
	int i=0;
	char* buffer;
	char* aux;
	log_trace(filesystem_log,"escribir_bloque_metadata->init");
	while(i<list_size(bl->nodobloques)){
		buffer = string_new();
		string_append(&buffer, "BLOQUE");
		aux = string_itoa(bl->num_bloque);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "COPIA");
		aux =string_itoa(i);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "=");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pSharedFile );
		escribir_nodobloque_metadata(list_get(bl->nodobloques,i));
		free(buffer);
		i++;
	}
	buffer = string_new();
	string_append(&buffer, "BLOQUE");
	aux = string_itoa(bl->num_bloque);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "BYTES");
	string_append(&buffer, "=");
	aux = string_itoa(bl->fin_bloque);
	string_append(&buffer, aux);
	free(aux);
	string_append(&buffer, "\n");
	fwrite(buffer , sizeof(char) , string_length(buffer) , pSharedFile );
	free(buffer);
	log_trace(filesystem_log,"escribir_bloque_metadata->end");
}
void escribir_bloques_metadata(t_list* bloques){
	log_trace(filesystem_log,"escribir_bloques_metadata->init");
	list_iterate(bloques,(void*)escribir_bloque_metadata);
	log_trace(filesystem_log,"escribir_bloques_metadata->end");
}

/*Guarda un archivo en el archivo metadata correspondiente*/
void save_file_info_to_file(t_file* arch){
	FILE *pFileMetadata = NULL;
	char* buffer;
	char* path_file=string_new();
	char* aux;
	string_append(&path_file,PATH_METADATA_FILES);
	aux =string_itoa(arch->directorio_padre);
	string_append(&path_file,aux);
	free(aux);
	string_append(&path_file,"/");
	//creo directorio donde se crea la metadata , id directorio padre
	crea_directorio_metadata(path_file);
	string_append(&path_file,arch->nombre);
	log_trace(filesystem_log,"save_file_info_to_file->init");
	pFileMetadata = fopen(path_file, "w");
	if(pFileMetadata == NULL)
	{
		log_error(filesystem_log,"save_file_info_to_file->Error al abrir el archivo %s donde se guarda la info del archivo",path_file);
	}else{
		pthread_mutex_lock(&mutex_pSharedFile);
		pSharedFile = pFileMetadata;
		string_append(&path_file,"\n");
		fwrite(path_file , sizeof(char) , string_length(path_file) , pFileMetadata );
		free(path_file);
		buffer = string_new();
		string_append(&buffer, "TAMANIO=");
		aux = string_itoa(arch->size);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		buffer = string_new();
		string_append(&buffer, "TIPO=");
		aux = file_type_to_string(arch->tipo);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		buffer = string_new();
		string_append(&buffer, "ESTADO=");
		aux = file_state_to_string(arch->estado);
		string_append(&buffer, aux);
		free(aux);
		string_append(&buffer, "\n");
		fwrite(buffer , sizeof(char) , string_length(buffer) , pFileMetadata );
		free(buffer);
		pthread_mutex_lock(&arch->mutex_bloques);
		escribir_bloques_metadata(arch->bloques);
		pthread_mutex_unlock(&arch->mutex_bloques);
		pthread_mutex_unlock(&mutex_pSharedFile);
	}
	fclose(pFileMetadata);
	log_trace(filesystem_log,"save_file_info_to_file->end");
}
/*Lee el archivo pasado por parametro
 * error retorna 0
 * ok retorna 1*/
int read_entire_file_text(char* filepath,char** buffer, long int *file_size){
	log_trace(filesystem_log,"read_entire_file->init");
	int rta = 1;
	FILE *f = fopen(filepath, "rb");
	if(f==NULL){
		rta=0;
	}else{
		fseeko(f, 0, SEEK_END);
		long fsize = ftello(f);
		*file_size = fsize;
		fseeko(f, 0, SEEK_SET);

		free(*buffer);
		*buffer = malloc(fsize + 1);
		//char *string = malloc(fsize + 1);
		fread(*buffer, fsize, 1, f);
		//buffer[fsize+1]='\0';
		//string_append(buffer,string);
		//free(string);
		fclose(f);
	}
	log_trace(filesystem_log,"read_entire_file->end");
	return rta;
}

int read_entire_file_binary(char* filepath,char** buffer, long int *file_size){
	log_trace(filesystem_log,"read_entire_file_binary->init");
	int rta = 1;
	FILE *f = fopen(filepath, "rb");
	if(f==NULL){
		rta=0;
	}else{
		fseeko(f, 0, SEEK_END);
		long fsize = ftello(f);
		*file_size = fsize;
		fseeko(f, 0, SEEK_SET);
		fclose(f);

		char *string = map_file(filepath,filesystem_log);
		string_append(buffer,string);
		free(string);

	}
	log_trace(filesystem_log,"read_entire_file_binary->end");
	return rta;
}

/*Lee una linea del buffer pasado por parametro,
 * desde el offset pasador por parametro
 * Devuelve la cantidad de caracteres leidos
 * */
int my_getline_from_buffer(char* buffer,char** line,long int offset){
	//log_trace(filesystem_log,"my_getline_from_buffer->init");
	int string_size=0;
	char* chreaded=NULL;
	buffer=buffer+offset;
	chreaded = string_substring_until(buffer, 1);
	while(*buffer != '\0' && *chreaded != '\n' && *chreaded != EOF){
		string_append(line,chreaded);
		string_size++;
		buffer=buffer+1;
		free(chreaded);
		chreaded = string_substring_until(buffer, 1);
	}
	if(*buffer == '\0' || *chreaded==EOF){
		string_size=-1;
	}else{
		if(*chreaded=='\n'){
			string_size++;
			string_append(line,"\n");
		}
	}
	free(chreaded);
	//log_trace(filesystem_log,"my_getline_from_buffer->end");
	return string_size;
}

int my_getline_binary_from_buffer(char* buffer,char** line,long int offset,int block_size){
	log_trace(filesystem_log,"my_getline_binary_from_buffer->init");
	int string_size=0;
	char* chreaded=NULL;
	buffer=buffer+offset;
	chreaded = string_substring_until(buffer, 1);
	while(string_size<block_size && *chreaded != EOF){
		string_append(line,chreaded);
		string_size++;
		buffer=buffer+1;
		free(chreaded);
		chreaded = string_substring_until(buffer, 1);
	}

	free(chreaded);
	log_trace(filesystem_log,"my_getline_binary_from_buffer->end");
	return string_size;
}


/*Lee del buffer pasado por parametro la cantidad especificada por
 * length, desde el ofsset pasado por parametro
 * Devuelve la cantidad leida*/
int my_read_from_buffer(char* buffer,char** line,long int offset,long int length,long int file_size){
	//log_trace(filesystem_log,"my_read_from_buffer->init");
	int minimo = -1;
	if(file_size-offset != 0){
		if(file_size-offset > length){
			minimo = length;
		}else{
			minimo = file_size-offset;
		}
		//strncpy(*line, buffer+offset, minimo);
		memcpy(*line, buffer+offset,minimo);
	}
	//log_trace(filesystem_log,"my_read_from_buffer->end");
	return minimo;
}

/*
 * lee un buffer que representa un archivo y devuelve
 * el bloque leido, la cantidad de bytes del bloque
 * */
int lee_y_corta_bloque_archivo(char* archString,long int *offset,char** bloque_leido,t_file_type tipo_arch,int block_size,long int file_size){
	int leido=0;
	int terminado=0;
	char *linea=NULL;
	int read=0;
	//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->init");
	if(tipo_arch==DELIMITADO){
		*bloque_leido=string_new();
		linea = string_new();
		while (leido<=block_size && !terminado){
			if((read = my_getline_from_buffer_mejorado(archString,&linea,*offset)) != -1){
				if((leido + read) <= block_size){
					leido = leido + read;
					*offset= *offset + read;
					string_append(bloque_leido,linea);
					//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->se lee una linea del archivo delimitado");
				}else{
					//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->se supera el tamaño de bloque, se termina de leer");
					terminado = 1;
				}
			}else{
				terminado = 1;
				//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->fin de archivo delimitado");
			}
			free(linea);
			linea = string_new();
		}
	}else{
		*bloque_leido=malloc(sizeof(char)*block_size);
		linea = malloc(sizeof(char)*block_size);
		//if((read = my_getline_binary_from_buffer(archString,&linea,*offset,block_size)) != -1){
		if((read = my_read_from_buffer(archString,&linea,*offset,block_size,file_size)) != -1){
			leido = leido + read;
			*offset = *offset + read;
			memcpy(*bloque_leido,linea,(sizeof(char)*block_size));
			//string_append(bloque_leido,linea);
			//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->leyendo un bloque archivo binario");
		}
	}
	free(linea);
	//log_trace(filesystem_log,"lee_y_corta_bloque_archivo->end");
	return	leido;
}

/*Devuelve la cantidad de datanodes con "cant_bloques" libres*/
int hay_minimo_datanodes_libres(unsigned int cant_bloques){
	int i;
	int cant=0;
	t_datanode* nodo;
	log_trace(filesystem_log,"hay_minimo_datanodes_libres->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_lock(&mutex_bloques_libres_sistema);
	if(!list_is_empty(filesystem_datanodes_conectados)&&bloques_libres_sistema>=cant_bloques*2){
		for(i=0;i<list_size(filesystem_datanodes_conectados);i++){
			nodo = list_get(filesystem_datanodes_conectados,i);
			//if(nodo->bloques_libres>cant_bloques){
			if(nodo->bloques_libres>0){
				cant++;
			}
		}
	}
	pthread_mutex_unlock(&mutex_bloques_libres_sistema);

	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"hay_minimo_datanodes_libres->end");
	return cant;
}
/*toma el primer datanode de la lista de datanodes activos
 * y lo vuelve a poner al final de la lista (cola circular)*/
t_datanode *tomar_y_agregar_al_final_datanode(){
	t_datanode* nodo;
	log_trace(filesystem_log,"tomar_y_agregar_al_final_datanode->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	if(list_is_empty(filesystem_datanodes_conectados)){
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		log_trace(filesystem_log,"tomar_datanode -> lista de datanodes vacia");
		nodo = NULL;
	}else{
		nodo = list_remove(filesystem_datanodes_conectados, 0);
		list_add(filesystem_datanodes_conectados,nodo);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		log_trace(filesystem_log,"tomar_datanode -> nodo %d tomado y removido de la lista",nodo->datanode_id);
	}
	log_trace(filesystem_log,"tomar_y_agregar_al_final_datanode->end");
	return nodo;
}
/*buscan un datanode de la lista con el node_id
 distinto del argumento , si lo encuentra busca un bloque
 dentro del nodo, lo setea ocupado y actualiza estructuras.
 Retorna un nodo bloque.
 Si no pudo hacerlo retorna null.
 */
t_nodobloque* buscar_datanode_a_usar (int distinto_de){
	t_nodobloque* nb=NULL;
	t_datanode * nodo;
	int bloque;
	int encontrado = 0;
	int cant = 0;
	log_trace(filesystem_log,"buscar_datanode_a_usar->init");
	//busco datanode
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	while(!encontrado && cant<list_size(filesystem_datanodes_conectados)){
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		nodo = tomar_y_agregar_al_final_datanode();
		if((nodo != NULL) && (nodo->datanode_id != distinto_de) && (nodo->bloques_libres>0)){
			encontrado = 1;
		}
		cant++;
	}
	if(encontrado){
		//busco bloque en bitmap
		bloque = obtener_bloque_libre_nodo(nodo);
		if(bloque != -1){
			//bloque encontrado , lo seteo ocupado
			escribir_bloque_bitmap(nodo,bloque);
			//sincronizo mapeado
			actualizar_bitmap(nodo);
			//actualizo bloque libres nodo
			if(!actualizar_bloques_libres_nodo(nodo->datanode_id,nodo->bloques_libres-1)){
				log_error(filesystem_log,"buscar_datanode_a_usar->error al actualizar informacion del nodo");
			}else{
				nb = nodobloque_create(nodo->datanode_id,bloque);
			}
		}
	}
	log_trace(filesystem_log,"buscar_datanode_a_usar->end");
	return nb;
}
/*libera el bloque apuntado por un nodobloque*/
void liberar_nodobloque(t_nodobloque* nb){
	log_trace(filesystem_log,"liberar_nodobloque->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	pthread_mutex_lock(&mutex_id_nodo_busqueda);
	id_nodo_busqueda = nb->id_nodo;
	t_datanode* dnode =list_find(filesystem_datanodes_conectados, (void*)es_nodo_con_id);
	if(dnode==NULL){
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		log_error(filesystem_log,"liberar_nodobloque->no se encontro el nodo %d",nb->id_nodo);
	}else{
		liberar_bloque_bitmap(dnode,nb->num_bloque_nodo);
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		if(!actualizar_bloques_libres_nodo(dnode->datanode_id,dnode->bloques_libres+1)){
			log_error(filesystem_log,"liberar_nodobloque->error al actualizar informacion del nodo");
		}
	}
	log_trace(filesystem_log,"liberar_nodobloque->end");
}

void liberar_nodos_bloques(t_list* nodosb){
	log_trace(filesystem_log,"liberar_nodos_bloques->init");
	list_iterate(nodosb,(void*)liberar_nodobloque);
	log_trace(filesystem_log,"liberar_nodos_bloques->end");
}

/*Devuelve una lista con 2 nodosbloques de distinto nodo
 * en caso de error retorna lista vacia*/
t_list* obtener_nodos_bloque(){
	t_list* lista_nb = list_create();
	t_nodobloque* nodo_bloque;
	int cant = 0;
	int error = 0;
	int datanode_usado=-1;
	log_trace(filesystem_log,"obtener_nodos_bloque->init");
	if(hay_minimo_datanodes_libres(1) >= 2){
		while(cant<2 && !error){
			nodo_bloque= buscar_datanode_a_usar(datanode_usado);
			if(nodo_bloque!=NULL){
				list_add(lista_nb,nodo_bloque);
				datanode_usado = nodo_bloque->id_nodo;
				cant ++;
			}else{
				error = 1;
			}
		}
	}
	log_trace(filesystem_log,"obtener_nodos_bloque->end");
	return lista_nb;
}

/*recibe una lista de nodobloques, un tamano de data, y el buffer con los datos
 * envia a todos los datanode de la lista el mensaje para que escriban
 * el buffer pasado por parametro en el bloque especificado dentro del nodobloque*/
int enviar_mensaje_escritura_datanodes(t_list* nodob, int size_data,char* data){
	int rta=0;
	int error=0;
	int i=0;
	t_nodobloque* nb;
	t_datanode* dnode;
	t_mensaje_HEADER *msjeHeader=malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_leer_escribir_nodo *msjeEscribir;
	int32_t msjLargo = 0;

	msjeHeader->codigoMensaje = DATANODE_ESCRIBIR_BLOQUE;
	log_trace(filesystem_log,"enviar_mensaje_datanodes->init");
	log_trace(filesystem_log,"enviar_mensaje_datanodes->size_data: %d",size_data);
	//por cada nodobloque
	while(!error && i<list_size(nodob)){
		nb = list_get(nodob,i);
		//busco el datanode
		pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
		pthread_mutex_lock(&mutex_id_nodo_busqueda);
		id_nodo_busqueda = nb->id_nodo;
		dnode =list_find(filesystem_datanodes_conectados, (void*)es_nodo_con_id);
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		if(dnode==NULL){
			log_trace(filesystem_log,"enviar_mensaje_datanodes->no se encontro el nodo %d",nb->id_nodo);
			error=1;
		}else{
			//envio los mensajes
			//pthread_mutex_lock(&mutex_enviar_mensajes);
			log_trace(filesystem_log,"enviar_mensaje_datanodes->datanode %d encontrado,se envia mensaje",nb->id_nodo);
			msjeEscribir = malloc(sizeof(t_mensaje_leer_escribir_nodo));
			msjeEscribir->bloque_id = nb->num_bloque_nodo;
			msjeEscribir->buff_bloque_size = size_data;
			//msjeEscribir->buff_bloque = string_new();
			msjeEscribir->buff_bloque = malloc(size_data);
			memcpy(msjeEscribir->buff_bloque,data,size_data);
			//string_append(&msjeEscribir->buff_bloque,data);
			char* packReducirGlobal = serializarLeerEscribirNodo_COPIA(msjeEscribir, &msjLargo);
			msjeHeader->tamanio = msjLargo;

			if(!enviar_mensaje_header(msjeHeader,dnode->sock_fd)){
				log_error(filesystem_log,"enviar_mensaje_datanodes->error al enviar mensaje header para el nodo %d",nb->id_nodo);
				error=1;
			}
			log_trace(filesystem_log,"enviar_mensaje_datanodes-> se envio mensaje header al datanode %d ",nb->id_nodo);
			log_trace(filesystem_log,"enviar_mensaje_datanodes-> size_data: %d",size_data);
			if(!sendall(dnode->sock_fd,packReducirGlobal, msjLargo)){
				log_error(filesystem_log,"enviar_mensaje_datanodes->error al enviar mensaje escribir para el nodo %d",nb->id_nodo);
			}
			free(packReducirGlobal);
			log_trace(filesystem_log,"enviar_mensaje_datanodes-> se envio mensaje escribir al datanode %d ",nb->id_nodo);
			//pthread_mutex_unlock(&mutex_enviar_mensajes);
			i++;
			free(msjeEscribir->buff_bloque);
			free(msjeEscribir);
		}
	}
	if(error==0){
		rta = 1;
	}
	free(msjeHeader);
	log_trace(filesystem_log,"enviar_mensaje_datanodes->end");
	return rta;
}

int enviar_mensaje_lectura_datanodes(t_list* nodob,t_list* bloques){
	int rta=0;
	int error=0;
	int i=0;
	t_nodobloque* nb;
	char* packReducirGlobal;
	t_block* bl;
	t_datanode* dnode;
	t_mensaje_HEADER *msjeHeader=malloc(sizeof(t_mensaje_HEADER));
	t_mensaje_leer_escribir_nodo *msjeEscribir;
	int32_t msjLargo = 0;

	msjeHeader->codigoMensaje = DATANODE_LEER_BLOQUE;
	log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes->init");
	//por cada nodobloque
	while(!error && i<list_size(nodob)){
		bl = list_get(bloques,i);
		nb = list_get(nodob,i);
		//busco el datanode
		pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
		pthread_mutex_lock(&mutex_id_nodo_busqueda);
		id_nodo_busqueda = nb->id_nodo;
		dnode =list_find(filesystem_datanodes_conectados, (void*)es_nodo_con_id);
		pthread_mutex_unlock(&mutex_id_nodo_busqueda);
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		if(dnode==NULL){
			log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes->no se encontro el nodo %d",nb->id_nodo);
			error=1;
		}else{
			//envio los mensajes
			//pthread_mutex_lock(&mutex_enviar_mensajes);
			log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes->datanode %d encontrado,se envia mensaje",nb->id_nodo);
			msjeEscribir = malloc(sizeof(t_mensaje_leer_escribir_nodo));
			msjeEscribir->bloque_id = nb->num_bloque_nodo;
			msjeEscribir->buff_bloque_size = bl->fin_bloque;
			msjeEscribir->buff_bloque = NULL;
			packReducirGlobal = serializarLeer(msjeEscribir, &msjLargo);
			msjeHeader->tamanio = msjLargo;

			if(!enviar_mensaje_header(msjeHeader,dnode->sock_fd)){
				log_error(filesystem_log,"enviar_mensaje_lectura_datanodes->error al enviar mensaje header para el nodo %d",nb->id_nodo);
				error=1;
			}
			log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes-> se envio mensaje header al datanode %d ",nb->id_nodo);
			if(!sendall(dnode->sock_fd,packReducirGlobal, msjLargo)){
				error=1;
				log_error(filesystem_log,"enviar_mensaje_lectura_datanodes->error al enviar mensaje leer para el nodo %d",nb->id_nodo);
			}
			//para sincronizar la lectura
			sem_wait(&b_orden_lectura);
			free(packReducirGlobal);
			log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes-> se envio mensaje leer al datanode %d ",nb->id_nodo);
			//pthread_mutex_unlock(&mutex_enviar_mensajes);
			i++;
			free(msjeEscribir);
		}
	}
	if(error==0){
		rta = 1;
	}
	free(msjeHeader);
	log_trace(filesystem_log,"enviar_mensaje_lectura_datanodes->end");
	return rta;
}

/*obtiene la cantidad de bloques que ocupa un archivo, bloques de 1MB*/
unsigned int obtener_cantidad_de_bloques(long int size_bytes){
	return (round_closest(size_bytes, BLOCK_SIZE));
}

void obtener_lista_nodobloques_lectura(t_list** historial,t_list* bloques){
	log_trace(filesystem_log,"obtener_lista_nodobloques_lectura->init");
	int i,j=0;
	int encontrado=0;
	t_list* hist_int=list_create();
	t_block* bl;
	t_nodobloque* nb;
	if(list_size(bloques)>0){
		//recorro bloques
		for(i=0;i<list_size(bloques);i++){
			//obtengo el bloque i
			bl = list_get(bloques,i);
			pthread_mutex_lock(&bl->mutex_nodobloques);
			while(j<list_size(bl->nodobloques) && !encontrado){
				//si lista es vacia agarro el primero
				nb = list_get(bl->nodobloques,j);
				if(list_size(hist_int) == 0){
					list_add(hist_int,nb);
					encontrado = 1;
				}else{
					//tengo que comparar con lo que hay en la lista historial
					pthread_mutex_lock(&mutex_id_nb_busqueda);
					id_nb_busqueda = nb->id_nodo;
					t_list* encontrados =list_filter(hist_int, (void*)es_nodobloque_con_id);
					if(list_size(encontrados)==0){
						//no existe en historial, lo elijo
						list_add(hist_int,nb);
						encontrado = 1;
					}else{
						//ya existe sigo con el siguiente nodobloque
						j++;
					}
					pthread_mutex_unlock(&mutex_id_nb_busqueda);
				}
				pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
				if(list_size(hist_int)==list_size(filesystem_datanodes_conectados)){
					list_add_all(*historial,hist_int);
					list_clean(hist_int);
				}
				pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
			}
			pthread_mutex_unlock(&bl->mutex_nodobloques);
			//si se recorrio toda la lista de nodobloques y
			//no pudo encontrar distinto devuelvo el primero
			if((list_size(bl->nodobloques)==j) && !encontrado){
				nb = list_get(bl->nodobloques,0);
				list_add(hist_int,nb);
			}
			j=0;
			encontrado=0;
		}
	}
	if((list_size(bloques) % 2)==0){
		list_add_all(*historial,hist_int);
		list_clean(hist_int);
	}else{
		if(list_size(bloques) == 1){
			list_add_all(*historial,hist_int);
			list_clean(hist_int);
		}
	}
	list_destroy(hist_int);
	log_trace(filesystem_log,"obtener_lista_nodobloques_lectura->end");
}

/*leer_archivo
 * 0-> directorio no existe
 * -1 -> el archivo no existe
 * -2 -> error interno
 * -3-> error al enviar mensajes
 * */
int leer_archivo(char* path, char* filename){
	int rta=1;
	int dir_padre;
	t_file* archivo;
	t_list* nodobloques_para_leer;
	dir_padre = validar_path(path);
	if(!dir_padre){
		//no existe directorio
		log_error(filesystem_log,"info_yama->El directorio %s no existe",path);
		printf("Error. El directorio %s no existe.\n",path);
		rta = 0;
	}else{
		archivo = buscar_nombre_arch_en_dir(filename,dir_padre);
		if(archivo==NULL){
			//no existe archivo
			log_error(filesystem_log,"El archivo %s no existe en el directorio %s.\n",filename,path);
			printf("Error. El archivo %s no existe en el directorio %s.\n",filename,path);
			rta = -1;
		}else{
			//existe archivo, tengo la lista de bloques
			pthread_mutex_lock(&mutex_cant_bloques_leer);
			cant_bloques_leer = list_size(archivo->bloques);
			pthread_mutex_unlock(&mutex_cant_bloques_leer);
			pthread_mutex_lock(&mutex_buffer_lectura);
			buffer_lectura = malloc(archivo->size);
			pthread_mutex_unlock(&mutex_buffer_lectura);
			pthread_mutex_lock(&mutex_size_leer);
			size_leer = archivo->size;
			pthread_mutex_unlock(&mutex_size_leer);
			nodobloques_para_leer = list_create();
			pthread_mutex_lock(&archivo->mutex_bloques);
			obtener_lista_nodobloques_lectura(&nodobloques_para_leer,archivo->bloques);
			pthread_mutex_unlock(&archivo->mutex_bloques);
			if(list_size(nodobloques_para_leer)==0 || list_size(nodobloques_para_leer) != list_size(archivo->bloques)){
				log_error(filesystem_log,"Error interno no se pudieron obtener los nodobloques para el archivo %s",filename);
				rta = -2;
			}else{
				//mando las solicitudes para leer a cada nodobloque
				pthread_mutex_lock(&archivo->mutex_bloques);
				if(!enviar_mensaje_lectura_datanodes(nodobloques_para_leer,archivo->bloques)){
					log_error(filesystem_log,"Error al enviar mensaje a los datanodes");
					rta = -3;
				}
				pthread_mutex_unlock(&archivo->mutex_bloques);
				log_trace(filesystem_log,"Se enviaron los mensajes a los datanode");
			}
			list_destroy(nodobloques_para_leer);
		}
	}
	return rta;
}

int leer_yama_fs(char* fullpath){
	int rta=0;
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	int longitud_nombre;
	char* aux;
	log_trace(filesystem_log,"leer_yama_fs->init");
	aux = obtener_nombre_archivo_path(fullpath);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	aux = string_substring(fullpath, 0, string_length(fullpath)-longitud_nombre);
	string_append(&path_yama,aux);
	free(aux);
	if(leer_archivo(path_yama, nombre_archivo) == 1){
		//se enviaron todos los mensajes
		//espero que se lean todos
		sem_wait(&b_lectura);
		log_trace(filesystem_log,"leer_yama_fs->ya se leyeron todos los bloques, el contenido del archiv esta disponible");
		rta = 1;
	}
	free(nombre_archivo);
	free(path_yama);
	log_trace(filesystem_log,"leer_yama_fs->end");
	return rta;
}

void md5_yama_fs(char* path){
	log_trace(filesystem_log,"md5_yama_fs->init");
	int i;
	char* nombre_arch;
	se_pide_md5 = 1;
	if(leer_yama_fs(path)){
		log_trace(filesystem_log,"md5_yama_fs->se pudo leer el archivo");
		//ya se pudo leer
		//imprimo el contenido
		pthread_mutex_lock(&mutex_buffer_lectura);
		pthread_mutex_lock(&mutex_size_leer);
		MD5_Final (c,&mdContext);
		for(i = 0; i < MD5_DIGEST_LENGTH; i++) printf("%02x", c[i]);
		nombre_arch = obtener_nombre_archivo_path(path);
		printf (" %s\n", nombre_arch);
		free(buffer_lectura);
		free(nombre_arch);
		buffer_lectura = string_new();
		pthread_mutex_unlock(&mutex_size_leer);
		pthread_mutex_unlock(&mutex_buffer_lectura);
		//reinicio flag
		pthread_mutex_lock(&mutex_cant_bloques_leer);
		cant_bloques_leer = 0;
		pthread_mutex_unlock(&mutex_cant_bloques_leer);
		pthread_mutex_lock(&mutex_size_leer);
		size_leer = 0;
		offset_leer = 0;
		se_pide_md5 = 0;
		MD5_Init (&mdContext);
		pthread_mutex_unlock(&mutex_size_leer);
	}
	log_trace(filesystem_log,"md5_yama_fs->end");
}

void cat_yama_fs(char* path){
	log_trace(filesystem_log,"cat_yama_fs->init");
	if(leer_yama_fs(path)){
		//ya se pudo leer
		//imprimo el contenido
		pthread_mutex_lock(&mutex_buffer_lectura);
		pthread_mutex_lock(&mutex_size_leer);
		fwrite(buffer_lectura,size_leer,1,stdout);
		free(buffer_lectura);
		//buffer_lectura = string_new();
		pthread_mutex_unlock(&mutex_size_leer);
		pthread_mutex_unlock(&mutex_buffer_lectura);
		//reinicio flag
		pthread_mutex_lock(&mutex_cant_bloques_leer);
		cant_bloques_leer = 0;
		pthread_mutex_unlock(&mutex_cant_bloques_leer);
		pthread_mutex_lock(&mutex_size_leer);
		size_leer = 0;
		offset_leer = 0;
		pthread_mutex_unlock(&mutex_size_leer);
	}
	log_trace(filesystem_log,"cat_yama_fs->end");
}

void copy_from_yama_to_local(char* paths){
	log_trace(filesystem_log,"copy_from_yama_to_local->init");
	int longitud_nombre = 0;
	char *nombre_archivo = string_new();
	char *path_local = string_new();
	char* aux;
	FILE *f;

	char** paths_spliteado = string_split(paths, " ");

	aux = obtener_nombre_archivo_path(paths_spliteado[1]);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	// directorio local
	aux = string_substring(paths_spliteado[1], 0, string_length(paths_spliteado[1])-longitud_nombre);
	string_append(&path_local,aux);
	free(aux);

	//creo directorio local si no existe
	crea_directorio_metadata(path_local);

	if(leer_yama_fs(paths_spliteado[0])){
		//ya se pudo leer
		//imprimo el contenido
		f = fopen(paths_spliteado[1], "wb");
		if(f==NULL){
			printf("Error al abrir el archivo %s.\n",paths_spliteado[1]);
		}else{
			pthread_mutex_lock(&mutex_buffer_lectura);
			pthread_mutex_lock(&mutex_size_leer);
			fwrite(buffer_lectura,size_leer,1,f);
			fclose(f);
			printf("Se escribio el archivo %s correctamente.\n",paths_spliteado[1]);
			free(buffer_lectura);
			//buffer_lectura = string_new();
			pthread_mutex_unlock(&mutex_size_leer);
			pthread_mutex_unlock(&mutex_buffer_lectura);
			//reinicio flag
			pthread_mutex_lock(&mutex_cant_bloques_leer);
			cant_bloques_leer = 0;
			pthread_mutex_unlock(&mutex_cant_bloques_leer);
			pthread_mutex_lock(&mutex_size_leer);
			size_leer = 0;
			offset_leer = 0;
			pthread_mutex_unlock(&mutex_size_leer);
		}
	}
	log_trace(filesystem_log,"copy_from_yama_to_local->end");
}

/*Almacena un archivo, funcion principal del fs Yama
 * interfaz definida en el enunciado
 * retorna -1 si no hay espacion para el archivo y su copia
 * retorna -2 si hay un error interno
 * retorna -3 si no se pudo crear el directorio
 * retorna -4 si ya existe un archivo con ese nombre en ese directorio
 * */
int almacenar_archivo(char* path, char* filename,char* data,long int file_size){
	long int offset=0;
	unsigned int cant_bloques_archivo;
	int cant_nodobloques=0;
	int num_bloque_arch=0,i;
	int cant_bytes_leidos;
	int error=0;
	char* buff_leido;
	t_list* nodosb = list_create();
	t_list* nodosb_aux;
	t_list* list_aux;
	t_block* bloque;
	t_file* arch;
	int dir_padre;
	log_trace(filesystem_log,"almacenar_archivo->init");
	//obtengo la cantidad de bloques del archivo
	cant_bloques_archivo = obtener_cantidad_de_bloques(file_size);
	//hay 2 nodos con esa cantidad de bloques?
	if(hay_minimo_datanodes_libres(cant_bloques_archivo)<2){
		log_error(filesystem_log,"almacenar_archivo->no hay bloques suficientes para almacenar el archivo %s y su copia",filename);
		error=-1;
	}else{
		//hay espacio, obtengo los nodobloques que voy a usar
		//como se chequea antes que hay espacio
		//todas las listas deberian ser distinto de vacio
		pthread_mutex_lock(&mutex_crear_nodo_bloque);
		while(cant_nodobloques < cant_bloques_archivo){
			list_aux = obtener_nodos_bloque();
			list_add_all(nodosb, list_aux);
			list_destroy(list_aux);
			cant_nodobloques++;
		}
		if(list_size(nodosb)!= (cant_bloques_archivo*2)){
			log_error(filesystem_log,"almacenar_archivo->error interno, no hay 2 nodos distintos para guardar el bloque o la cantidad de nodos bloques incorrecto");
			liberar_nodos_bloques(nodosb);
			list_destroy_and_destroy_elements(nodosb, (void*)free);
			pthread_mutex_unlock(&mutex_crear_nodo_bloque);
			error=-2;
		}else{
			pthread_mutex_unlock(&mutex_crear_nodo_bloque);
			dir_padre = mkdir_fs_yama(path);
			if(dir_padre==0){
				//existe, busco el id
				dir_padre = validar_path(path);
				if(buscar_nombre_arch_en_dir(filename,dir_padre)!=NULL){
					//existe el archivo
					log_error(filesystem_log,"almacenar_archivo->el archivo %s ya existe en el directorio",filename);
					liberar_nodos_bloques(nodosb);
					error = -4;
				}
			}else if(dir_padre==-1 || dir_padre==-2){
				log_error(filesystem_log,"almacenar_archivo->error al crear el directorio para el archivo %s",filename);
				error=-1;
			}
		}
	}

	if(!error){
		//ya tengo el directorio
		//ya tengo los nodobloques a usar
		//creo archivo
		arch = file_create(filename,file_size,determinar_tipo_archivo(filename),dir_padre);
		//empiezo a leer el archivo desde el buffer
		cant_bytes_leidos=lee_y_corta_bloque_archivo(data,&offset,&buff_leido,determinar_tipo_archivo(filename),BLOCK_SIZE,file_size);
		while(cant_bytes_leidos != 0 && !error){
			log_trace(filesystem_log,"almacenar_archivo->se leyo un bloque para el archivo %s",filename);
			//voy tomando de a 2 nodobloques
			nodosb_aux = list_take_and_remove(nodosb, 2);
			if(enviar_mensaje_escritura_datanodes(nodosb_aux, cant_bytes_leidos,buff_leido)){
				//ya envio el mensaje a los datanode y escribieron
				//tengo que crear bloque
				bloque = bloque_create(num_bloque_arch,cant_bytes_leidos);
				//agrego los nodobloque al bloque
				for(i=0;i<list_size(nodosb_aux);i++){
					add_nodobloque_a_bloque(bloque,list_get(nodosb_aux,i));
				}
				//agrego el bloque al archivo
				add_bloque_a_file(arch,bloque);
				num_bloque_arch++;
			}else{
				//hubo error al enviar el mensaje a los datanode
				//hago rollback
				liberar_nodos_bloques(nodosb);
				list_destroy_and_destroy_elements(nodosb, (void*)free);
				list_destroy_and_destroy_elements(arch->bloques, (void*)free);
				rmdir_fs_yama(path);
				log_error(filesystem_log,"almacenar_archivo->error al enviar el mensaje a los datanode");
			}
			list_destroy(nodosb_aux);
			i++;
			free(buff_leido);
			//buff_leido=string_new();
			cant_bytes_leidos=lee_y_corta_bloque_archivo(data,&offset,&buff_leido,determinar_tipo_archivo(filename),BLOCK_SIZE,file_size);
		}
		free(buff_leido);
		error = 1;
		//aca ya tengo el archivo con todos sus bloques
		//tengo que agregarlo al directorio
		add_file_to_directory(arch->directorio_padre,arch);
		//actualizo la info del sistema y archivos metadata
		actualizar_bloques_sistema();
		save_nodes_info_to_file();
		save_file_info_to_file(arch);
		list_destroy(nodosb);
	}
	log_trace(filesystem_log,"almacenar_archivo->end");
	return error;
}

char* obtener_nombre_archivo_path(char* path){
	char** path_spliteado = string_split(path, "/");
	char * strNombre = string_new();
	int ultimo_elemento = 0;
	log_trace(filesystem_log,"obtener_nombre_archivo_path->init");
	while(path_spliteado[ultimo_elemento]!=NULL){
		ultimo_elemento++;
	}
	string_append(&strNombre,path_spliteado[ultimo_elemento-1]);
	ultimo_elemento = 0;
	while(path_spliteado[ultimo_elemento]!=NULL){
		free(path_spliteado[ultimo_elemento]);
		ultimo_elemento++;
	}
	free(path_spliteado);
	log_trace(filesystem_log,"obtener_nombre_archivo_path->end");
	return strNombre;
}
/* copia un archivo local al directorio de yamafs indicado
 * rta -> 0 error al leer el archivo local
 * rta -1 si no hay espacion para el archivo y su copia
 * rta -2 si hay un error interno
 * rta -3 si no se pudo crear el directorio
 * rta -4 si ya existe un archivo con ese nombre en ese directorio
 * */

int copy_from_local_to_yamafs(char* paths){
	int rta= 0;
	int i = 0;
	long int tamano_archivo = 0;
	char* data_archivo = string_new();
	int longitud_nombre = 0;
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	char* aux;
	//el primer elemento es el path from, el segundo es el path de yama
	char** paths_spliteado = string_split(paths, " ");
	log_trace(filesystem_log,"copy_from_local_to_yamafs->init");
	//leo el archivo del fs localread_entire_file
	//TODO parametro binario pdf
	if(read_entire_file_text(paths_spliteado[0],&data_archivo,&tamano_archivo)){
		log_trace(filesystem_log,"copy_from_local_to_yamafs->se pudo leer el archivo local");
		//ya tengo la data del archivo, y el tamaño
		//ahora necesito sacar el nombre del archivo destino
		aux = obtener_nombre_archivo_path(paths_spliteado[1]);
		string_append(&nombre_archivo,aux);
		free(aux);
		longitud_nombre = string_length(nombre_archivo);
		// y tambien el directorio destino
		aux = string_substring(paths_spliteado[1], 0, string_length(paths_spliteado[1])-longitud_nombre);
		string_append(&path_yama,aux);
		free(aux);
		//ahora llamo a la funcion de la interfaz de yama fs
		rta = almacenar_archivo(path_yama, nombre_archivo,data_archivo,tamano_archivo);
	}
	free(data_archivo);
	free(nombre_archivo);
	free(path_yama);
	i = 0;
	while(paths_spliteado[i]!=NULL){
		free(paths_spliteado[i]);
		i++;
	}
	free(paths_spliteado);
	log_trace(filesystem_log,"copy_from_local_to_yamafs->end");
	return rta;

}

void liberar_bloques_archivo(t_file* arch){
	log_trace(filesystem_log,"liberar_bloques_archivo->init");
	int i;
	t_block *bl;
	pthread_mutex_lock(&arch->mutex_bloques);
	for(i=0;i<list_size(arch->bloques);i++){
		bl=list_get(arch->bloques,i);
		pthread_mutex_lock(&bl->mutex_nodobloques);
		liberar_nodos_bloques(bl->nodobloques);
		pthread_mutex_unlock(&bl->mutex_nodobloques);
	}
	pthread_mutex_unlock(&arch->mutex_bloques);
	log_trace(filesystem_log,"liberar_bloques_archivo->end");
}

void destroy_file(t_file* arch){
	log_trace(filesystem_log,"destroy_file->init");
	int i;
	t_block *bl;
	pthread_mutex_lock(&arch->mutex_bloques);
	for(i=0;i<list_size(arch->bloques);i++){
		bl=list_get(arch->bloques,i);
		pthread_mutex_lock(&bl->mutex_nodobloques);
		list_destroy_and_destroy_elements(bl->nodobloques, (void*)free);
		pthread_mutex_unlock(&bl->mutex_nodobloques);
	}
	list_destroy_and_destroy_elements(arch->bloques, (void*)free);
	pthread_mutex_unlock(&arch->mutex_bloques);
	free(arch->nombre);
	free(arch);
	log_trace(filesystem_log,"destroy_file->end");
}

/* -2 no existe la copia especificada
 * -1 no existe el bloque
 * 0 solo queda un bloque
 * 1 se borro un bloque
 * */
int eliminar_bloque_de_arch(t_file* arch,int n_bloque,int n_copia){
	int rta;
	t_block *bl;
	t_nodobloque* nb;
	int encontrado = 0;
	int i=0;
	t_list *aborrar;
	log_trace(filesystem_log,"eliminar_bloque_de_arch->init");
	pthread_mutex_lock(&arch->mutex_bloques);
	while(i<list_size(arch->bloques) && !encontrado){
		bl = list_get(arch->bloques,i);
		if(bl->num_bloque==n_bloque){
			encontrado = 1;
		}
		i++;
	}
	if(!encontrado){
		rta = -1;
	}else{
		//hay mas de una copia?
		pthread_mutex_lock(&bl->mutex_nodobloques);
		if(list_size(bl->nodobloques)<=1){
			rta = 0;
		}else{
			if(n_copia < list_size(bl->nodobloques)){
				//busco la copia
				nb = list_remove(bl->nodobloques,n_copia);
				aborrar = list_create();
				list_add(aborrar,nb);
				liberar_nodos_bloques(aborrar);
				//libero
				list_destroy_and_destroy_elements(aborrar, (void*)free);
				rta = 1;
			}else{
				rta = -2;
			}
		}
		pthread_mutex_unlock(&bl->mutex_nodobloques);
	}
	pthread_mutex_unlock(&arch->mutex_bloques);
	//actualizo la info de metadata
	save_file_info_to_file(arch);
	log_trace(filesystem_log,"eliminar_bloque_de_arch->end");
	return rta;
}

void rm_block_file(char* path){
	log_trace(filesystem_log,"rm_block_file->init");
	int i=0;
	char** split = string_split(path, " ");
	//flag b arg 0
	//path archivo arg 1
	//nro bloque arg 2
	//nro copia arg3
	int longitud_nombre = 0;
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	char* aux;
	t_file* archivo;
	int dir_padre;
	int resultado;

	aux = obtener_nombre_archivo_path(split[1]);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	// directorio
	aux = string_substring(split[1], 0, string_length(split[1])-longitud_nombre);
	string_append(&path_yama,aux);
	free(aux);

	dir_padre = validar_path(path_yama);
	if(!dir_padre){
		//no existe directorio
		log_error(filesystem_log,"rm_block_file->El directorio %s no existe",path);
		printf("Error. El directorio %s no existe.\n",path_yama);
	}else{
		archivo = buscar_nombre_arch_en_dir(nombre_archivo,dir_padre);
		if(archivo==NULL){
			//no existe archivo
			log_error(filesystem_log,"rm_block_file->El archivo %s no existe en el directorio %s.\n",nombre_archivo,path);
			printf("Error. El archivo %s no existe en el directorio %s.\n",nombre_archivo,path_yama);
		}else{
			//existe archivo, tengo que eliminar el bloque
			//si es que hay más de una copia
			resultado = eliminar_bloque_de_arch(archivo,atoi(split[2]),atoi(split[3]));
			if(resultado == -1){
				log_error(filesystem_log,"rm_block_file->No existe el bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[2],nombre_archivo,path_yama);
				printf("No existe el bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[2],nombre_archivo,path_yama);
			}else if(resultado == -2){
				log_error(filesystem_log,"rm_block_file->No existe la copia %s del bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[3],split[2],nombre_archivo,path_yama);
				printf("No existe la copia %s del bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[3],split[2],nombre_archivo,path_yama);
			}else if(resultado == 0){
				log_error(filesystem_log,"rm_block_file->Solo queda una copia del bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[2],nombre_archivo,path_yama);
				printf("Solo queda una copia del bloque %s del archivo %s del directorio %s , se cancela la operacion.\n",split[2],nombre_archivo,path_yama);
			}else{
				actualizar_bloques_sistema();
				log_trace(filesystem_log,"rm_block_file->Se elimino una copia del bloque %s del archivo %s del directorio %s correctamente.\n",split[2],nombre_archivo,path_yama);
				printf("Se elimino una copia del bloque %s del archivo %s del directorio %s correctamente.\n",split[2],nombre_archivo,path_yama);
			}
		}
	}

	while(split[i]!=NULL){
		free(split[i]);
		i++;
	}
	free(nombre_archivo);
	free(path_yama);
	log_trace(filesystem_log,"rm_block_file->end");
}

void rm_file_yama_fs(char* path){
	log_trace(filesystem_log,"rm_file_yama_fs->init");
	int longitud_nombre = 0;
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	char* aux;
	t_file* archivo;

	aux = obtener_nombre_archivo_path(path);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	int dir_padre;
	// directorio local
	aux = string_substring(path, 0, string_length(path)-longitud_nombre);
	string_append(&path_yama,aux);
	free(aux);

	dir_padre = validar_path(path_yama);
	if(!dir_padre){
		//no existe directorio
		log_error(filesystem_log,"rm_file_yama_fs->El directorio %s no existe",path);
		printf("Error. El directorio %s no existe.\n",path);
	}else{
		archivo = buscar_nombre_arch_en_dir(nombre_archivo,dir_padre);
		if(archivo==NULL){
			//no existe archivo
			log_error(filesystem_log,"rm_file_yama_fs->El archivo %s no existe en el directorio %s.\n",nombre_archivo,path);
			printf("Error. El archivo %s no existe en el directorio %s.\n",nombre_archivo,path);
		}else{
			//existe archivo, tengo que eliminarlo
			//libero bloques (ya me actualiza la info del sistema)
			liberar_bloques_archivo(archivo);
			//borro la metadata
			borrar_metadata_file(archivo->directorio_padre,archivo);
			//remuevo el archivo de la lista del directorio y libero
			pthread_mutex_lock(&mutex_tabla_directorios);
			pthread_mutex_lock(&mutex_nombre_archivo_aux);
			string_append(&nombre_archivo_aux,archivo->nombre);
			list_remove_and_destroy_by_condition(tabla_directorios[dir_padre].archivos, (void*)es_archivo_con_nombre, (void*)destroy_file);
			free(nombre_archivo_aux);
			nombre_archivo_aux = string_new();
			pthread_mutex_unlock(&mutex_nombre_archivo_aux);
			pthread_mutex_unlock(&mutex_tabla_directorios);
			actualizar_bloques_sistema();
			printf("Se elimino el archivo %s del directorio %s correctamente.\n",nombre_archivo,path_yama);
		}
	}
	free(nombre_archivo);
	free(path_yama);
	log_trace(filesystem_log,"rm_file_yama_fs->end");
}
void imprimir_nodobloque_metadata(t_nodobloque* nodob){
	log_trace(filesystem_log,"imprimir_nodobloque_metadata->init");
	printf("[Nodo%d,%d]\n",nodob->id_nodo,nodob->num_bloque_nodo);
	log_trace(filesystem_log,"imprimir_nodobloque_metadata->end");
}


void imprimir_bloque_metadata(t_block* bl){
	int i=0;
	log_trace(filesystem_log,"imprimir_bloque_metadata->init");
	while(i<list_size(bl->nodobloques)){
		printf("BLOQUE%dCOPIA%d=",bl->num_bloque,i);
		imprimir_nodobloque_metadata(list_get(bl->nodobloques,i));
		i++;
	}
	printf("BLOQUE%dBYTES=%d\n",bl->num_bloque,bl->fin_bloque);
	log_trace(filesystem_log,"imprimir_bloque_metadata->end");
}

void imprimr_bloques_archivo(t_list* bloques){
	log_trace(filesystem_log,"imprimr_bloques_archivo->init");
	list_iterate(bloques,(void*)imprimir_bloque_metadata);
	log_trace(filesystem_log,"imprimr_bloques_archivo->end");
}

void imprimir_info_archivo(t_file* arch){
	char* type=file_type_to_string(arch->tipo);
	char* estado=file_state_to_string(arch->estado);
	log_trace(filesystem_log,"imprimir_info_archivo->init");
	printf("NOMBRE = %s\n",arch->nombre);
	printf("TAMANIO = %d\n",arch->size);
	printf("TIPO = %s\n",type);
	printf("ESTADO = %s\n",estado);
	pthread_mutex_lock(&arch->mutex_bloques);
	imprimr_bloques_archivo(arch->bloques);
	pthread_mutex_unlock(&arch->mutex_bloques);
	free(type);
	free(estado);
	log_trace(filesystem_log,"imprimir_info_archivo->end");
}

void info_yamafs(char* path){
	char *nombre_archivo = string_new();
	char *path_yama = string_new();
	t_file* archivo;
	int longitud_nombre;
	int dir_padre;
	char* aux;
	log_trace(filesystem_log,"info_yama->init");
	aux = obtener_nombre_archivo_path(path);
	string_append(&nombre_archivo,aux);
	free(aux);
	longitud_nombre = string_length(nombre_archivo);
	aux = string_substring(path, 0, string_length(path)-longitud_nombre);
	string_append(&path_yama,aux);
	free(aux);
	dir_padre = validar_path(path_yama);
	if(!dir_padre){
		log_error(filesystem_log,"info_yama->El directorio %s no existe",path_yama);
		printf("Error. El directorio %s no existe.\n",path_yama);
	}else{
		archivo = buscar_nombre_arch_en_dir(nombre_archivo,dir_padre);
		if(archivo==NULL){
			log_error(filesystem_log,"El archivo %s no existe en el directorio %s.\n",nombre_archivo,path_yama);
			printf("Error. El archivo %s no existe en el directorio %s.\n",nombre_archivo,path_yama);
		}else{
			imprimir_info_archivo(archivo);
		}
	}
	free(nombre_archivo);
	free(path_yama);
}

void rename_yamafs(char* paths){
	char** paths_spliteado;
	char** path_spliteado1;
	char** path_spliteado2;
	char *nombre_archivo_origen = string_new();
	char *nombre_archivo_destino = string_new();
	char *path_yama = string_new();
	t_file* archivo;
	int longitud_nombre;
	int dir_padre;
	int cant_path1=0;
	int cant_path2=0;
	char* aux;
	log_trace(filesystem_log,"rename_yamafs->init");
	paths_spliteado = string_split(paths, " ");
	path_spliteado1 = string_split(paths, "/");
	path_spliteado2 = string_split(paths, "/");
	while(path_spliteado1[cant_path1]!=NULL){
		cant_path1++;
	}
	while(path_spliteado2[cant_path2]!=NULL){
		cant_path2++;
	}
	//tienen la misma longitud los path?
	if(cant_path1!=cant_path2){
		log_error(filesystem_log,"Los paths pasados por parametro no tienen la misma longitud.");
		printf("Error.Los paths pasados por parametro no tienen la misma longitud.\n");
	}else{
		//es un archivo o un directorio?
		dir_padre = validar_path(paths_spliteado[0]);
		if(!dir_padre){
			log_trace(filesystem_log,"rename_yamafs->El path %s no existe, se busca como archivo.",paths_spliteado[0]);
			//no es un directorio
			//veo si es un archivo
			aux = obtener_nombre_archivo_path(paths_spliteado[0]);
			string_append(&nombre_archivo_origen,aux);
			free(aux);
			longitud_nombre = string_length(nombre_archivo_origen);
			string_append(&path_yama,string_substring(paths_spliteado[0], 0, string_length(paths_spliteado[0])-longitud_nombre));
			dir_padre = validar_path(path_yama);
			if(!dir_padre){
				//no existe el path previo al archivo
				log_error(filesystem_log,"info_yama->El directorio %s no existe",path_yama);
				printf("Error. El directorio %s no existe, se intento buscar el directorio %s y no existe.\n",paths_spliteado[0],path_yama);
			}else{
				//existe el path previo, puede ser un archivo
				log_trace(filesystem_log,"info_yama->El directorio %s existe, se busca el archivo %s",path_yama,nombre_archivo_origen);
				archivo = buscar_nombre_arch_en_dir(nombre_archivo_origen,dir_padre);
				if(archivo==NULL){
					log_error(filesystem_log,"El archivo %s no existe en el directorio %s.\n",nombre_archivo_origen,path_yama);
					printf("Error. El archivo %s no existe en el directorio %s.\n",nombre_archivo_origen,path_yama);
				}else{
					//es un archivo y existe
					aux = obtener_nombre_archivo_path(paths_spliteado[1]);
					string_append(&nombre_archivo_destino,aux);
					free(aux);
					pthread_mutex_lock(&tabla_directorios[dir_padre].mutex_archivos);
					free(archivo->nombre);
					archivo->nombre = string_new();
					string_append(&archivo->nombre,nombre_archivo_destino);
					pthread_mutex_unlock(&tabla_directorios[dir_padre].mutex_archivos);
					save_file_info_to_file(archivo);
					log_trace(filesystem_log,"Se modifico el nombre del archivo %s a %s exitosamente",nombre_archivo_origen,nombre_archivo_destino);
					printf("Se modifico el nombre del archivo %s a %s exitosamente. \n",nombre_archivo_origen,nombre_archivo_destino);
				}
			}
		}else{
			//es un directorio
			aux = obtener_nombre_archivo_path(paths_spliteado[0]);
			string_append(&nombre_archivo_origen,aux);
			free(aux);
			aux = obtener_nombre_archivo_path(paths_spliteado[1]);
			string_append(&nombre_archivo_destino,aux);
			free(aux);
			log_trace(filesystem_log,"Se encontro el directorio %s, se procede a cambiar el nombre.",paths_spliteado[0]);
			pthread_mutex_lock(&tabla_directorios[dir_padre].mutex_archivos);
			memset(&tabla_directorios[dir_padre].nombre[0], 0, sizeof(tabla_directorios[dir_padre].nombre));
			memcpy(tabla_directorios[dir_padre].nombre,nombre_archivo_destino,strlen(nombre_archivo_destino));
			pthread_mutex_unlock(&tabla_directorios[dir_padre].mutex_archivos);
			save_table_directory_to_file();
			printf("Se modifico el nombre del directorio %s a %s exitosamente. \n",nombre_archivo_origen,nombre_archivo_destino);
		}
	}
	cant_path1=0;
	cant_path2=0;
	while(path_spliteado1[cant_path1]!=NULL){
		free(path_spliteado1[cant_path1]);
		cant_path1++;
	}
	while(path_spliteado2[cant_path2]!=NULL){
		free(path_spliteado2[cant_path2]);
		cant_path2++;
	}
	free(nombre_archivo_origen);
	free(nombre_archivo_destino);
	free(path_yama);
	log_trace(filesystem_log,"rename_yamafs->end");
}

void create_bitmaps(void){
	log_trace(filesystem_log,"create_bitmaps->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	list_iterate(filesystem_datanodes_conectados,(void*)crear_bitmap_datanode_v);
	list_iterate(filesystem_datanodes_conectados,(void*)mapear_bitmap_a_nodo_v);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"create_bitmaps->end");
}

void mapear_bitmaps(void){
	log_trace(filesystem_log,"mapear_bitmaps->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	list_iterate(filesystem_datanodes_conectados,(void*)mapear_bitmap_a_nodo_v);
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"mapear_bitmaps->end");
}

void limpiar_datanodes(void){
	t_datanode* dn;
	log_trace(filesystem_log,"limpiar_datanodes->init");
	int i=0;
	int j;
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	while(i<list_size(filesystem_datanodes_conectados)){
		dn = list_get(filesystem_datanodes_conectados,i);
		dn->bloques_libres = dn->bloques_totales;
		for(j=0;j<dn->bloques_totales;j++){
			bitarray_clean_bit(dn->bitmap_array, j);
		}
		i++;
	}
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"limpiar_datanodes->end");
}

void format_yama_fs(void){
	log_trace(filesystem_log,"format_yama_fs->init");
	pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
	if(list_size(filesystem_datanodes_conectados) >= 2){
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		initialize_table_directory();
		create_bitmaps();
		limpiar_datanodes();
		actualizar_bloques_sistema();
		save_table_directory_to_file();
		pthread_mutex_lock(&mutex_filesystem_estable);
		filesystem_estable = 1;
		pthread_mutex_unlock(&mutex_filesystem_estable);
		printf("Se ha formateado el filesystem. Estructuras administrativas creadas.\n");
	}else{
		pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
		printf("No se puede formatear el filesystem, se precisan 2 nodos conectados como minimo.Se cancela la operacion.\n");
	}
	pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
	log_trace(filesystem_log,"format_yama_fs->end");
}

int es_filesystem_estable(){
	int rta;
	pthread_mutex_lock(&mutex_filesystem_estable);
	rta = filesystem_estable;
	pthread_mutex_unlock(&mutex_filesystem_estable);
	return rta;
}
void test_escrib_arch (char* data,int cuanto,char* filename) {
	FILE *fp;

	fp = fopen( filename , "a" );
	fwrite(data , 1 , cuanto , fp );

	fclose(fp);

}

/*Test cortar archivo*/
void test_cortar_archivo(){
	char* buff_leido=string_new();
	char* buffer_arch=string_new();
	int cant_bytes_leidos=0;
	long int offset=0;
	long int fsize = 0;
	int i = 0;
	//FILE *fp = fopen("/home/utnso/UTN/TP_Esther/exampleIT.csv", "r");
	//FILE *fp = fopen("/home/utnso/UTN/TP_Esther/kdesample.bin", "r");
	//if (fp == NULL) exit(EXIT_FAILURE);
	//
	if(!read_entire_file_text("/home/utnso/UTN/TP_Esther/Archivos/batmanmatrix.csv",&buffer_arch,&fsize)) exit(EXIT_FAILURE);
	//if(!read_entire_file("/home/utnso/UTN/TP_Esther/exampleTestDELIMITADO.csv",&buffer_arch)) exit(EXIT_FAILURE);
	//string_append(&buffer_arch,"\0");
	printf("archivo leido:\n");
	test_escrib_arch (buffer_arch,fsize,"/home/utnso/UTN/TP_Esther/escriboFSTESTCORTAR_ANTES.txt") ;
	printf("%s\n",buffer_arch);
	while((cant_bytes_leidos=lee_y_corta_bloque_archivo(buffer_arch,&offset,&buff_leido,BINARIO,BLOCK_SIZE,fsize))!=0){
		printf("Se leyeron %d bytes para el bloque %d:\n",cant_bytes_leidos,i);
		printf("Contenido leido para el bloque %d:\n",i);
		i++;
		//string_append(&buff_leido,"\0");
		//printf("%s\n",buff_leido);
		//printf("%d\n",buff_leido);
		test_escrib_arch (buff_leido,cant_bytes_leidos,"/home/utnso/UTN/TP_Esther/escriboFSTESTCORTAR_DESPUES.txt");
		free(buff_leido);
		buff_leido=string_new();
	}
	free(buffer_arch);
}
/*Test del actualizar bloques sistema*/
void test_actualizar_bloques_sistema(){
	t_datanode* dnode2 = datanode_create(1,1,"127.0.0.1",2000,500);
	t_datanode* dnode1 = datanode_create(2,2,"127.0.0.1",3000,100);
	t_datanode* dnode3 = datanode_create(3,3,"127.0.0.1",4000,50);
	agregar_a_datanodes_validos(dnode2);
	agregar_a_datanodes_validos(dnode1);
	agregar_a_datanodes_validos(dnode3);
	actualizar_bloques_sistema();
	crear_bitmap_datanode(dnode2);
	crear_bitmap_datanode(dnode1);
	crear_bitmap_datanode(dnode3);
	mapear_bitmap_a_nodo(dnode2);
	mapear_bitmap_a_nodo(dnode1);
	mapear_bitmap_a_nodo(dnode3);
	escribir_bloque_bitmap(dnode2,1);
	escribir_bloque_bitmap(dnode3,1);
	escribir_bloque_bitmap(dnode1,2);
	log_trace(filesystem_log,"Bloque libre en nodo 1:%d",obtener_bloque_libre_nodo(dnode1));
	liberar_bloque_bitmap(dnode1,0);
	log_trace(filesystem_log,"Bloque libre en nodo 1:%d",obtener_bloque_libre_nodo(dnode1));
	//
	t_nodobloque *nb1 = nodobloque_create(1,45);
	t_nodobloque *nb2 = nodobloque_create(2,12);
	t_nodobloque *nb3 = nodobloque_create(1,10);
	t_nodobloque *nb4 = nodobloque_create(2,88);
	//
	//
	t_nodobloque *nb5 = nodobloque_create(1,77);
	t_nodobloque *nb6 = nodobloque_create(2,2);
	t_nodobloque *nb7 = nodobloque_create(1,15);
	t_nodobloque *nb8 = nodobloque_create(2,10);
	//
	t_block *bloque1 = bloque_create(0,1048500);
	add_nodobloque_a_bloque(bloque1,nb1);
	add_nodobloque_a_bloque(bloque1,nb2);
	t_block *bloque2 = bloque_create(1,1048500);
	add_nodobloque_a_bloque(bloque2,nb3);
	add_nodobloque_a_bloque(bloque2,nb4);
	t_block *bloque3 = bloque_create(2,1048532);
	add_nodobloque_a_bloque(bloque3,nb5);
	add_nodobloque_a_bloque(bloque3,nb6);
	t_block *bloque4 = bloque_create(3,1048532);
	add_nodobloque_a_bloque(bloque4,nb7);
	add_nodobloque_a_bloque(bloque4,nb8);
	t_file *arch_nuevo = file_create("conair.avi",12356334,BINARIO,4);
	add_bloque_a_file(arch_nuevo,bloque1);
	add_bloque_a_file(arch_nuevo,bloque2);
	add_bloque_a_file(arch_nuevo,bloque3);
	add_bloque_a_file(arch_nuevo,bloque4);
	add_file_to_directory(4,arch_nuevo);
	t_file *arch_nuevo2 = file_create("conair.sub",12356334,DELIMITADO,4);
	add_bloque_a_file(arch_nuevo2,bloque1);
	add_bloque_a_file(arch_nuevo2,bloque2);
	add_bloque_a_file(arch_nuevo2,bloque3);
	add_bloque_a_file(arch_nuevo2,bloque4);
	add_file_to_directory(4,arch_nuevo2);
	t_file *arch_nuevo3 = file_create("therock.avi",12356334,BINARIO,3);
	add_bloque_a_file(arch_nuevo3,bloque1);
	add_bloque_a_file(arch_nuevo3,bloque2);
	add_bloque_a_file(arch_nuevo3,bloque3);
	add_bloque_a_file(arch_nuevo3,bloque4);
	add_file_to_directory(3,arch_nuevo3);
	t_file *arch_nuevo4 = file_create("therock.srt",12356334,DELIMITADO,3);
	add_bloque_a_file(arch_nuevo4,bloque1);
	add_bloque_a_file(arch_nuevo4,bloque2);
	add_bloque_a_file(arch_nuevo4,bloque3);
	add_bloque_a_file(arch_nuevo4,bloque4);
	add_file_to_directory(3,arch_nuevo4);
	save_file_info_to_file(arch_nuevo);
	save_file_info_to_file(arch_nuevo2);
	save_file_info_to_file(arch_nuevo3);
	save_file_info_to_file(arch_nuevo4);
}

void string_split_test(){
	char** spliteado;
	int i=0;
	char* strTest = string_new();
	string_append(&strTest,"/home/test/dira/dirb/");
	spliteado = string_split(strTest,"/");
	while(spliteado[i]!=NULL){
		printf("%s/n",spliteado[i]);
		i++;
	}
}

int validar_invocacion_fs(int cant_params,char *params[]){
	int rta;
	log_trace(filesystem_log,"validar_invocacion_fs->init");
	if(cant_params == 1){
		pthread_mutex_lock(&mutex_estado_anterior);
		log_trace(filesystem_log,"validar_invocacion_fs->se invoco al FS en modo para recuperar estado anterior");
		estado_anterior = 1;
		pthread_mutex_unlock(&mutex_estado_anterior);
		rta = 1;
	}else if(cant_params == 2){
		if(string_equals_ignore_case(params[1], "--clean")){
			log_trace(filesystem_log,"validar_invocacion_fs->se invoco al FS en modo --clean se ignora estado anterior");
			rta = 1;
		}else{
			log_error(filesystem_log,"validar_invocacion_fs->se invoco al FS incorrectamente");
			rta = 0;
		}
	}else{
		log_error(filesystem_log,"validar_invocacion_fs->se invoco al FS incorrectamente");
		rta = 0;
	}
	log_trace(filesystem_log,"validar_invocacion_fs->end");
	return rta;
}

int validar_existencia_archivo(char* path){
	int rta=0;
	log_trace(filesystem_log,"validar_existencia_archivo->init");
	if(!access(path, F_OK)){
		log_trace(filesystem_log,"validar_existencia_archivo->existe");
		rta = 1;
	}else{
		log_trace(filesystem_log,"validar_existencia_archivo->no existe");
		rta = 0;
	}
	log_trace(filesystem_log,"validar_existencia_archivo->end");
	return  rta;
}

int validar_archivo_metadata(void){
	int rta;
	int termino=0;
	int i;
	t_config *config_para_nodos;
	char** id_nodos;
	char* nodo_path=string_new();
	log_trace(filesystem_log,"validar_archivo_metadata->init");
	//valido que exista metadata directorios
	if(validar_existencia_archivo(PATH_METADATA_DIRECTORY)){
		log_trace(filesystem_log,"validar_archivo_metadata->existe el archivo metadata de directorios");
		//valido que exista metadata nodos
		if(validar_existencia_archivo(PATH_METADATA_NODES)){
			log_trace(filesystem_log,"validar_archivo_metadata->existe el archivo metadata de nodos");
			//por cada nodo valido que exista metadata bitmap
			//necesito saber los id de los nodos
			config_para_nodos = config_create(PATH_METADATA_NODES);
			id_nodos = config_get_array_value(config_para_nodos, "NODOS");
			//ya tengo los id, por cada uno tengo que comprobar que existe el bitmap
			i=0;
			while(id_nodos[i]!=NULL && !termino){
				//paso a minuscula porque se llaman nodo1.dat,etc
				string_append(&nodo_path ,PATH_METADATA_BITMAP);
				string_to_lower(id_nodos[i]);
				string_append(&nodo_path ,id_nodos[i]);
				string_append(&nodo_path ,".dat");
				//nombre formado
				if(!validar_existencia_archivo(nodo_path)){
					//no existe, termino
					termino = 1;
					log_error(filesystem_log,"validar_archivo_metadata->No existe el bitmap del nodo %s",id_nodos[i]);
				}else{
					log_trace(filesystem_log,"validar_archivo_metadata->existe el bitmap del nodo %s",id_nodos[i]);
				}
				free(nodo_path);
				nodo_path = string_new();
				i++;
			}
			config_destroy(config_para_nodos);
			if(termino){
				//al menos uno no existe
				rta = 0;
			}else{
				rta = 1;
			}
			i=0;
			while(id_nodos[i]!=NULL){
				free(id_nodos[i]);
				i++;
			}
			free(nodo_path);
		}else{
			rta = 0;
		}
	}else{
		rta = 0;
	}
	log_trace(filesystem_log,"validar_archivo_metadata->end");
	return rta;
}

void borrar_metadata_file(int dir_padre,t_file* arch){
	char* path_borrar = string_new();
	char* aux;
	log_trace(filesystem_log,"borrar_metadata_file->init");
	string_append(&path_borrar,PATH_METADATA_FILES);
	aux = string_itoa(dir_padre);
	string_append(&path_borrar,aux);
	free(aux);
	string_append(&path_borrar,"/");
	string_append(&path_borrar,arch->nombre);
	if(remove(path_borrar) == -1)log_error(filesystem_log,"borrar_metadata_file->error al borrar el archivo %s",path_borrar);
	free(path_borrar);
	log_trace(filesystem_log,"borrar_metadata_file->end");
}

int cargar_archivos_metadata(void){
	int rta;
	log_trace(filesystem_log,"cargar_archivos_metadata->init");
	rta = validar_archivo_metadata();
	if(rta){
		//existen los archivo metadata
		//cargo directorios
		read_directory_table_from_metadata();
		initialize_others_directory();
		log_trace(filesystem_log,"cargar_archivos_metadata->se cargo la tabla de directorios");
		//cargo nodos
		cargar_nodos_de_metadata();
		log_trace(filesystem_log,"cargar_archivos_metadata->se cargo la info de los nodos");
		//mapeo bitmaps
		mapear_bitmaps();
		log_trace(filesystem_log,"cargar_archivos_metadata->se mapearon los bitmaps");
		//cargo archivos
		cargar_archivos_desde_metadata();
		log_trace(filesystem_log,"cargar_archivos_metadata->se cargaron los archivos en los directorios");
	}
	log_trace(filesystem_log,"cargar_archivos_metadata->end");
	return rta;
}

void cargar_nodos_de_metadata(void){
	int i;
	log_trace(filesystem_log,"cargar_nodos_de_metadata->init");
	t_config* config_para_nodos = config_create(PATH_METADATA_NODES);
	char ** id_nodos;
	char* aux;
	int id_nodo;
	int bl_tot;
	int bl_lib;
	t_datanode* dt;
	//por cada nodo que leo, creo un datanode
	//que va a tener como info:
	//id
	//bloques totales
	//bloques libres
	//el resto de la info se tiene que completar cuando se conecta (sock,ip worker,puerto worker)
	//por ahora lo completo con info que despues se va a pisar
	if(config_para_nodos == NULL){
		log_error(filesystem_log, "create_file_from_metadata_and_add_directory->No se pudo acceder al archivo de config del archivo %s",PATH_METADATA_NODES);
	}else{
		id_nodos = config_get_array_value(config_para_nodos, "NODOS");
		i=0;
		while(id_nodos[i]!=NULL){
			//obtengo bloques totales
			aux = string_new();
			string_append(&aux,id_nodos[i]);
			string_append(&aux,"Total");
			bl_tot = config_get_int_value(config_para_nodos,aux);
			free(aux);
			//obtengo bloques libres
			aux = string_new();
			string_append(&aux,id_nodos[i]);
			string_append(&aux,"Libre");
			bl_lib = config_get_int_value(config_para_nodos,aux);
			free(aux);
			//corto el "Nodo" para obtener el id
			aux = string_substring(id_nodos[i],4,string_length(id_nodos[i]));
			id_nodo = atoi(aux);
			free(aux);
			//tengo id
			//creo datanode
			dt = datanode_create(id_nodo,0,"127.0.0.1",0,bl_tot);
			dt->bloques_libres = bl_lib;
			pthread_mutex_lock(&mutex_filesystem_datanodes_conectados);
			list_add(filesystem_datanodes_conectados,dt);
			log_trace(filesystem_log,"cargar_nodos_de_metadata->Se agrego el Nodo %d",dt->datanode_id);
			pthread_mutex_unlock(&mutex_filesystem_datanodes_conectados);
			i++;
		}
		i=0;
		while(id_nodos[i]!=NULL){
			free(id_nodos[i]);
			i++;
		}
	}
	config_destroy(config_para_nodos);
	log_trace(filesystem_log,"cargar_nodos_de_metadata->end");
}

void create_file_from_metadata_and_add_directory(char* filepath,int padre_dir){
	log_trace(filesystem_log,"create_file_from_metadata_and_add_directory->init");
	t_config* config_arch=config_create(filepath);
	t_file* arch;
	t_block* bl;
	t_nodobloque* nb;
	int tamanio_arch;
	char* nombre_arch;
	char* key;
	char* aux;
	char** copia_nb;
	int tam_bloque;
	int i,j;
	int termino_bloque = 0;
	int termino_nodobloque = 0;
	if(config_arch == NULL){
		log_error(filesystem_log, "create_file_from_metadata_and_add_directory->No se pudo acceder al archivo de config del archivo %s",filepath);
	}else{
		//tengo que empezar a recorre las keys para ir armando el archivo
		//la cantidad de bloques y nodobloques son variables
		//para crear archivo
		tamanio_arch = config_get_int_value(config_arch,"TAMANIO");
		nombre_arch = obtener_nombre_archivo_path(filepath);
		arch = file_create(nombre_arch,tamanio_arch,determinar_tipo_archivo(nombre_arch),padre_dir);
		free(nombre_arch);
		//archivo creado
		i=0;
		j=0;
		while(!termino_bloque){
			//para crear bloque
			//armo la key a buscar
			key = string_new();
			string_append(&key,"BLOQUE");
			aux = string_itoa(i);
			string_append(&key,aux);
			free(aux);
			string_append(&key,"BYTES");
			//si existe ya puedo crear el bloque,
			//sino significa que ya no hay mas
			if(config_has_property(config_arch, key)){
				//lo encontro leo tamano de bloque
				// y los nodobloques de ese bloque
				tam_bloque = config_get_int_value(config_arch,key);
				//leyendo el tamano ya puedo crear el bloque
				bl = bloque_create(i,tam_bloque);
				//bloque creado
				free(key);
				//ahora tengo que iterar por los nodobloques
				while(!termino_nodobloque){
					//armo la key a buscar
					key = string_new();
					string_append(&key,"BLOQUE");
					aux = string_itoa(i);
					string_append(&key,aux);
					free(aux);
					string_append(&key,"COPIA");
					aux = string_itoa(j);
					string_append(&key,aux);
					free(aux);
					//pregunto si existe la key,
					//si existe creo el nodobloque
					//si no existe es porque no hay mas copias del bloque
					if(config_has_property(config_arch, key)){
						//existe, creo nodobloque
						copia_nb=config_get_array_value(config_arch,key);
						free(key);
						//el primer elemento es el nodo
						//el segundo el bloque del nodo
						aux=string_substring(copia_nb[0],4,strlen(copia_nb[0]));
						nb = nodobloque_create(atoi(aux),atoi(copia_nb[1]));
						free(aux);
						//lo agrego al bloque
						add_nodobloque_a_bloque(bl,nb);
						//libero el array del config
						free(copia_nb[0]);
						free(copia_nb[1]);
						free(copia_nb);
						j++;
					}else{
						termino_nodobloque=1;
						free(key);
					}
				}
				//agrego bloque al archivo
				add_bloque_a_file(arch,bl);
				i++;
				termino_nodobloque = 0;
				j=0;
			}else{
				termino_bloque = 1;
				free(key);
			}
		}
		add_file_to_directory(padre_dir,arch);
	}
	log_trace(filesystem_log,"create_file_from_metadata_and_add_directory->end");
}

void test_leer_metadata_archivo(void){
	initialize_table_directory();
	mkdir_fs_yama("/base");
	create_file_from_metadata_and_add_directory("/home/utnso/UTN/TP_Esther/FSYAMA/metadata/archivos/1/nombres.csv",1);
	ls_yama("/base");
	info_yamafs("/base/nombres.csv");
}

int procesar_directorio_archivo(const char *name, const struct stat *status, int type) {
	int index_path;
	int cant=0;
	char** path_spliteado;
	char* aux;
	char* nombre = string_new();
	string_append(&nombre,name);
	if(type == FTW_NS)
		return 0;

	if(type == FTW_F){

		path_spliteado=string_split(nombre,"/");
		while(path_spliteado[cant]!=NULL){
			cant++;
		}
		//if(!string_equals_ignore_case(path_spliteado[cant], "archivos")){
		//if(strcmp(path_spliteado[cant], "archivos")!=0){
		cant--;
		cant--;
		aux=string_new();
		string_append(&aux,path_spliteado[cant]);
		index_path = atoi(aux);
		free(aux);
		create_file_from_metadata_and_add_directory(nombre,index_path);
		//}
		cant=0;
		while(path_spliteado[cant]!=NULL){
			free(path_spliteado[cant]);
			cant++;
		}
		free(path_spliteado);
	}

	if(type == FTW_D && strcmp(".", name) != 0){
		//nada para dorectorios
	}
	free(nombre);
	return 0;
}

void cargar_archivos_desde_metadata(void){
	log_trace(filesystem_log,"cargar_archivos_desde_metadata->init");
	ftw(PATH_METADATA_FILES, procesar_directorio_archivo, 1);
	log_trace(filesystem_log,"cargar_archivos_desde_metadata->end");
}

void sumar_nodo_cant_copias_bloque(t_block* bl){
	pthread_mutex_lock(&bl->mutex_nodobloques);
	if(list_any_satisfy(bl->nodobloques, (void*)es_nodobloque_con_id)){
		bl->cant_copias=bl->cant_copias+1;
	}
	pthread_mutex_unlock(&bl->mutex_nodobloques);
}

void sumar_nodo_cant_copias_arch(t_file* arch){
	pthread_mutex_lock(&arch->mutex_bloques);
	list_iterate(arch->bloques,(void*)sumar_nodo_cant_copias_bloque);
	pthread_mutex_unlock(&arch->mutex_bloques);
}

/*validar canti de copias de cada bloque*/
void sumar_nodo_cant_copias(int nodo_id){
	int i;
	log_trace(filesystem_log,"sumar_nodo_cant_copias->init");
	pthread_mutex_lock(&mutex_id_nb_busqueda);
	id_nb_busqueda = nodo_id;
	pthread_mutex_lock(&mutex_tabla_directorios);
	for(i=0;i<100;i++){
		list_iterate(tabla_directorios[i].archivos,(void*)sumar_nodo_cant_copias_arch);
	}
	pthread_mutex_unlock(&mutex_tabla_directorios);
	pthread_mutex_unlock(&mutex_id_nb_busqueda);
	log_trace(filesystem_log,"sumar_nodo_cant_copias->end");
}

bool es_bloque_estable(t_block* bl){
	bool rta=false;
	if(bl->cant_copias>=2){
		rta = true;
	}
	return rta;
}

bool todos_bloques_estables(t_file* arch){
	pthread_mutex_lock(&arch->mutex_bloques);
	bool rta = list_all_satisfy(arch->bloques, (void*)es_bloque_estable);
	pthread_mutex_unlock(&arch->mutex_bloques);
	return rta;
}

bool todos_archivos_estables(void){
	int i=0;
	bool rta=true;
	pthread_mutex_lock(&mutex_tabla_directorios);
	while(i<100 && rta == true){
		rta = list_all_satisfy(tabla_directorios[i].archivos, (void*)todos_bloques_estables);
		i++;
	}
	pthread_mutex_unlock(&mutex_tabla_directorios);
	return rta;
}

void validar_y_setear_estable(void){
	log_trace(filesystem_log,"validar_y_setear_estable->init");
	if(todos_archivos_estables()==true){
		log_trace(filesystem_log,"validar_y_setear_estable->Cada archivo del filesystem posee una copia, el filesystem esta estable");
		pthread_mutex_lock(&mutex_filesystem_estable);
		filesystem_estable = 1;
		pthread_mutex_unlock(&mutex_filesystem_estable);
		estado_anterior=0;
	}else{
		log_trace(filesystem_log,"validar_y_setear_estable->El filesystem todavia no se encuentra estable, faltan nodos por conectarse");
	}
	log_trace(filesystem_log,"validar_y_setear_estable->end");
}

int my_getline_from_buffer_mejorado(char* buffer,char** line,long int offset){
	//log_trace(filesystem_log,"my_getline_from_buffer->init");
	int string_size=0;
	buffer=buffer+offset;
	char* nueva_linea;
	int index_linea;
	char* aux_nueva_linea;

	//esta funcion me retorna un puntero al primer /n que encuentra
	nueva_linea = strchr(buffer,'\n');

	if(nueva_linea){
		index_linea = nueva_linea - buffer;
		//le sumo uno asi me toma el \n
		index_linea = index_linea + 1;
		//reservo la memo
		aux_nueva_linea = malloc((sizeof(char)*index_linea)+1);
		//inicializo
		memset(aux_nueva_linea, '\0', index_linea);
		// ahora copio
		memcpy(aux_nueva_linea,buffer,index_linea);
		aux_nueva_linea[index_linea]='\0';
		string_append(line,aux_nueva_linea);
		free(aux_nueva_linea);
		string_size = index_linea;
	}else{
		//no encontro /n pero es el fin de la data del archivo
		nueva_linea = strchr(buffer,'\0');
		if(nueva_linea){
			index_linea = nueva_linea - buffer;
			if(index_linea==0){
				//ya se llego al final
				string_size = -1;
			}else{
				//todavia se puede leer
				//reservo la memo
				aux_nueva_linea = malloc(sizeof(char)*index_linea);
				// ahora copio
				memcpy(aux_nueva_linea,buffer,index_linea);
				string_append(line,aux_nueva_linea);
				free(aux_nueva_linea);
				string_size = index_linea;
			}
		}else{
			string_size = -1;
		}
	}
	//log_trace(filesystem_log,"my_getline_from_buffer->end");
	return string_size;
}


void df_yamafs(void){
	char* buffer = malloc(10);
	long int fsize=0;
	log_trace(filesystem_log,"df_yama->init");
	if(read_entire_file_text(PATH_METADATA_NODES,&buffer, &fsize)){
		fwrite(buffer,fsize,1,stdout);
		free(buffer);
	}else{
		log_error(filesystem_log,"df_yama->error al leer el archivo %s",PATH_METADATA_NODES);
	}
	log_trace(filesystem_log,"df_yama->end");
}
