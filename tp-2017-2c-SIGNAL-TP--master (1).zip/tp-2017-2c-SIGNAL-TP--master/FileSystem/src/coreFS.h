/*
 * coreFS.h
 *
 *  Created on: 16/9/2017
 *      Author: utnso
 */

#ifndef SRC_COREFS_H_
#define SRC_COREFS_H_
#include <commons/log.h>
#include <commons/collections/list.h>
#include <pthread.h>
#include <commons/string.h>
#include <commons/bitarray.h>
#include <stdlib.h>
#include "config.h"
#include <stdio.h>
#include <semaphore.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include "serializeFS.h"
#include "src/serialize-adm.h"
#include "src/socket-adm.h"
#include "src/filesUtilities.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <math.h>
#include <openssl/md5.h>
#include <ftw.h>

#define CANT_MAX_DIRECTORIOS 100

#define MAX_SIZE_NAME_DIRECTORY 255

//tamano de bloque en bytes
#define BLOCK_SIZE 1048576

#define PATH_METADATA_DIRECTORY "metadata/directorios.dat"
#define PATH_METADATA_FILES "metadata/archivos/"
#define PATH_METADATA_NODES "metadata/nodos.bin"
#define PATH_METADATA_BITMAP "metadata/bitmaps/"

typedef enum {
	DISPONIBLE,
	NO_DISPONIBLE
} t_file_state;

typedef enum {
	INICIALIZADO,
	VALIDO,
	BORRADO
} t_directory_state;

typedef enum {
	DELIMITADO,
	BINARIO
} t_file_type;

typedef struct {
    char *puerto;
    int32_t cola;
    t_log *logger;
} st_escuchar_conexion;

typedef struct{
	int32_t sock_fd;
}t_proceso_conectado;

typedef struct {
	int32_t datanode_id;
	int32_t sock_fd;
	char *ip_worker;
	int32_t puerto_worker;
	int32_t bloques_libres;
	int32_t bloques_totales;
	char *bitmap_file;
	t_bitarray *bitmap_array;
	pthread_mutex_t mutex_bitmap;
}t_datanode;

typedef struct {
	int32_t id_nodo;
	int32_t num_bloque_nodo; //este es el nodo real
}t_nodobloque;

typedef struct {
	int32_t num_bloque; // este el el bloque ficticio
	int32_t fin_bloque; // bytes ocupados
	pthread_mutex_t mutex_nodobloques;
	t_list* nodobloques; // lista de bloques con los nodos
	int32_t cant_copias;
}t_block;

typedef struct {
	char* nombre;
	int32_t size;
	t_file_type tipo;
	int32_t directorio_padre;
	t_file_state estado;
	pthread_mutex_t mutex_bloques;
	t_list* bloques;
}t_file;

typedef struct {
	int32_t index;
	char nombre[MAX_SIZE_NAME_DIRECTORY];
	int32_t padre;
	t_directory_state estado;
	pthread_mutex_t mutex_archivos;
	t_list* archivos;
}t_directory;



//variable que indica si el filesystem es estable y debe aceptar a YAMA
int filesystem_estable;
//mutex para variable filesystem_estable
pthread_mutex_t mutex_filesystem_estable;
int estado_anterior;
pthread_mutex_t mutex_estado_anterior;
//Lista global que contiene los sockets de los procesos conectados al filesystem
t_list* filesystem_procesos_aceptados;
//mutex para modificar la lista de procesos
pthread_mutex_t mutex_filesystem_procesos_aceptados;
//id del socket de busqueda actual de lectura
int socket_lectura_proceso;
//mutex para modificar el socket del proceso, para ver si es aceptado o no
pthread_mutex_t mutex_socket_lectura_proceso;
//Lista global que contiene los datanodes conectados al filesystem
t_list* filesystem_datanodes_conectados;
//Lista global que contiene los datanodes desconectados que pueden volver a conectarse al filesystem
t_list* filesystem_datanodes_desconectados;
//mutex para modificar la lista de datanodes
pthread_mutex_t mutex_filesystem_datanodes_conectados;
//mutex para modificar la lista de datanodes
pthread_mutex_t mutex_filesystem_datanodes_desconectados;
//Lista global que contiene los datanodes conectados al filesystem
t_list* filesystem_datanodes_leidos;
//mutex para modificar la lista de datanodes
pthread_mutex_t mutex_filesystem_datanodes_leidos;
//variable para busqueda de un nodo por id
int32_t id_nodo_busqueda;
//mutex para modificar el valor de id_nodo_busqueda
pthread_mutex_t mutex_id_nodo_busqueda;
//variable para busqueda de un nodo por id
int32_t id_nb_busqueda;
//mutex para modificar el valor de id_nodo_busqueda
pthread_mutex_t mutex_id_nb_busqueda;
//tabla de directorios
t_directory tabla_directorios[CANT_MAX_DIRECTORIOS];
//mutex para modificar la tabla de directorios
pthread_mutex_t mutex_tabla_directorios;
//variable que representa la cantidad de bloques libres en el sistema
int bloques_libres_sistema;
//mutex para modificar bloques libres sistema
pthread_mutex_t mutex_bloques_libres_sistema;
//variable que representa la cantidad de bloques libres en el sistema
int bloques_totales_sistema;
//mutex para modificar bloques totales sistema
pthread_mutex_t mutex_bloques_totales_sistema;
//variable para usar list_iterate y escribir en un archivo
FILE *pSharedFile;
//mutex para modificar pSharedFile
pthread_mutex_t mutex_pSharedFile;
//mutex para crear un nodo bloque
pthread_mutex_t mutex_crear_nodo_bloque;
//variable para buscar nombre de archivos
char* nombre_archivo_aux;
//mutex para nombre_archivo_aux
pthread_mutex_t mutex_nombre_archivo_aux;
//para la operacion lectura
int cant_bloques_leer;
//mutex para cant_bloques_leer
pthread_mutex_t mutex_cant_bloques_leer;
//para la operacion lectura
int size_leer;
int offset_leer;
//mutex para cant_bloques_leer
pthread_mutex_t mutex_size_leer;
//semaforo binario para lectura
sem_t b_lectura;
//para la operacion lectura
char* buffer_lectura;
//mutex para cant_bloques_leer
pthread_mutex_t mutex_buffer_lectura;
//para md5
unsigned char c[MD5_DIGEST_LENGTH];
MD5_CTX mdContext;
int se_pide_md5;
//semaforo binario para lectura
sem_t b_orden_lectura;
//mutex para recibir mensajes
//pthread_mutex_t mutex_recibir_mensajes;
//pthread_mutex_t mutex_enviar_mensajes;

/*crear_hilo_escuchar_conexiones_filesystem:
 * crea un hilo encargado de escuchar las conexiones al filesystem
 * por cada conexion se crea un nuevo hilo que realiza handshake y
 * en caso de ser un proceso valido establece la comunicacion.
 * Procesos permitidos datanode,workenode y yama, estos dos ultimos dependen
 * de que el sistema este estable */
int crear_hilo_escuchar_conexiones_filesystem(t_log *logger);

/*
 * initialize_fs:
 * Inicializa todas las estructuras y variables necesarias para el proceso fs
 * */
void initialize_fs(void);

/*
 * mkdir:
 * Crea un directorio en la tabla de directorios, si es posible.
 * Devuelve 0 si el dir ya existe.
 * Devuelve -2 si el nombrees muy largo.
 * Devuelve -1 si no se puede crear el directorio en la tabla de directorios.
 * Devuelve 1 en OK
 * */
int mkdir_fs_yama(char nombre[MAX_SIZE_NAME_DIRECTORY]);

/*
 * read_directory_table_from_metadata:
 * Lee la tabla de directorios del archivo especificado por config
 * Cada linea leida del archivo debe respetar la estructura <index> <nombre> <id_padre>
 * El index de cada directorio debe estar entre 0-99
 * Aquellos directorios que no cumplen con esas condiciones se loguean como error
 * */
void read_directory_table_from_metadata();

/*
 * rmdir_fs_yama:
 * Borra un directorio.
 * Si no existe el path devuelve -1.
 * Si el directorio contiene archivos y no se puede borrar devuelve 0.
 * Si se pudo borrar devuelve 1.
 * */
int rmdir_fs_yama(char* nombre);

/*lista los nombres de los archivos de un directorios
 * 0->no existe el directorio
 * 1->ok
 * */
int ls_yama(char* path);

/* copia un archivo local al directorio de yamafs indicado
 * rta -> 0 error al leer el archivo local
 * rta -1 si no hay espacion para el archivo y su copia
 * rta -2 si hay un error interno
 * rta -3 si no se pudo crear el directorio
 * rta -4 si ya existe un archivo con ese nombre en ese directorio
 * */
t_file* buscar_en_lista_de_archivos(char* nombre_arch,t_list* archivos);


t_list* armarMapeoParaYama( char* nombre_archivo_ruta_completa);

int copy_from_local_to_yamafs(char* paths);

void actualizar_bloques_sistema(void);

int crear_bitmap_datanode(t_datanode* dnode);

int almacenar_archivo(char* path, char* filename,char* data,long int file_size);

int mapear_bitmap_a_nodo(t_datanode* dnode);

char* obtener_nombre_archivo_path(char* path);

void info_yamafs(char* path);

void rename_yamafs(char* paths);

void cat_yama_fs(char* path);

void md5_yama_fs(char* path);

void copy_from_yama_to_local(char* paths);

void rm_file_yama_fs(char* path);

void rm_block_file(char* path);

void format_yama_fs(void);

int mv_fs_yama(char* paths);

void cpblock_fs_yama(char* paths);

bool es_nodo_con_id(t_datanode* dnode);

int obtener_bloque_libre_nodo(t_datanode* dnode);

void escribir_bloque_bitmap(t_datanode* dnode,int numero_bloque);

bool es_archivo_con_nombre(t_file* arch);

t_nodobloque *nodobloque_create(int32_t id_datanode,int32_t num_bloque_nodo);

t_file* buscar_nombre_arch_en_dir(char* nombre_arch,int index_dir);

int enviar_mensaje_lectura_datanodes(t_list* nodob,t_list* bloques);

int enviar_mensaje_escritura_datanodes(t_list* nodob, int size_data,char* data);

void liberar_directorios_y_archivos(void);

void destroy_file(t_file* arch);

void save_file_info_to_file(t_file* arch);

bool es_nodo_con_sock(t_datanode* dnode);

bool es_proceso_aceptado(t_proceso_conectado *proceso_conectado);

int validar_invocacion_fs(int cant_params,char *params[]);

int es_filesystem_estable();

int validar_existencia_archivo(char* path);

void read_directory_table_from_metadata();

int cargar_archivos_metadata(void);

void borrar_metadata_file(int dir_padre,t_file* arch);

void cargar_nodos_de_metadata(void);

void eliminarListaBloquePorArchivo (void*data);

void borrarBloques(void*data);

void cargar_archivos_desde_metadata(void);

void validar_y_setear_estable(void);

void sumar_nodo_cant_copias(int nodo_id);

unsigned int round_closest(unsigned int dividend, unsigned int divisor);

void eliminar_de_datanodes_activos(int sock_fd);

void eliminar_de_procesos_conectados(int sock_fd);

int my_getline_from_buffer_mejorado(char* buffer,char** line,long int offset);

void df_yamafs(void);

int actualizar_bloques_libres_nodo(int32_t datanode_id,int valor);

void test_leer_metadata_archivo(void);
void test_actualizar_bloques_sistema();
void test_cortar_archivo();
void string_split_test();
void test_escrib_arch (char* data,int cuanto,char* filename);
void datanode_destroy(t_datanode* dnode);
#endif /* SRC_COREFS_H_ */
