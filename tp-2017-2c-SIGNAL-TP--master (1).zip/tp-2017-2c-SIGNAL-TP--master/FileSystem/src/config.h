/*
 * config.h
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <commons/config.h>
#include <commons/log.h>

#define PROGRAM_NAME "FILESYSTEM_SIGNAL_TP"
#define PATH_CONFIG_FILESYSTEM "config/filesystem.cfg"
#define PATH_LOG_FILESYSTEM "log/filesystem.log"
#define CANTIDAD_PARAMETROS_CONFIG 1

//Estructura config del filesystem
typedef struct {
	int32_t puerto_filesystem;
} filesystem_config;

//Estructura global que contiene el archivo de configuración actual del filesystem
filesystem_config* filesystem_cfg;
//mutex para modificar la variable global del archivo de configuracion
pthread_mutex_t mutex_filesystem_cfg;
//Estructura que representa el log del proceso filesystem
t_log* filesystem_log;
//mutex para usar el log
pthread_mutex_t mutex_filesystem_log;

/*
 * filesystem_config_create:
 * genera una estructura del tipo filesystem_config leyendo los parametros
 * desde el archivo de configuracion
 */
int filesystem_config_create(filesystem_config *config,char* config_path);

/*
 * filesystem_config_destroy:
 * destruye una estructura del tipo filesystem_config
 */
void filesystem_config_destroy(filesystem_config *config);

/*
 * log_config:
 * loguea los valores de una estructura del tipo config
 * */
void log_config(filesystem_config *config);

#endif /* SRC_CONFIG_H_ */
