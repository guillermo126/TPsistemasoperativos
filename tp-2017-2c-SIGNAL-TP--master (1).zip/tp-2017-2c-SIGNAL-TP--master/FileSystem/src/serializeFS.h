/*
 * serializeFS.h
 *
 *  Created on: 16/9/2017
 *      Author: utnso
 */

#ifndef SRC_SERIALIZEFS_H_
#define SRC_SERIALIZEFS_H_
#include <stdio.h>
#include <ctype.h>
#include <stdint.h>
#include "src/socket-adm.h"
#include "src/serialize-adm.h"
#include <stdlib.h>
#include <string.h>

/*
 * deserializeNuevoNodo:
 * Deserializa una estructura del tipo t_mensaje_nuevo_nodo;
 * */

t_mensaje_nuevo_nodo* deserializeNuevoNodo(char* buffer);

/*
 * recibirNuevoNodo:
 * recibe una estructura del tipo t_mensaje_nuevo_nodo del sock_fd pasado por parametro
 * */
int recibirNuevoNodo(t_mensaje_nuevo_nodo *msjeNodo,int sock_fd, int buffer_size);


/*
 * destroyMensajeNuevoNodo:
 * destruye una estructura del tipo t_mensaje_nuevo_nodo
 *
 * */
void destroyMensajeNuevoNodo(t_mensaje_nuevo_nodo* msje);


/*
 * deserializeAlmacenamientoFinal:
 * Deserializa una estructura del tipo t_msj_almacenamiento_final_fs;
 * */

t_msj_almacenamiento_final_fs* deserializeAlmacenamientoFinal(char*);

/*
 * recibirAlmacenamientoFinal:
 * recibe una estructura del tipo t_msj_almacenamiento_final_fs del sock_fd pasado por parametro
 * */
int recibirAlmacenamientoFinal(t_msj_almacenamiento_final_fs*, int, int);

/*
 * destroyMensajeAlmacenamientoFinal:
 * destruye una estructura del tipo t_msj_almacenamiento_final_fs
 *
 * */
void destroyMensajeAlmacenamientoFinal(t_msj_almacenamiento_final_fs*);


char* serializarMsjYamaFs(t_list* lista_de_nodo_del_archivo,int* largo);

#endif /* SRC_SERIALIZEFS_H_ */
