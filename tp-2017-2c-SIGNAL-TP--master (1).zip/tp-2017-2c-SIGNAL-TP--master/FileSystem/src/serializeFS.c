/*
 * serializeFS.c
 *
 *  Created on: 16/9/2017
 *      Author: utnso
 */
#include "serializeFS.h"


///SERIALIZACION YAMA/FS
 t_list* generar_listaConCantidadDeBloquesPorNodo(t_list* lista_nodos_del_archivo) {
  	t_list* listaACrear = list_create();

  	void sacarCantidadDeBloquesDelNodo(void *data) {
  		bloques_en_archivo * nuevoNivel;
  		nuevoNivel = (bloques_en_archivo *) data;
  		int cantidadDEBoques;
  		cantidadDEBoques = list_size(nuevoNivel->bloques);
  		list_add(listaACrear, (void*) cantidadDEBoques);

  	}
  	list_iterate(lista_nodos_del_archivo, sacarCantidadDeBloquesDelNodo);

  	return listaACrear;
  }

 int obtenerTamanioLista( t_list* lista_de_nodo_del_archivo){

 	int tamanio = 0;
 	t_list* listaConCantidadDeBloquesPorNodo = generar_listaConCantidadDeBloquesPorNodo(lista_de_nodo_del_archivo);
 	tamanio += sizeof(int)+sizeof(int)*list_size(listaConCantidadDeBloquesPorNodo);
 	void TamanioNodosDeArchivo(void* data){
 		bloques_en_archivo* nodo = (bloques_en_archivo*) data;
 		tamanio += sizeof(typeof(nodo->largo_ip)) + nodo->largo_ip;
 		tamanio += sizeof(typeof(nodo->largo_nombre_Archivo)) + nodo->largo_nombre_Archivo;
 		tamanio += sizeof(typeof(nodo->nodo));
 		tamanio += sizeof(typeof(nodo->puerto));
 	void TamanioBoques(void* data){
 		bloque* unBloque = (bloque*) data;
 		tamanio += sizeof(typeof(unBloque->num_bloque_ficticio));
 		tamanio += sizeof(typeof(unBloque->num_bloque_real));
 		tamanio += sizeof(typeof(unBloque->bytes_ocupados));
 	}

 	list_iterate(nodo->bloques,TamanioBoques);
 	}

 	list_iterate(lista_de_nodo_del_archivo,TamanioNodosDeArchivo);
 	list_clean(listaConCantidadDeBloquesPorNodo);
 	list_destroy(listaConCantidadDeBloquesPorNodo);
 	return tamanio;

 }




 char* serializarMsjYamaFs(t_list* lista_de_nodo_del_archivo,int* largo){
 	int payload = 0;
 	*largo = 0;
 	int cant_nodo = list_size(lista_de_nodo_del_archivo);
 	// primero obtengo la cantidad de bloques que tiene cada nodo
 	t_list* listaConCantidadDeBloquesPorNodo = generar_listaConCantidadDeBloquesPorNodo(lista_de_nodo_del_archivo);
 	//aca obtengo la cantidad de nodos que tengo por archivo
 	int tamanio =  obtenerTamanioLista(lista_de_nodo_del_archivo);

 	char*buffer = malloc(tamanio);

 	memcpy(buffer+payload,&(cant_nodo),sizeof(typeof(cant_nodo)));
 	payload +=sizeof(typeof(cant_nodo));

 	void serializarListaCantBloqPorNodo(void *data) {
 				int auxiliar = (int) data;
 				memcpy(buffer + payload, &auxiliar, sizeof(int));
 				payload += sizeof(int);
 			}
 	list_iterate(listaConCantidadDeBloquesPorNodo, serializarListaCantBloqPorNodo);

 	void serializarNodosDeArchivo(void* data){
 		bloques_en_archivo * nodo = (bloques_en_archivo *) data;
 		//LARGO IP CON IP
 		memcpy(buffer + payload,&(nodo->largo_ip), sizeof(typeof(nodo->largo_ip)));
 		payload += sizeof(typeof(nodo->largo_ip));
 		if(nodo->largo_ip){
 			memcpy(buffer+payload,nodo->ip,nodo->largo_ip);
 			payload += nodo->largo_ip;

 		}
 		//LARGO NOMBRE ARCHIVO CON NOMBRE ARHIVO
 		memcpy(buffer +payload,&(nodo->largo_nombre_Archivo),sizeof(typeof(nodo->largo_nombre_Archivo)));
 		payload += sizeof(typeof(nodo->largo_nombre_Archivo));
 		if(nodo->largo_nombre_Archivo){
 			memcpy(buffer +payload,nodo->nombre_archivo,nodo->largo_nombre_Archivo);
 			payload += nodo->largo_nombre_Archivo;

 		}
 		//NUMERO NODO
 		memcpy(buffer +payload,&(nodo->nodo),sizeof(typeof(nodo->nodo)));
 		payload += sizeof(typeof(nodo->nodo));
 		//PUERTO NODO
 		memcpy(buffer +payload,&(nodo->puerto),sizeof(typeof(nodo->puerto)));
 		payload += sizeof(typeof(nodo->puerto));

 		void serializarBloques(void*data){
 			bloque* unBloque = (bloque*) data;
 			memcpy(buffer +payload, &(unBloque->num_bloque_ficticio),sizeof(typeof(unBloque->num_bloque_ficticio)));
 			payload += sizeof(typeof(unBloque->num_bloque_ficticio));
 			memcpy(buffer + payload, &(unBloque->num_bloque_real),sizeof(typeof(unBloque->num_bloque_real)));
 			payload += sizeof(typeof(unBloque->num_bloque_real));
 			memcpy(buffer + payload, &(unBloque->bytes_ocupados),sizeof(typeof(unBloque->bytes_ocupados)));
 			payload += sizeof(typeof(unBloque->bytes_ocupados));

 		}



 		list_iterate(nodo->bloques,serializarBloques);
 	}



 	list_iterate(lista_de_nodo_del_archivo,serializarNodosDeArchivo);
 	*largo = payload;
 	return buffer;

 }

t_mensaje_nuevo_nodo* deserializeNuevoNodo(char* buffer){

	t_mensaje_nuevo_nodo* mensaje = malloc(sizeof(t_mensaje_nuevo_nodo));
	int offset = 0, tmp_len = 0;
	memcpy(&mensaje->datanode_id, buffer + offset, tmp_len = sizeof(typeof(mensaje->datanode_id)));
	offset += tmp_len;
	memcpy(&mensaje->puerto_worker, buffer + offset, tmp_len = sizeof(typeof(mensaje->puerto_worker)));
	offset += tmp_len;
	memcpy(&mensaje->bloques_totales, buffer + offset, tmp_len = sizeof(typeof(mensaje->bloques_totales)));
	offset += tmp_len;
	memcpy(&mensaje->ip_nodo_size, buffer + offset, tmp_len = sizeof(typeof(mensaje->ip_nodo_size)));
	offset += tmp_len;
	mensaje->ip_nodo = malloc(mensaje->ip_nodo_size + 1);
	memcpy(mensaje->ip_nodo, buffer + offset, tmp_len = mensaje->ip_nodo_size);
	mensaje->ip_nodo[mensaje->ip_nodo_size]='\0';
	return mensaje;

}

int recibirNuevoNodo(t_mensaje_nuevo_nodo *msjeNodo,int sock_fd, int buffer_size){

	t_mensaje_nuevo_nodo *auxMsje;
	char* buf = malloc(buffer_size);
	if(!recvall(sock_fd, buf, buffer_size)){
		free(buf);
		return 0;
	}else{
		auxMsje=deserializeNuevoNodo(buf);
		*msjeNodo=*auxMsje;
		free(auxMsje);
		free(buf);
		return 1;
	}

}

void destroyMensajeNuevoNodo(t_mensaje_nuevo_nodo* msje){
	free(msje->ip_nodo);
	free(msje);

}

t_msj_almacenamiento_final_fs* deserializeAlmacenamientoFinal(char* buffer){

	t_msj_almacenamiento_final_fs* mensaje = malloc(sizeof(t_msj_almacenamiento_final_fs));
	int offset = 0, tmp_len = 0;

	memcpy(&mensaje->path_archivo_largo, buffer + offset, tmp_len = sizeof(typeof(mensaje->path_archivo_largo)));
	offset += tmp_len;

	mensaje->path_archivo = malloc(mensaje->path_archivo_largo + 1);
	memcpy(mensaje->path_archivo, buffer + offset, tmp_len = mensaje->path_archivo_largo);
	mensaje->path_archivo[mensaje->path_archivo_largo]='\0';
	offset += tmp_len;

	memcpy(&mensaje->contenido_archivo_largo, buffer + offset, tmp_len = sizeof(typeof(mensaje->contenido_archivo_largo)));
	offset += tmp_len;

	mensaje->contenido_archivo = malloc(mensaje->contenido_archivo_largo + 1);
	memcpy(mensaje->contenido_archivo, buffer + offset, tmp_len = mensaje->contenido_archivo_largo);
	mensaje->contenido_archivo[mensaje->contenido_archivo_largo]='\0';

	return mensaje;
}

int recibirAlmacenamientoFinal(t_msj_almacenamiento_final_fs* msjWorker, int sock_fd, int buffer_size){

	t_msj_almacenamiento_final_fs *auxMsje=malloc(sizeof(t_msj_almacenamiento_final_fs));
	char* buf = malloc(buffer_size);
	if(!recvall(sock_fd, buf, buffer_size)){
		return 0;
	}else{
		auxMsje=deserializeAlmacenamientoFinal(buf);
		*msjWorker=*auxMsje;
		return 1;
	}

}

void destroyMensajeAlmacenamientoFinal(t_msj_almacenamiento_final_fs* msje){

	free(msje->contenido_archivo);
	free(msje->path_archivo);
	free(msje);

}
