/*
 * console.c
 *
 *  Created on: 9/9/2017
 *      Author: utnso
 */
#include "consolafs.h"

COMMAND commands[] = {
		{ "format", comando_format, "Formatear el filesystem" },
		{ "rm", comando_rm, "rm​ <path_archivo> : eliminar archivo,\n\t\trm​ ​-d​ <path_dir> : eliminar directorio, \n\t\trm​ ​-b​ <path_archivo> <nro_bloque> <nro_copia>: eliminar numero de copia de n bloque de un archivo" },
		{ "help", comando_help, "Mostrar ayuda" },
		{ "?", comando_help, "Mostrar ayuda" },
		{ "rename", comando_rename, "rename <path_origen> <path_destino>: renombra un archivo o directorio" },
		{ "mv", comando_mv, "mv <path_origen> <path_destino>: mueve un archivo o directorio" },
		{ "cat", comando_cat, "cat <path_archivo>: muesta el contenido del archivo como texto plano" },
		{ "mkdir", comando_mkdir, "mkdir <path_dir>: crea un directorio" },
		{ "cpfrom", comando_cpfrom, "cpfrom​ <path_archivo_origen> <directorio_yamafs>: Copiar un archivo local al yamafs, siguiendo los lineamientos en la operacion Almacenar Archivo" },
		{ "cpto", comando_cpto, "cpto​ <path_archivo_yamafs> <directorio_filesystem>: Copiar un archivo de yamafs al filesystem local" },
		{ "cpblock", comando_cpblock, "cpblock​ <path_archivo> <nro_bloque> <id_nodo>: Crea una copia de un bloque de un archivo en el nodo dado" },
		{ "md5", comando_md5, "md5 <path_archivo> :Solicitar el MD5 de un archivo en yamafs" },
		{ "list", comando_ls, "Lista los archivos de un directorio" },
		{ "ls", comando_ls, "Lista los archivos de un directorio" },
		{ "info", comando_info, "info <path_archivo> : Muestra toda la información del archivo, incluyendo tamaño, bloques, ubicación de los bloques,etc"},
		{ "df", comando_df, "df: Muestra el espacio de almacenamiento disponible en el sistema y en cada nodo conectado"},
		{ "exit", comando_exit, "Terminar proceso filesystem" },
		{ (char *)NULL, (Function *)NULL, (char *)NULL }
};

char *
dupstr (s)
int s;
{
	char *r;

	r = xmalloc (strlen (s) + 1);
	strcpy (r, s);
	return (r);
}

int contieneString(char* original,char* buscado){
	return strstr(original, buscado) != NULL;
}

/*
 * delete_new_line_char:
 * borra el caracter de nueva linea de fgets
 * */
void delete_new_line_char(char* str){
	char* pos;
	if ((pos=strchr(str, '\n')) != NULL)
		*pos = '\0';
}

int validar_cantidad_parametros(char* params, int cant_params){
	char** parametros;
	int cantidad_parametros=0,rta=0;
	int i = 0;
	if(params[0]!='\0'){
		parametros = string_split(params, " ");
		while(parametros[cantidad_parametros]!=NULL){
			cantidad_parametros++;
		}
		if(cant_params==cantidad_parametros){
			rta = 1;
		}
	}
	else{
		if(cant_params==0)rta=1;
	}
	if(cant_params!=0){
		while(parametros[i]!=NULL){
			free(parametros[i]);
			i++;
		}
		free(parametros);
	}

	return rta;
}

int comando_help (arg) char *arg;{
	register int i;
	int printed = 0;
	log_trace(filesystem_log,"Se invoco al comando help.");
	for (i = 0; commands[i].name; i++)
	{
		if (!*arg || (strcmp (arg, commands[i].name) == 0))
		{
			printf ("%s\t\t%s.\n", commands[i].name, commands[i].doc);
			printed++;
		}
	}

	if (!printed)
	{
		printf ("No hay comandos que coincidan con `%s'.  Posibilidades:\n", arg);

		for (i = 0; commands[i].name; i++)
		{
			if (printed == 6)
			{
				printed = 0;
				printf ("\n");
			}

			printf ("%s\t", commands[i].name);
			printed++;
		}

		if (printed)
			printf ("\n");
	}
	return (0);

}

int comando_exit (arg)
char* arg;{
	int cant_params_correcto;
	cant_params_correcto=validar_cantidad_parametros(arg, 0);
	if(!cant_params_correcto){
		printf("cantidad de parametros incorrecto para el comando exit, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
	}else{
		log_trace(filesystem_log,"Se invoco al comando exit");
		quiere_salir_consola=1;
	}
	return 1;
}

int comando_format (arg)
char* arg;{
	int cant_params_correcto;
	cant_params_correcto=validar_cantidad_parametros(arg, 0);

	if(!cant_params_correcto){
		printf("cantidad de parametros incorrecto para el comando format, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
	}else{
		format_yama_fs();
	}
	return 1;
}

int comando_rm (arg)
char* arg;{
	int resultado_operacion;
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		if(contieneString(arg,"-d")){
			cant_params_correcto = validar_cantidad_parametros(arg, 2);
			if(!cant_params_correcto){
				printf("cantidad de parametros incorrecto para el comando rm, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
			}else{
				log_trace(filesystem_log,"Se invoco al comando rm -d");
				resultado_operacion = rmdir_fs_yama(arg);
				switch(resultado_operacion){
				case -1:
					printf("Error. El directorio ingresado no existe\n");
					break;
				case 0:
					printf("Error. El directorio ingresado no se encuentra vacio\n");
					break;
				case 1:
					printf("El directorio ha sido borrado correctamente\n");
					break;
				default:
					break;
				}
			}
		}else if(contieneString(arg,"-b")){
			cant_params_correcto = validar_cantidad_parametros(arg, 4);
			if(!cant_params_correcto){
				printf("cantidad de parametros incorrecto para el comando rm, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
			}else{
				rm_block_file(arg);
			}
		}else{
			cant_params_correcto = validar_cantidad_parametros(arg, 1);
			if(!cant_params_correcto){
				printf("cantidad de parametros incorrecto para el comando rm, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
			}else{
				rm_file_yama_fs(arg);
			}
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_rename (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 2);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando rename, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			rename_yamafs(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}

int comando_df (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 0);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando df, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			df_yamafs();
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}


int comando_mv (arg)
char* arg;{
	int cant_params_correcto;
	int resultado_operacion;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 2);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando mv, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			resultado_operacion = mv_fs_yama(arg);
			switch(resultado_operacion){
			case 0:
				printf("Error. Las rutas no son validas\n");
				break;
			case -1:
				printf("Error. El path origen del archivo no existe\n");
				break;
			case -2:
				printf("Error. El archivo no se encuentra en el path origen\n");
				break;
			case 1:
				printf("El comando mv se ejecutó correctamente.\n");
				break;
			default:
				break;
			}
			log_trace(filesystem_log,"Se invoco al comando mv");
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_cat (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 1);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando cat, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			cat_yama_fs(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}

int comando_mkdir (arg)
char* arg;{
	int cant_params_correcto;
	int resultado_operacion;
	cant_params_correcto=validar_cantidad_parametros(arg, 1);
	if(es_filesystem_estable()==1){
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando mkdir, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			resultado_operacion = mkdir_fs_yama(arg);
			if(resultado_operacion > 0){
				resultado_operacion = 1;
			}
			switch(resultado_operacion){
			case 0:
				printf("Error. El directorio ingresado ya existe\n");
				break;
			case -1:
				printf("Error. No se pudo crear el directorio en la tabla de directorios\n");
				break;
			case -2:
				printf("Error. El nombre del directorio supera el limite especificado\n");
				break;
			case 1:
				printf("El directorio se ha creado correctamente.\n");
				break;
			default:
				break;
			}
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}

int comando_cpfrom (arg)
char* arg;{
	int resultado_operacion;
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 2);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando cpfrom, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			log_trace(filesystem_log,"Se invoco al comando cpfrom");
			resultado_operacion = copy_from_local_to_yamafs(arg);
			switch(resultado_operacion){
			case -1:
				printf("Error. No hay espacio para el archivo y su copia, se cancela la operacion.\n");
				break;
			case 0:
				printf("Error. Error al intentar leer el archivo del filesystem local.\n");
				break;
			case -2:
				printf("Error. Error interno de la aplicacion.\n");
				break;
			case -3:
				printf("Error. No se pudo crear el directorio.\n");
				break;
			case -4:
				printf("Error. Ya existe un archivo con el mismo nombre.\n");
				break;
			case 1:
				printf("Se escribio el archivo correctamente.\n");
				break;
			default:
				break;
			}
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}

int comando_cpto (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 2);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando cpto, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			copy_from_yama_to_local(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_cpblock (arg)
char* arg; {
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 3);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando cpblock, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			cpblock_fs_yama(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_md5 (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 1);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando md5, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			md5_yama_fs(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_ls (arg)
char* arg;{
	int cant_params_correcto;
	int resultado;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 1);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando ls o list, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			log_trace(filesystem_log,"Se invoco al comando ls");
			resultado = ls_yama(arg);
			if(!resultado)printf("El directorio ingresado no existe.\n");
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}
	return 1;
}
int comando_info (arg)
char* arg;{
	int cant_params_correcto;
	if(es_filesystem_estable()==1){
		cant_params_correcto=validar_cantidad_parametros(arg, 1);
		if(!cant_params_correcto){
			printf("cantidad de parametros incorrecto para el comando info, verifique la sintaxis. Ingrese help o ? para obtener ayuda.\n");
		}else{
			info_yamafs(arg);
		}
	}else{
		printf("El filesystem todavia no se encuentra estable, no se puede ejecutar el comando.\n");
	}

	return 1;
}


void ejecutar_consola_con_historial(char* prompt) {
	char *line, *s;
	initialize_readline();
	quiere_salir_consola=0;
	while(!quiere_salir_consola)
	{
		line = readline (prompt);
		if (line){
			s = stripwhite (line);
			if (*s)
			{
				add_history (s);
				execute_line(s);
			}
			free(line);
		}
	}
}

int execute_line (line)
char *line;{
	register int i;
	COMMAND *command;
	char *word;
	int rta_cmd;

	i = 0;

	while (line[i] && whitespace (line[i]))
		i++;
	word = line + i;

	while (line[i] && !whitespace (line[i]))
		i++;

	if (line[i])
		line[i++] = '\0';

	command = find_command (word);

	if (!command)
	{
		printf ("%s: No existe el comando.\n", word);
		return (-1);
	}

	while (whitespace (line[i]))
		i++;

	word = line + i;

	rta_cmd = (*command->func)(word);
	return rta_cmd;
	//((*(command->func)));// (word));
}


COMMAND * find_command (name)
char *name;{

	register int i;

	for (i = 0; commands[i].name; i++)
		if (strcmp (name, commands[i].name) == 0)
			return (&commands[i]);

	return ((COMMAND *)NULL);
}

char * stripwhite (string)
char *string;{
	register char *s, *t;

	for (s = string; whitespace (*s); s++);

	if (*s == 0)
		return (s);

	t = s + strlen (s) - 1;
	while (t > s && whitespace (*t))
		t--;
	*++t = '\0';

	return s;
}


char *
command_generator (text, state)
char *text;
int state;
{
	static int list_index, len;
	char *name;

	if (!state)
	{
		list_index = 0;
		len = strlen (text);
	}

	while (name = commands[list_index].name)
	{
		list_index++;

		if (strncmp (name, text, len) == 0)
			return (dupstr(name));
	}

	return ((char *)NULL);
}

char **
fileman_completion (text, start, end)
char *text;
int start, end;
{
	char **matches;

	matches = (char **)NULL;

	if (start == 0)
		matches = completion_matches (text, command_generator);

	return (matches);
}

void initialize_readline (void)
{
	rl_readline_name = "FileSystem>";

	rl_attempted_completion_function = (CPPFunction *)fileman_completion;
}
