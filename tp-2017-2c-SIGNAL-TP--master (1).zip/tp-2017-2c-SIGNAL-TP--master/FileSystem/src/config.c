/*
 * config.c
 *
 *  Created on: 3/9/2017
 *      Author: utnso
 */
#include "config.h"


int filesystem_config_create(filesystem_config *config,char* config_path){
	t_config *cfg_config;
	cfg_config = config_create(config_path);
	if(cfg_config == NULL){
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(filesystem_log, "filesystem_config_create->No se pudo acceder al archivo de config");
		pthread_mutex_unlock(&mutex_filesystem_log);
		return 0;
	}

	if (config_keys_amount(cfg_config) == CANTIDAD_PARAMETROS_CONFIG) {
		if (config_has_property(cfg_config, "PUERTO_FILESYSTEM")) {
			config->puerto_filesystem = config_get_int_value(cfg_config, "PUERTO_FILESYSTEM");
		} else {
			pthread_mutex_lock(&mutex_filesystem_log);
			log_error(filesystem_log, "filesystem_config_create->Falta el parametro: PUERTO_FILESYSTEM");
			pthread_mutex_unlock(&mutex_filesystem_log);
			return 0;
		}
	}else{
		pthread_mutex_lock(&mutex_filesystem_log);
		log_error(filesystem_log, "filesystem_config_create->El archivo de configuracion no tiene todos los parametros necesarios");
		pthread_mutex_unlock(&mutex_filesystem_log);
		return 0;
	}
	pthread_mutex_lock(&mutex_filesystem_log);
	log_trace(filesystem_log, "filesystem_config_create->Se ha cargado el archivo de configuracion del filesystem exitosamente");
	pthread_mutex_unlock(&mutex_filesystem_log);
	config_destroy(cfg_config);
	return 1;
}

void filesystem_config_destroy(filesystem_config *config){
	free(config);
	pthread_mutex_lock(&mutex_filesystem_log);
	log_trace(filesystem_log, "filesystem_config_destroy->Estructura filesystem liberada exitosamente");
	pthread_mutex_unlock(&mutex_filesystem_log);
}

void log_config(filesystem_config *config){
	pthread_mutex_lock(&mutex_filesystem_log);
	log_trace(filesystem_log,"-----Archivo de configuracion del proceso filesystem -----\n");
	log_trace(filesystem_log,"PUERTO_FILESYSTEM: %d\n",config->puerto_filesystem);
	log_trace(filesystem_log,"-----Fin archivo de configuracion del proceso filesystem-----\n");
	pthread_mutex_unlock(&mutex_filesystem_log);
}

